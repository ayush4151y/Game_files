extends SceneTree

## Verifies the tap-to-start handler really fires, by emitting a real input
## event through the overlay's own gui_input signal (headless cannot deliver
## physical mouse input, but the handler wiring is what was broken).
##   godot --headless --path . --script res://tests/check_tap.gd

var _main: Node
var _gm: GameManager
var _ui: UI


func _initialize() -> void:
	Save.reset_progress()
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	root.add_child(_main)
	_go()


func _go() -> void:
	await _wait(4)
	_gm = _main.get_node("Game")
	_ui = _gm.ui
	var fails := 0

	# the regression: a STOP child under the overlay ate every tap
	for child in _ui._tap_overlay.get_children():
		if child is Control and (child as Control).mouse_filter != Control.MOUSE_FILTER_IGNORE:
			fails += 1
			printerr("tap overlay child ", child.get_class(),
				" has mouse_filter ", (child as Control).mouse_filter)
	print("[1] tap overlay children ignore input: ", "OK" if fails == 0 else "FAIL")

	fails += await _check_tap("tutorial", func() -> void: _gm.launch_tutorial())
	_gm.stop_tutorial(false)
	_gm.is_tutorial = false
	fails += await _check_tap("daily", func() -> void: _gm.start_daily())
	fails += await _check_tap("endless", func() -> void: _gm.start_endless())

	# level select must have a non-zero height grid inside a non-zero scroll
	_gm.stop_tutorial(false)
	_gm.is_tutorial = false
	_gm.start_game()
	await _wait(6)
	var scroll := _ui._level_grid.get_parent() as ScrollContainer
	if _ui._level_grid.get_global_rect().size.y <= 0.0 or scroll.get_global_rect().size.y <= 0.0:
		fails += 1
		printerr("[2] level grid collapsed: grid=", _ui._level_grid.get_global_rect(),
			" scroll=", scroll.get_global_rect())
	print("[2] level grid has height: grid=", _ui._level_grid.get_global_rect().size,
		" scroll_h=", scroll.get_global_rect().size.y)

	# every cell must sit inside the scroll area, not off-screen
	# the grid is taller than the viewport on purpose (it scrolls), so check the
	# scroll is a real clipped viewport and every cell sits within its width
	var f3 := 0
	var scr := scroll.get_global_rect()
	for i in range(_ui._level_grid.get_child_count()):
		var cr: Rect2 = (_ui._level_grid.get_child(i) as Control).get_global_rect()
		if cr.position.x < scr.position.x or cr.end.x > scr.end.x:
			f3 += 1
	fails += f3
	if f3:
		printerr("[3] ", f3, " cells overflow the scroll width")
	print("[3] grid scrolls inside a ", scr.size, " viewport: ", "OK" if f3 == 0 else "FAIL")

	if fails == 0:
		print("PASS: tap overlay, mode taps, level select layout")
	else:
		printerr("FAIL: ", fails, " check(s)")
	quit(1 if fails else 0)


func _check_tap(label: String, start: Callable) -> int:
	start.call()
	await _wait(2)
	var t := 0.0
	while t < 15.0 and not _ui._tap_overlay.visible:
		await _sleep(0.05)
		t += 0.05
	if not _ui._tap_overlay.visible:
		printerr("[", label, "] tap overlay never appeared, state=", _gm.state)
		return 1
	var i0 := _gm.show_start_index
	var first := _gm.cube_grid._path_cubes[i0]
	var last := _gm.cube_grid._path_cubes[_gm.cube_grid._path_cubes.size() - 1]
	var y_before := _gm.cube_grid._path_cubes[i0 + 1].mesh.position.y if _gm.cube_grid._path_cubes.size() > i0 + 1 else 0.5
	var ev := InputEventScreenTouch.new()
	ev.pressed = true
	ev.position = Vector2(10, 10)
	_ui._tap_overlay.gui_input.emit(ev)
	t = 0.0
	while t < 15.0 and not _gm.is_playing():
		await _sleep(0.05)
		t += 0.05
	if not _gm.is_playing():
		printerr("[", label, "] tap did not start play, state=", _gm.state)
		return 1
	# first/last are the start/end tiles, which stay up by design, so check a
	# middle cube and require the whole middle band to be down
	var total := _gm.cube_grid._path_cubes.size()
	var ups := 0
	for j in range(i0 + 1, total - 1):
		if _gm.cube_grid._path_cubes[j].mesh.position.y >= 0.0:
			ups += 1
	var hid := total < 3 or ups == 0
	print("[", label, "] tap started play=", _gm.is_playing(),
		" cubes=", total, " still_up=", ups,
		" start/end kept=", first.mesh.position.y, "/", last.mesh.position.y,
		" first_mid_before=", y_before, " hidden=", hid)
	if not hid:
		printerr("[", label, "] blocks did not hide after tap")
		return 1
	return 0


func _wait(frames: int) -> void:
	for _i in range(frames):
		await process_frame


func _sleep(s: float) -> void:
	await create_timer(s).timeout