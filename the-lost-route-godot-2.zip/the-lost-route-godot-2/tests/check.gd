extends SceneTree

## Self-check: run with
##   godot --headless --path . --script res://tests/check.gd
##
## 1. Path generation must match the JS output byte for byte (tests/expected_paths.json
##    is produced by running the original PathGenerator.js under node).
## 2. A booted level must accept a step and advance the player by exactly one cell.

var _fails := 0


func _initialize() -> void:
	_check_paths()
	_check_blocks()
	await _check_gameplay()
	if _fails == 0:
		print("PASS: path + block parity, full walk to win")
	else:
		printerr("FAIL: ", _fails, " check(s)")
	quit(1 if _fails else 0)


func _check_paths() -> void:
	var cases: Array = JSON.parse_string(FileAccess.get_file_as_string("res://tests/expected_paths.json"))
	var gen := PathGenerator.new()
	for c in cases:
		var got: Array[Vector2i] = gen.generate(int(c["len"]), int(c["seed"]), float(c["bias"]), int(c["min_turns"]))
		var want: Array = c["path"]
		if got.size() != want.size():
			_fails += 1
			printerr("level ", c["level"], ": length ", got.size(), " != ", want.size())
			continue
		for i in got.size():
			var w: Array = want[i]
			if got[i] != Vector2i(int(w[0]), int(w[1])):
				_fails += 1
				printerr("level ", c["level"], " step ", i, ": ", got[i], " != ", w)
				break


func _check_blocks() -> void:
	var cases: Array = JSON.parse_string(FileAccess.get_file_as_string("res://tests/expected_paths.json"))
	for c in cases:
		var path: Array[Vector2i] = []
		for raw in c["path"]:
			path.append(Vector2i(int(raw[0]), int(raw[1])))
		var bm := BlockManager.new()
		bm.reset()
		bm.assign(path, int(c["seed"]), int(c["level"]))
		var want_types: Array = c["types"]
		if bm.types.size() != want_types.size():
			_fails += 1
			printerr("level ", c["level"], ": block count ", bm.types.size(), " != ", want_types.size())
			continue
		var bad := -1
		for i in want_types.size():
			if bm.types[i] != want_types[i]:
				bad = i
				break
		if bad >= 0:
			_fails += 1
			printerr("level ", c["level"], ": block ", bad, " is ", bm.types[bad], " != ", want_types[bad])
		# decoys are compared relative to path[0]: the JS centre offset is a
		# float shift, ours is rounded, so absolute coords differ by half a cell
		var origin := path[0]
		var want_decoys: Array = c["decoys"]
		if bm.decoys.size() != want_decoys.size():
			_fails += 1
			printerr("level ", c["level"], ": decoy count ", bm.decoys.size(), " != ", want_decoys.size())
			continue
		for i in want_decoys.size():
			var w: Array = want_decoys[i]
			if bm.decoys[i] - origin != Vector2i(int(w[0]), int(w[1])):
				_fails += 1
				printerr("level ", c["level"], ": decoy ", i, " ", bm.decoys[i] - origin, " != ", w)
				break


func _check_gameplay() -> void:
	var scene: PackedScene = load("res://scenes/main.tscn")
	var main: Node = scene.instantiate()
	root.add_child(main)
	await process_frame
	await process_frame

	var gm: GameManager = main.get_node("Game")
	assert(gm != null, "GameManager missing from main.tscn")
	gm.skip_show()
	await process_frame
	gm.tap_to_start()
	for _i in range(600):
		await process_frame
		if gm.is_playing():
			break
	if not gm.is_playing():
		_fails += 1
		printerr("tap_to_start did not reach playing, state=", gm.state)
		return

	# regression: exponential fog at density 1.0 whites out the scene the moment
	# play begins, so the fog must be linear (three.js Fog near/far)
	var env: EnvironmentBuilder = main.get_node("Environment")
	if not env._env.fog_enabled or env._env.fog_mode != Environment.FOG_MODE_DEPTH:
		_fails += 1
		printerr("fog is not linear: enabled=", env._env.fog_enabled, " mode=", env._env.fog_mode)

	var first := Cfg.dir_between(gm.path[0], gm.path[1])
	var target := gm.path[1]
	gm.handle_move(first)
	for _i in range(120):
		await process_frame
		if not gm.player.is_moving:
			break
	if gm.current_path_index != 1 or gm.player.position.x != float(target.x) or gm.player.position.z != float(target.y):
		_fails += 1
		printerr("step failed: index=", gm.current_path_index, " pos=", gm.player.position, " want=", target)
		return

	# level 2 is pure grass (tier 1 has no ice/fire/tnt), so walking the whole
	# path must end in a win
	while gm.current_path_index < gm.path.size() - 1:
		if not gm.is_playing():
			break
		var step := Cfg.dir_between(gm.path[gm.current_path_index], gm.path[gm.current_path_index + 1])
		gm.handle_move(step)
		for _i in range(240):
			await process_frame
			if not gm.player.is_moving:
				break
		if gm.state == GameManager.State.GAMEOVER:
			break
	if gm.state != GameManager.State.WON:
		_fails += 1
		printerr("walk did not win: state=", gm.state, " index=", gm.current_path_index, "/", gm.path.size() - 1)