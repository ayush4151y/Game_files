class_name BlockManager
extends RefCounted

## Port of BlockManager.js. Block mix per level tier, TNT decoy placement,
## ice slide timer, fire burn budget, TNT fuse. Sentinel -1.0 == JS null.

var types: PackedStringArray = PackedStringArray()
var decoys: Array[Vector2i] = []

var slide_remaining := -1.0
var slide_dir := ""
var slide_expired := false

var fire_remaining := Cfg.FIRE_BUDGET
var standing_on_fire := false
var fire_warn_accum := 0.0

var fuse_remaining := -1.0


func reset() -> void:
	types = PackedStringArray()
	decoys = []
	slide_remaining = -1.0
	slide_dir = ""
	slide_expired = false
	fire_remaining = Cfg.FIRE_BUDGET
	standing_on_fire = false
	fire_warn_accum = 0.0
	fuse_remaining = -1.0


func assign(path: Array[Vector2i], seed: int, level: int, no_hearts := false) -> void:
	var tier := _tier_for(level)
	var ice_pct := _ramp(tier["ice"], level, tier)
	var fire_pct := _ramp(tier["fire"], level, tier)
	var heart_pct := 0.0 if no_hearts else _ramp(tier["heart"], level, tier)
	# seed stays under 2^31 so the multiply cannot overflow a 64-bit int
	var rng := Rng.lcg(((seed & 0x7fffffff) * 2654435761) & Rng.U32)

	types = PackedStringArray()
	types.resize(path.size())
	for i in path.size():
		types[i] = Cfg.T_GRASS

	for i in range(0, path.size()):
		if i == 0:
			types[i] = Cfg.T_GRASS
			continue
		var r := rng.next()
		if heart_pct > 0.0 and r < heart_pct:
			types[i] = Cfg.T_HEART
		elif fire_pct > 0.0 and r < heart_pct + fire_pct:
			types[i] = Cfg.T_FIRE
		elif ice_pct > 0.0 and r < heart_pct + fire_pct + ice_pct:
			types[i] = Cfg.T_ICE
		else:
			types[i] = Cfg.T_GRASS

	# decoy TNT sits on the outer side of every turn
	var first_candidate := Vector2i.ZERO
	var has_candidate := false
	for i in range(1, path.size() - 1):
		var d1 := Cfg.dir_between(path[i - 1], path[i])
		var d2 := Cfg.dir_between(path[i], path[i + 1])
		if d1 == "" or d1 == d2:
			continue
		var pos: Vector2i = path[i] + Cfg.dir_vec(d1)
		var is_tnt := rng.next() < float(tier["tnt"])
		if not path.has(pos) and not decoys.has(pos):
			if not has_candidate:
				first_candidate = pos
				has_candidate = true
			if is_tnt:
				decoys.append(pos)
	if level > 20 and decoys.is_empty() and has_candidate:
		decoys.append(first_candidate)


func type_of(index: int) -> String:
	if index < 0 or index >= types.size():
		return Cfg.T_GRASS
	return types[index]


func is_decoy(x: int, z: int) -> bool:
	for d in decoys:
		if d.x == x and d.y == z:
			return true
	return false


func is_slide_active() -> bool:
	return slide_remaining >= 0.0


func slide_progress() -> float:
	if slide_remaining < 0.0:
		return 0.0
	return 1.0 - maxf(slide_remaining / Cfg.ICE_SLIDE_TIME, 0.0)


func fuse_active() -> bool:
	return fuse_remaining >= 0.0


func fire_active() -> bool:
	return standing_on_fire


func fire_percent() -> float:
	return maxf(fire_remaining / Cfg.FIRE_BUDGET, 0.0)


func cancel_slide() -> void:
	slide_remaining = -1.0


func activate_tnt(gm) -> void:
	fuse_remaining = Cfg.TNT_FUSE_TIME
	gm.on_tnt_activated()


func defuse_tnt(gm) -> void:
	fuse_remaining = -1.0
	gm.on_tnt_defused()


func on_entered(index: int, gm, from_pos: Vector2i) -> void:
	var type := type_of(index)
	if type == Cfg.T_ICE:
		slide_remaining = Cfg.ICE_SLIDE_TIME
		slide_dir = Cfg.dir_between(from_pos, gm.path[index])
		gm.update_phase_text("SLIDING! Choose direction!")
	elif slide_remaining >= 0.0:
		slide_remaining = -1.0
		gm.update_phase_text("Go!")
	if type == Cfg.T_FIRE:
		standing_on_fire = true
		fire_warn_accum = 0.0
		gm.player.set_fire(true)
	elif standing_on_fire:
		standing_on_fire = false
		gm.player.set_fire(false)
	if type == Cfg.T_HEART:
		gm.add_health(1)
		gm.update_phase_text("Heart! +1")


func update(dt: float, gm) -> void:
	if slide_remaining >= 0.0:
		slide_remaining -= dt
		if slide_remaining <= 0.0:
			slide_remaining = -1.0
			slide_expired = true
			gm.game_over()
			return
	if standing_on_fire:
		fire_remaining -= dt
		if fire_remaining <= 0.0:
			fire_remaining = Cfg.FIRE_BUDGET
			gm.on_fire_burned()
			return
		fire_warn_accum += dt
		if fire_warn_accum >= Cfg.FIRE_WARN_STEP:
			fire_warn_accum = 0.0
		gm.update_phase_text("FIRE! " + ("%.1f" % maxf(fire_remaining, 0.0)) + "s")
	if fuse_remaining >= 0.0:
		fuse_remaining -= dt
		if fuse_remaining <= 0.0:
			fuse_remaining = -1.0
			gm.on_tnt_exploded()
			return


static func _tier_for(level: int) -> Dictionary:
	for t in Cfg.LEVEL_TIERS:
		if level <= int(t["end"]):
			return t
	return Cfg.LEVEL_TIERS[Cfg.LEVEL_TIERS.size() - 1]


static func _ramp(chance, level: int, tier: Dictionary) -> float:
	if chance == null:
		return 0.0
	if chance is float or chance is int:
		return float(chance)
	var t := minf((float(level) - float(tier["start"])) / (float(tier["end"]) - float(tier["start"])), 1.0)
	return lerpf(float(chance[0]), float(chance[1]), t)