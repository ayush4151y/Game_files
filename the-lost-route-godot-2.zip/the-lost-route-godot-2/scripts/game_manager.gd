class_name GameManager
extends Node3D

## Port of GameManager.js (campaign path only). Owns the state machine, the
## per-level setup/teardown and every rule that reacts to a move.

enum State { SHOWING, PLAYING, WON, GAMEOVER }

var path: Array[Vector2i] = []
var current_path_index := 0
var level := 1
var health := Cfg.MAX_HEARTS
var state: State = State.SHOWING
var paused := false

var path_gen := PathGenerator.new()
var blocks := BlockManager.new()
var cube_grid: CubeGrid
var island_builder: IslandBuilder
var environment: EnvironmentBuilder
var player: Player
var camera_rig: CameraRig
var ui

var _midpoint_rewarded := false
var _sequence_id := 0
var _tnt_back_direction := ""
var _active_tnt := Vector2i.ZERO
var _has_active_tnt := false
var _slide_falling := false
var _stuck_token := 0
var _skip_busy := false


func _process(delta: float) -> void:
	if paused:
		return
	if _slide_falling:
		player.position.y -= delta * 5.0
		if player.position.y < -1.2:
			_slide_falling = false
		ui.set_fire_bar(false, 0.0)
		return
	if state != State.PLAYING:
		ui.set_fire_bar(false, 0.0)
		return

	blocks.update(delta, self)
	if blocks.slide_expired:
		blocks.slide_expired = false
		_slide_falling = true
	if blocks.is_slide_active():
		var p := blocks.slide_progress()
		var pos := path[current_path_index]
		var d := Cfg.dir_vec(blocks.slide_dir)
		player.position = Vector3(pos.x + d.x * 0.45 * p, Cfg.PLAYER_Y, pos.y + d.y * 0.45 * p)
	ui.set_fire_bar(blocks.fire_active(), blocks.fire_percent())


# --- level setup -------------------------------------------------------------

func start_level(l: int) -> void:
	level = l
	var path_len := get_path_length(level)
	var seed := level * 9973 + 42
	var turn_bias := get_turn_bias(level)
	var min_turns := maxi(1, int(floor(path_len / 3.0)))

	cleanup()
	_sequence_id += 1

	path = path_gen.generate(path_len, seed, turn_bias, min_turns)
	_offset_path_to_center()
	blocks.assign(path, seed, level)
	island_builder.build(path)
	cube_grid.build_from_path(path, blocks)
	camera_rig.adjust_camera_to_path(path)

	player.create(path[0])
	player.is_moving = false
	current_path_index = 0
	health = Cfg.MAX_HEARTS
	_midpoint_rewarded = false
	slide_falling_off()

	state = State.SHOWING
	update_phase_text("Watch!")
	ui.show_info(true)
	ui.set_skip_visible(true)
	ui.show_action_buttons(false)
	ui.show_tap_overlay(false)
	ui.set_hearts(health)
	update_hud()

	_show_sequence()


func get_path_length(l: int) -> int:
	var r: Dictionary = Cfg.PATH_RANGES[Cfg.PATH_RANGES.size() - 1]
	for x in Cfg.PATH_RANGES:
		if l <= int(x["max"]):
			r = x
			break
	var t := minf((float(l) - float(r["min"])) / (float(r["max"]) - float(r["min"])), 1.0)
	return int(round(float(r["len_min"]) + (float(r["len_max"]) - float(r["len_min"])) * t))


func get_turn_bias(l: int) -> float:
	return 0.4 + minf((float(l) - 1.0) / 199.0, 1.0) * 0.4


func _offset_path_to_center() -> void:
	var min_x := INF
	var max_x := -INF
	var min_z := INF
	var max_z := -INF
	for p in path:
		min_x = minf(min_x, float(p.x))
		max_x = maxf(max_x, float(p.x))
		min_z = minf(min_z, float(p.y))
		max_z = maxf(max_z, float(p.y))
	var center := Vector2i(int(round((min_x + max_x) * 0.5)), int(round((min_z + max_z) * 0.5)))
	# ponytail: JS subtracts the float centre, which shifts every cell by half a
	# unit. Rounding the centre instead keeps grid coords integral (decoy lookups
	# and dir_between stay exact) and only translates the level by half a cell.
	for i in path.size():
		path[i] -= center


func cleanup() -> void:
	_clear_stuck_timer()
	_tnt_back_direction = ""
	_active_tnt = Vector2i.ZERO
	_has_active_tnt = false
	_slide_falling = false
	_sequence_id += 1
	ui.hide_all()
	blocks.reset()
	cube_grid.cancel = true
	cube_grid.clear()
	player.destroy()


func slide_falling_off() -> void:
	_slide_falling = false


# --- show sequence -----------------------------------------------------------

func _show_sequence() -> void:
	var seq := _sequence_id
	cube_grid.cancel = false
	await cube_grid.show_path_wave()
	if _sequence_id != seq or state != State.SHOWING:
		return
	cube_grid.draw_path_line(path)
	ui.show_tap_overlay(true)


func tap_to_start() -> void:
	if state != State.SHOWING:
		return
	var seq := _sequence_id
	ui.show_tap_overlay(false)
	cube_grid.remove_path_line()
	cube_grid.cancel = false
	await cube_grid.hide_path_wave()
	if _sequence_id != seq or state != State.SHOWING or paused:
		return
	cube_grid.start_idle_animations()
	begin_playing()


func begin_playing() -> void:
	state = State.PLAYING
	environment.set_fog(true)
	update_phase_text("Go!")
	ui.set_skip_visible(false)
	ui.show_action_buttons(true)
	_start_stuck_timer()


# --- moves -------------------------------------------------------------------

func handle_move(direction: String) -> void:
	if state != State.PLAYING or paused or player.is_moving:
		return
	direction = camera_rig.screen_to_world(direction)
	if blocks.fuse_active():
		if direction == _tnt_back_direction:
			_back_to_previous()
		return

	var next_index := current_path_index + 1
	if next_index >= path.size():
		return
	var current := path[current_path_index]
	var nxt := path[next_index]

	if Cfg.dir_between(current, nxt) == direction:
		blocks.cancel_slide()
		_clear_stuck_timer()
		current_path_index = next_index
		var from_pos := current
		player.move_to(nxt, next_index, func() -> void: _on_stepped(next_index, from_pos))
		return

	var np := current + Cfg.dir_vec(direction)
	if blocks.is_decoy(np.x, np.y):
		_clear_stuck_timer()
		_tnt_back_direction = Cfg.opposite(Cfg.dir_between(current, np))
		_active_tnt = np
		_has_active_tnt = true
		player.move_to(np, -1, func() -> void:
			cube_grid.rise_decoy_at(np.x, np.y)
			blocks.activate_tnt(self))
	else:
		game_over()


func _on_stepped(index: int, from_pos: Vector2i) -> void:
	cube_grid.rise_cube_at(index)
	if index == path.size() - 1:
		win_level()
		return
	blocks.on_entered(index, self, from_pos)
	if not _midpoint_rewarded and index >= int(floor(path.size() / 2.0)):
		_midpoint_rewarded = true
		add_health(1)
		update_phase_text("Midway! +1 Heart")
	_start_stuck_timer()


func hint_move() -> void:
	if state != State.PLAYING or paused or player.is_moving:
		return
	if blocks.fuse_active() or blocks.is_slide_active():
		return
	var next_index := current_path_index + 1
	if next_index >= path.size():
		return
	_clear_stuck_timer()
	current_path_index = next_index
	player.current_index = next_index
	var nxt := path[next_index]
	var prev := path[next_index - 1]
	player.position = Vector3(nxt.x, Cfg.PLAYER_Y, nxt.y)
	player.set_face_direction(float(nxt.x - prev.x), float(nxt.y - prev.y))
	cube_grid.hint_rise_at(next_index)
	if next_index == path.size() - 1:
		win_level()
		return
	_start_stuck_timer()


func _back_to_previous() -> void:
	if state != State.PLAYING or paused or player.is_moving:
		return
	if not blocks.fuse_active():
		return
	var target := current_path_index - 1
	if target < 0:
		return
	blocks.defuse_tnt(self)
	current_path_index = target
	var t := target
	player.move_to(path[t], t, func() -> void:
		cube_grid.rise_cube_at(t)
		blocks.on_entered(t, self, path[t - 1])
		_start_stuck_timer())


# --- TNT ---------------------------------------------------------------------

func on_tnt_activated() -> void:
	update_phase_text("TNT! Go back!")
	ui.highlight_tnt_back(_tnt_back_direction)


func on_tnt_defused() -> void:
	update_phase_text("Go!")
	ui.clear_tnt_back()
	_tnt_back_direction = ""
	_active_tnt = Vector2i.ZERO
	_has_active_tnt = false


func on_tnt_exploded() -> void:
	update_phase_text("BOOM!")
	ui.clear_tnt_back()
	_tnt_back_direction = ""
	var pos := _active_tnt
	var had_tnt := _has_active_tnt
	_active_tnt = Vector2i.ZERO
	_has_active_tnt = false
	if had_tnt:
		await get_tree().create_timer(0.12).timeout
		cube_grid.blast_at(pos.x, pos.y)
		await get_tree().create_timer(0.48).timeout
	game_over()


# --- health ------------------------------------------------------------------

func add_health(amount: int) -> void:
	health = mini(health + amount, Cfg.MAX_HEARTS)
	ui.set_hearts(health)


func on_fire_burned() -> void:
	health -= 1
	ui.set_hearts(health)
	update_phase_text("Burned! -1 Heart")
	if health <= 0:
		game_over()


# --- flow --------------------------------------------------------------------

func win_level() -> void:
	if state != State.PLAYING:
		return
	state = State.WON
	update_phase_text("Level Complete!")
	ui.show_action_buttons(false)
	ui.set_skip_visible(false)
	ui.hide_tap_overlay()
	await get_tree().create_timer(0.5).timeout
	if state == State.WON:
		ui.show_win("LEVEL COMPLETE!", "NEXT LEVEL")


func next_level() -> void:
	start_level(level + 1)


func game_over() -> void:
	if state == State.GAMEOVER or state == State.WON:
		return
	state = State.GAMEOVER
	update_phase_text("Game Over")
	ui.show_action_buttons(false)
	ui.set_skip_visible(false)
	ui.hide_tap_overlay()
	await get_tree().create_timer(0.3).timeout
	if state == State.GAMEOVER:
		ui.show_game_over("Level " + str(level))


func restart() -> void:
	start_level(level)


func skip_show() -> void:
	if state == State.WON or state == State.GAMEOVER or _skip_busy:
		return
	_skip_busy = true
	start_level(level + 1)
	# JS holds skipBusy for 500ms so a double tap cannot skip two levels
	await get_tree().create_timer(0.5).timeout
	_skip_busy = false


func toggle_pause() -> void:
	if state != State.SHOWING and state != State.PLAYING:
		return
	paused = not paused
	cube_grid.paused = paused
	if paused:
		ui.show_pause()
		ui.hide_tap_overlay()
	else:
		ui.hide_pause()
		if state == State.SHOWING:
			ui.show_tap_overlay(true)


func resume_from_pause() -> void:
	paused = false
	cube_grid.paused = false
	ui.hide_pause()
	if state == State.SHOWING:
		ui.show_tap_overlay(true)


func rotate_view() -> void:
	if path.is_empty():
		return
	camera_rig.rotate_view(90.0)


func is_playing() -> bool:
	return state == State.PLAYING


func update_phase_text(text: String) -> void:
	ui.set_phase(text)


func update_hud() -> void:
	ui.set_level(level)


# --- stuck hint --------------------------------------------------------------

func _start_stuck_timer() -> void:
	_stuck_token += 1
	var token := _stuck_token
	ui.set_hint_glow(false)
	await get_tree().create_timer(Cfg.STUCK_HINT_MS / 1000.0).timeout
	if token == _stuck_token and state == State.PLAYING and not paused:
		ui.set_hint_glow(true)


func _clear_stuck_timer() -> void:
	_stuck_token += 1
	if ui != null:
		ui.set_hint_glow(false)