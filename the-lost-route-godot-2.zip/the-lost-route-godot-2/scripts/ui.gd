class_name UI
extends CanvasLayer

## HUD + input. D-pad buttons and 4-way swipes are both live at the same time
## (the web build forced a choice in settings; this port takes both).

var gm

var _root: Control
var _level_label: Label
var _phase_label: Label
var _hearts: Array[Panel] = []
var _hint_btn: Button
var _rotate_btn: Button
var _skip_btn: Button
var _pause_btn: Button
var _tnt_btn := {}
var _dpad := {}
var _tap_overlay: Control
var _pause_popup: Control
var _win_popup: Control
var _over_popup: Control
var _fire_bar: Control
var _fire_fill: ColorRect
var _swipe_start: Variant = null
var _move_lock_until := 0


func build(game_manager) -> void:
	gm = game_manager
	layer = 10
	# tap overlay goes in first so it sits *under* the HUD: while the path is
	# being shown it swallows swipes, but SKIP/HINT/PAUSE must stay tappable
	_build_tap_overlay()
	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)

	_build_hud()
	_build_action_buttons()
	_build_dpad()
	_build_fire_bar()
	_build_popups()
	hide_all()


# --- construction ------------------------------------------------------------

func _place(c: Control, ax: float, ay: float, w: float, h: float, ox := 0.0, oy := 0.0) -> void:
	c.anchor_left = ax
	c.anchor_top = ay
	c.anchor_right = ax
	c.anchor_bottom = ay
	c.offset_left = ox
	c.offset_top = oy
	c.offset_right = ox + w
	c.offset_bottom = oy + h


func _button(text: String, w: float, h: float, font := 22) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", font)
	b.custom_minimum_size = Vector2(w, h)
	return b


func _build_hud() -> void:
	_level_label = Label.new()
	_level_label.add_theme_font_size_override("font_size", 24)
	_level_label.add_theme_color_override("font_color", Color(1, 1, 1))
	_place(_level_label, 0, 0, 260, 36, 24, 18)
	_root.add_child(_level_label)

	for i in range(Cfg.MAX_HEARTS):
		var p := Panel.new()
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.914, 0.118, 0.388)
		sb.set_corner_radius_all(16)
		sb.set_border_width_all(3)
		sb.border_color = Color(1, 1, 1, 0.85)
		p.add_theme_stylebox_override("panel", sb)
		_place(p, 1, 0, 34, 34, -156 + i * 42, 20)
		_root.add_child(p)
		_hearts.append(p)

	_phase_label = Label.new()
	_phase_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_phase_label.add_theme_font_size_override("font_size", 26)
	_phase_label.add_theme_color_override("font_color", Color(1, 0.93, 0.6))
	_phase_label.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.8))
	_phase_label.add_theme_constant_override("outline_size", 5)
	_place(_phase_label, 0.5, 0, 520, 40, -260, 66)
	_root.add_child(_phase_label)


func _build_action_buttons() -> void:
	_pause_btn = _button("II", 60, 60, 20)
	_place(_pause_btn, 1, 0, 60, 60, -84, 18)
	_pause_btn.pressed.connect(func() -> void: gm.toggle_pause())
	_root.add_child(_pause_btn)

	_hint_btn = _button("HINT", 76, 60, 18)
	_place(_hint_btn, 1, 0, 76, 60, -100, 96)
	_hint_btn.pressed.connect(func() -> void: gm.hint_move())
	_root.add_child(_hint_btn)

	_rotate_btn = _button("ROT", 76, 60, 18)
	_place(_rotate_btn, 1, 0, 76, 60, -100, 168)
	_rotate_btn.pressed.connect(func() -> void: gm.rotate_view())
	_root.add_child(_rotate_btn)

	_skip_btn = _button("SKIP", 76, 46, 16)
	_place(_skip_btn, 1, 0, 76, 46, -100, 240)
	_skip_btn.pressed.connect(func() -> void: gm.skip_show())
	_root.add_child(_skip_btn)

	for dir in ["up", "down", "left", "right"]:
		var b := _button(_arrow(dir), 60, 60, 24)
		_place(b, 1, 0, 60, 60, -84, 300)
		b.modulate = Color(1, 0.6, 0.5)
		b.visible = false
		_root.add_child(b)
		_tnt_btn[dir] = b


## ASCII arrows on purpose: the default Godot font has no geometric-shape
## glyphs, and this port ships no icon assets.
func _arrow(dir: String) -> String:
	match dir:
		"up": return "^"
		"down": return "v"
		"left": return "<"
	return ">"


func _build_dpad() -> void:
	var spots := {
		"up": [100.0, -212.0],
		"left": [24.0, -124.0],
		"right": [176.0, -124.0],
		"down": [100.0, -124.0],
	}
	for dir in spots:
		var b := _button(_arrow(dir), 76, 76, 30)
		var s: Array = spots[dir]
		_place(b, 0, 1, 76, 76, s[0], s[1])
		b.button_down.connect(_on_dpad.bind(dir))
		_root.add_child(b)
		_dpad[dir] = b


func _build_fire_bar() -> void:
	_fire_bar = Control.new()
	_fire_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fire_bar.size = Vector2(130, 12)
	_root.add_child(_fire_bar)

	var bg := ColorRect.new()
	bg.color = Color(0, 0, 0, 0.55)
	bg.size = Vector2(130, 12)
	_fire_bar.add_child(bg)

	_fire_fill = ColorRect.new()
	_fire_fill.color = Color(1.0, 0.596, 0.0)
	_fire_fill.position = Vector2(3, 3)
	_fire_fill.size = Vector2(124, 6)
	_fire_bar.add_child(_fire_fill)
	_fire_bar.visible = false


func _build_tap_overlay() -> void:
	_tap_overlay = Control.new()
	_tap_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_tap_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	var l := Label.new()
	l.text = "TAP TO START"
	l.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", 40)
	l.add_theme_color_override("font_color", Color(1, 1, 1))
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	l.add_theme_constant_override("outline_size", 6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_tap_overlay.add_child(l)
	_tap_overlay.gui_input.connect(func(e: InputEvent) -> void:
		if (e is InputEventScreenTouch and e.pressed) or (e is InputEventMouseButton and e.pressed):
			gm.tap_to_start())
	add_child(_tap_overlay)
	_tap_overlay.visible = false


func _panel(title: String, lines: Array) -> Control:
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.6)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(dim)

	var box := VBoxContainer.new()
	box.name = "Box"
	box.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	box.position = Vector2(-180, -140)
	box.size = Vector2(360, 280)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 18)
	root.add_child(box)

	var t := Label.new()
	t.text = title
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.add_theme_font_size_override("font_size", 34)
	t.add_theme_color_override("font_color", Color(1, 0.93, 0.6))
	box.add_child(t)

	for line in lines:
		var l := Label.new()
		l.text = str(line)
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		l.add_theme_font_size_override("font_size", 22)
		box.add_child(l)
	return root


func _centered(button: Button) -> void:
	button.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	button.custom_minimum_size = Vector2(260, 60)


func _panel_box(popup: Control) -> VBoxContainer:
	return popup.get_node("Box")


func _build_popups() -> void:
	_pause_popup = _panel("PAUSED", [])
	var pbox := _panel_box(_pause_popup)
	var resume := _button("RESUME", 260, 60, 22)
	_centered(resume)
	resume.pressed.connect(func() -> void: gm.resume_from_pause())
	pbox.add_child(resume)
	var again := _button("RESTART", 260, 60, 22)
	_centered(again)
	again.pressed.connect(func() -> void: gm.restart())
	pbox.add_child(again)
	_pause_popup.visible = false
	add_child(_pause_popup)

	_win_popup = _panel("LEVEL COMPLETE!", [""])
	var nb := _button("NEXT LEVEL", 260, 60, 22)
	_centered(nb)
	nb.pressed.connect(func() -> void: gm.next_level())
	_panel_box(_win_popup).add_child(nb)
	_win_popup.visible = false
	add_child(_win_popup)

	_over_popup = _panel("GAME OVER", [""])
	var rb := _button("TRY AGAIN", 260, 60, 22)
	_centered(rb)
	rb.pressed.connect(func() -> void: gm.restart())
	_panel_box(_over_popup).add_child(rb)
	_over_popup.visible = false
	add_child(_over_popup)


# --- public api --------------------------------------------------------------

func set_level(l: int) -> void:
	_level_label.text = "Level " + str(l)


func set_phase(text: String) -> void:
	_phase_label.text = text


func set_hearts(h: int) -> void:
	for i in _hearts.size():
		var sb: StyleBoxFlat = _hearts[i].get_theme_stylebox("panel")
		sb.bg_color = Color(0.914, 0.118, 0.388) if i < h else Color(0.25, 0.22, 0.24, 0.75)


func show_info(v: bool) -> void:
	_level_label.visible = v
	for h in _hearts:
		h.visible = v
	_pause_btn.visible = v


func show_action_buttons(v: bool) -> void:
	_hint_btn.visible = v
	_rotate_btn.visible = v
	for d in _dpad:
		_dpad[d].visible = v


func set_skip_visible(v: bool) -> void:
	_skip_btn.visible = v


func set_hint_glow(on: bool) -> void:
	_hint_btn.modulate = Color(1.0, 0.84, 0.31) if on else Color(1, 1, 1)


func highlight_tnt_back(dir: String) -> void:
	clear_tnt_back()
	if _tnt_btn.has(dir):
		_tnt_btn[dir].visible = true


func clear_tnt_back() -> void:
	for d in _tnt_btn:
		_tnt_btn[d].visible = false


func show_tap_overlay(v: bool) -> void:
	_tap_overlay.visible = v


func hide_tap_overlay() -> void:
	_tap_overlay.visible = false


func show_pause() -> void:
	_pause_popup.visible = true


func hide_pause() -> void:
	_pause_popup.visible = false


func show_win(title: String, _button_text: String) -> void:
	_popup_title(_win_popup, title)
	_win_popup.visible = true


func show_game_over(title: String) -> void:
	_popup_title(_over_popup, title)
	_over_popup.visible = true


func hide_all() -> void:
	show_info(false)
	show_action_buttons(false)
	set_skip_visible(false)
	hide_tap_overlay()
	hide_pause()
	_win_popup.visible = false
	_over_popup.visible = false
	_fire_bar.visible = false
	clear_tnt_back()
	_phase_label.text = ""
	_level_label.text = ""


func _popup_title(popup: Control, text: String) -> void:
	var t: Label = _panel_box(popup).get_child(0)
	t.text = text


func set_fire_bar(v: bool, percent: float) -> void:
	if not v or gm == null or gm.camera_rig == null or gm.camera_rig.camera == null:
		_fire_bar.visible = false
		return
	var cam: Camera3D = gm.camera_rig.camera
	var world: Vector3 = gm.player.global_position + Vector3(0.0, 1.6, 0.0)
	if cam.is_position_behind(world):
		_fire_bar.visible = false
		return
	_fire_bar.visible = true
	_fire_bar.position = cam.unproject_position(world) - _fire_bar.size * 0.5
	_fire_fill.size.x = (_fire_bar.size.x - 6.0) * clampf(percent, 0.0, 1.0)


# --- input -------------------------------------------------------------------

func _on_dpad(dir: String) -> void:
	if gm == null:
		return
	var now := Time.get_ticks_msec()
	if now < _move_lock_until:
		return
	_move_lock_until = now + int(Cfg.MOVE_LOCK_S * 1000.0)
	gm.handle_move(dir)


func _unhandled_input(event: InputEvent) -> void:
	var is_press: bool = (event is InputEventScreenTouch) \
		or (event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT)
	if is_press:
		if event.is_pressed():
			_swipe_start = event.position
		elif _swipe_start != null:
			var from: Vector2 = _swipe_start
			_swipe_start = null
			_swipe(_end_position(event) - from)
		return

	if event is InputEventKey and event.pressed and not event.echo and gm != null:
		match event.keycode:
			KEY_UP:
				gm.handle_move("up")
			KEY_DOWN:
				gm.handle_move("down")
			KEY_LEFT:
				gm.handle_move("left")
			KEY_RIGHT:
				gm.handle_move("right")
			KEY_S:
				gm.skip_show()
			KEY_SPACE, KEY_ENTER:
				gm.tap_to_start()
			KEY_H:
				gm.hint_move()
			KEY_R:
				gm.rotate_view()
			KEY_P, KEY_ESCAPE:
				gm.toggle_pause()


func _end_position(event: InputEvent) -> Vector2:
	if event is InputEventScreenTouch:
		return event.position
	if event is InputEventMouseButton:
		return event.position
	return Vector2.ZERO


func _swipe(d: Vector2) -> void:
	if gm == null or not gm.is_playing() or gm.paused or gm.player.is_moving:
		return
	if maxf(absf(d.x), absf(d.y)) < Cfg.SWIPE_MIN_PX:
		return
	if absf(d.x) > absf(d.y):
		gm.handle_move("right" if d.x > 0.0 else "left")
	else:
		gm.handle_move("down" if d.y > 0.0 else "up")