class_name UI
extends CanvasLayer

## Port of the index.html / UIController.js UI, laid out from the real CSS
## numbers. Heights are scaled by `_ui_scale()` because the JS uses a px-based
## layout that assumes a desktop-sized viewport; phones get proportionally
## smaller controls from the `--ui-ctrl` media tiers.

enum Screen { NONE, MENU, LEVELS, SETTINGS }

const TOTAL_LEVELS := 200
const CTRL_TIER_A := 76.0
const CTRL_TIER_B := 60.0
const CTRL_TIER_C := 56.0
const CONTROLS_BOTTOM_A := 80.0
const CONTROLS_BOTTOM_B := 8.0
const CONTROLS_BOTTOM_C := 4.0
const INFO_TOP_A := 15.0
const INFO_TOP_B := 6.0
const TAP_PAD_A := 200.0
const TAP_PAD_B := 110.0
const TAP_PAD_C := 80.0
const GRID_MIN_A := 68.0
const GRID_MIN_B := 54.0
const GRID_MIN_C := 46.0
const GRID_GAP_A := 12.0
const GRID_GAP_B := 6.0
const GRID_GAP_C := 4.0
const GRID_PAD_A := 16.0
const GRID_PAD_B := 8.0
const GRID_PAD_C := 6.0

const COL_INK := Color(0.200, 0.255, 0.302)
const COL_MUTED := Color(0.490, 0.545, 0.588)
const COL_TEAL := Color(0.055, 0.604, 0.650)
const COL_BG_TOP := Color(0.812, 0.914, 0.973)
const COL_BG_BOTTOM := Color(0.984, 0.933, 0.796)
const COL_CARD := Color(1, 1, 1)
const COL_DANGER := Color(0.839, 0.271, 0.271)
const COL_SUCCESS := Color(0.122, 0.616, 0.388)

var gm

var screen := Screen.NONE

var _root: Control
var _scale := 1.0

var _level_pill: Label
var _phase_label: Label
var _hearts: Array[Panel] = []
var _heart_box: HBoxContainer

var _pause_btn: Button
var _skip_btn: Button
var _hint_btn: Button
var _rotate_btn: Button
var _dpad := {}
var _tnt_btn := {}

var _tap_overlay: Control
var _tap_label: Label

var _pause_popup: Dictionary
var _win_popup: Dictionary
var _over_popup: Dictionary

var _menu_screen: Control
var _levels_screen: Control
var _settings_screen: Control
var _level_grid: GridContainer
var _ls_subtitle: Label
var _dpad_option: Button
var _swipe_option: Button

var _tut_banner: PanelContainer
var _tut_label: Label

var _fire_bar: Control
var _fire_fill: ColorRect
var _swipe_start: Variant = null
var _move_lock_until := 0


func build(game_manager) -> void:
	gm = game_manager
	layer = 10
	_build_tap_overlay()
	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)

	_build_hud()
	_build_action_buttons()
	_build_dpad()
	_build_fire_bar()
	_build_tutorial_banner()
	_build_popups()
	_build_menu()
	_build_levels()
	_build_settings()
	get_viewport().size_changed.connect(_relayout)
	_relayout()
	hide_all()


func _vp() -> Vector2:
	var vp := get_viewport()
	return Vector2(vp.size) if vp != null else Vector2(1280, 720)


## Mirrors the JS media tiers: short viewports get the smaller control set.
func _tier() -> int:
	var h := _vp().y
	if h <= 360.0:
		return 2
	if h <= 480.0:
		return 1
	return 0


func _ctrl_size() -> float:
	match _tier():
		0: return CTRL_TIER_A
		1: return CTRL_TIER_B
	return CTRL_TIER_C


func _controls_bottom() -> float:
	match _tier():
		0: return CONTROLS_BOTTOM_A
		1: return CONTROLS_BOTTOM_B
	return CONTROLS_BOTTOM_C


func _tap_pad() -> float:
	match _tier():
		0: return TAP_PAD_A
		1: return TAP_PAD_B
	return TAP_PAD_C


func _info_top() -> float:
	return INFO_TOP_A if _tier() == 0 else INFO_TOP_B


## JS renders at a fixed CSS pixel size; on a 720p-tall phone that is too big,
## so everything is scaled to the viewport before the tier constants are applied.
func _relayout() -> void:
	_scale = clampf(minf(_vp().x / 1280.0, _vp().y / 720.0), 0.55, 1.0)
	if _root != null:
		_root.scale = Vector2(_scale, _scale)
	_layout_hud()
	_layout_controls()
	_layout_popups()
	_layout_screens()


# --- construction ------------------------------------------------------------

func _place(c: Control, ax: float, ay: float, w: float, h: float, ox := 0.0, oy := 0.0) -> void:
	c.anchor_left = ax
	c.anchor_top = ay
	c.anchor_right = ax
	c.anchor_bottom = ay
	c.offset_left = ox
	c.offset_top = oy
	c.offset_right = ox + w
	c.offset_bottom = oy + h


func _center(c: Control, w: float, h: float) -> void:
	c.anchor_left = 0.5
	c.anchor_top = 0.5
	c.anchor_right = 0.5
	c.anchor_bottom = 0.5
	c.offset_left = -w * 0.5
	c.offset_top = -h * 0.5
	c.offset_right = w * 0.5
	c.offset_bottom = h * 0.5


func _label(text: String, size: int, color: Color, center := true) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if center:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.autowrap_mode = TextServer.AUTOWRAP_OFF
	return l


func _button(text: String, w: float, h: float, font := 22) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", font)
	b.custom_minimum_size = Vector2(w, h)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(1, 1, 1, 0.72)
	sb.set_corner_radius_all(int(maxf(8.0, h * 0.3)))
	sb.set_border_width_all(2)
	sb.border_color = Color(0.353, 0.549, 0.647, 0.4)
	sb.set_content_margin_all(4)
	b.add_theme_stylebox_override("normal", sb)
	var hover := sb.duplicate() as StyleBoxFlat
	hover.bg_color = Color(1, 1, 1, 0.85)
	b.add_theme_stylebox_override("hover", hover)
	var pressed := sb.duplicate() as StyleBoxFlat
	pressed.bg_color = Color(0.180, 0.769, 0.800, 0.6)
	b.add_theme_stylebox_override("pressed", pressed)
	return b


func _pill_button(text: String, w: float, h: float, font := 22, danger := false) -> Button:
	var b := _button(text, w, h, font)
	b.add_theme_stylebox_override("normal", _pill_box(danger, 1.0))
	b.add_theme_stylebox_override("hover", _pill_box(danger, 1.2))
	b.add_theme_stylebox_override("pressed", _pill_box(danger, 0.8))
	return b


func _pill_box(danger: bool, mul: float) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	if danger:
		sb.bg_color = Color(0.839, 0.271, 0.271, mul)
	else:
		sb.bg_color = Color(0.180, 0.769, 0.800, mul)
	sb.set_corner_radius_all(50)
	sb.set_content_margin_all(10)
	return sb


func _gradient_backdrop() -> Control:
	# a TextureRect, not a ColorRect: ColorRect has no texture property
	var bg := TextureRect.new()
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_SCALE
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var grad := Gradient.new()
	grad.set_color(0, COL_BG_TOP)
	grad.set_color(1, COL_BG_BOTTOM)
	var gt := GradientTexture2D.new()
	gt.gradient = grad
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(0, 1)
	gt.width = 8
	gt.height = 256
	bg.texture = gt
	return bg


func _build_hud() -> void:
	# #info-bar: level pill is centred during play, phase text is hidden then
	_level_pill = _label("Level 1", 18, COL_TEAL)
	_level_pill.add_theme_stylebox_override("normal", _pill_box(false, 0.0))
	_root.add_child(_level_pill)

	_phase_label = _label("", 19, COL_TEAL)
	_root.add_child(_phase_label)

	_heart_box = HBoxContainer.new()
	_heart_box.add_theme_constant_override("separation", 6)
	_heart_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_heart_box)
	for _i in range(Cfg.MAX_HEARTS):
		var p := Panel.new()
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(0.878, 0.322, 0.322)
		sb.set_corner_radius_all(9)
		_heart_box.add_child(p)
		p.add_theme_stylebox_override("panel", sb)
		_hearts.append(p)


func _build_action_buttons() -> void:
	# JS: pause top-left 15px/40px; skip right 15px, hint right 65px,
	# rotate right 121px. All 40x40.
	_pause_btn = _button("II", 40, 40, 16)
	_pause_btn.pressed.connect(func() -> void: gm.toggle_pause())
	_root.add_child(_pause_btn)

	_hint_btn = _button("?", 40, 40, 20)
	_hint_btn.pressed.connect(func() -> void: gm.hint_move())
	_root.add_child(_hint_btn)

	_rotate_btn = _button("ROT", 40, 40, 11)
	_rotate_btn.pressed.connect(func() -> void: gm.rotate_view())
	_root.add_child(_rotate_btn)

	_skip_btn = _button(">>", 40, 40, 15)
	_skip_btn.pressed.connect(func() -> void: gm.skip_show())
	_root.add_child(_skip_btn)

	for dir in ["up", "down", "left", "right"]:
		var b := _button(_arrow(dir), 40, 40, 14)
		b.visible = false
		b.add_theme_stylebox_override("normal", _tnt_box())
		_root.add_child(b)
		_tnt_btn[dir] = b


func _tnt_box() -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.878, 0.322, 0.322, 0.4)
	sb.set_corner_radius_all(12)
	sb.set_border_width_all(2)
	sb.border_color = Color(0.878, 0.322, 0.322, 0.7)
	return sb


## ASCII arrows on purpose: the default Godot font has no geometric-shape glyphs
## and this port ships no icon assets.
func _arrow(dir: String) -> String:
	match dir:
		"up": return "^"
		"down": return "v"
		"left": return "<"
	return ">"


func _build_dpad() -> void:
	# JS: two clusters. Left is a column (up over down), right is a row
	# (left, right). Both bottom-aligned, 24px side padding, 14px inner gap.
	for dir in ["up", "down", "left", "right"]:
		var b := _button(_arrow(dir), 76, 76, 30)
		b.button_down.connect(_on_dpad.bind(dir))
		_root.add_child(b)
		_dpad[dir] = b


func _build_fire_bar() -> void:
	# JS #fire-bar: 56x5, rounded, orange fill, centred on the player's head.
	_fire_bar = Control.new()
	_fire_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fire_bar.custom_minimum_size = Vector2(56, 5)
	_root.add_child(_fire_bar)

	var bg := ColorRect.new()
	bg.color = Color(1, 1, 1, 0.5)
	bg.size = Vector2(56, 5)
	_fire_bar.add_child(bg)

	_fire_fill = ColorRect.new()
	_fire_fill.color = Color(1.0, 0.341, 0.133)
	_fire_fill.position = Vector2.ZERO
	_fire_fill.size = Vector2(56, 5)
	_fire_bar.add_child(_fire_fill)
	_fire_bar.visible = false


func _build_tap_overlay() -> void:
	# Built first so it sits under the HUD: it swallows swipes while the path is
	# shown, but SKIP/HINT/PAUSE must stay tappable.
	_tap_overlay = Control.new()
	_tap_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_tap_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	var tint := ColorRect.new()
	tint.color = Color(1, 1, 1, 0.25)
	tint.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_tap_overlay.add_child(tint)
	_tap_label = _label("TAP ANYWHERE TO START", 22, Color(0.055, 0.604, 0.65, 0.9))
	_tap_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_tap_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_tap_overlay.add_child(_tap_label)
	_tap_overlay.gui_input.connect(func(e: InputEvent) -> void:
		if (e is InputEventScreenTouch and e.pressed) or (e is InputEventMouseButton and e.pressed):
			gm.tap_to_start())
	add_child(_tap_overlay)
	_tap_overlay.visible = false


func _build_tutorial_banner() -> void:
	_tut_banner = PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.051, 0.078, 0.141, 0.88)
	sb.set_corner_radius_all(12)
	sb.set_border_width_all(1)
	sb.border_color = Color(1.0, 0.835, 0.31, 0.5)
	sb.set_content_margin_all(10)
	_tut_banner.add_theme_stylebox_override("panel", sb)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	_tut_label = _label("", 15, Color(1.0, 0.835, 0.31), false)
	row.add_child(_tut_label)
	var skip := _button("X", 28, 28, 13)
	skip.pressed.connect(func() -> void: gm.stop_tutorial(true))
	row.add_child(skip)
	_tut_banner.add_child(row)
	_tut_banner.visible = false
	_root.add_child(_tut_banner)


func _screen_root() -> Control:
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(_gradient_backdrop())
	return root


func _header(back_call: Callable, title: String) -> Array:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	var back := _button("<", 44, 44, 22)
	back.pressed.connect(back_call)
	row.add_child(back)
	var t := _label(title, 20, Color(0.059, 0.165, 0.239), false)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	t.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(t)
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(44, 0)
	row.add_child(spacer)
	return [row, t]


func _build_menu() -> void:
	_menu_screen = _screen_root()
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 10)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	_center(box, 460, 420)
	_menu_screen.add_child(box)

	var title := _label("THE LOST ROUTE", 44, Color(0.059, 0.165, 0.239))
	box.add_child(title)
	var tag := _label("MEMORY  ·  REACTION  ·  MASTERY", 15, Color(0.18, 0.286, 0.361))
	box.add_child(tag)

	for spec in [["START", "start_game"], ["ENDLESS", "start_endless"],
			["DAILY CHALLENGE", "start_daily"], ["SETTINGS", "show_settings"]]:
		var b := _pill_button(str(spec[0]), 460, 60, 24)
		b.pressed.connect(func() -> void: gm.call(str(spec[1])))
		box.add_child(b)

	add_child(_menu_screen)
	_menu_screen.visible = false


func _build_levels() -> void:
	_levels_screen = _screen_root()
	var col := VBoxContainer.new()
	col.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_levels_screen.add_child(col)

	var head: Array = _header(func() -> void: gm.hide_level_select(), "SELECT LEVEL")
	var row: HBoxContainer = head[0]
	var vpad := MarginContainer.new()
	vpad.add_theme_constant_override("margin_top", 16)
	vpad.add_theme_constant_override("margin_bottom", 8)
	vpad.add_child(row)
	col.add_child(vpad)

	var sub_row := HBoxContainer.new()
	_ls_subtitle = _label("CAMPAIGN", 14, COL_TEAL)
	_ls_subtitle.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_ls_subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub_row.add_child(_ls_subtitle)
	var sub_pad := MarginContainer.new()
	sub_pad.add_theme_constant_override("margin_bottom", 6)
	sub_pad.add_child(sub_row)
	col.add_child(sub_pad)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_level_grid = GridContainer.new()
	_level_grid.columns = _grid_columns()
	scroll.add_child(_level_grid)
	var scroll_pad := MarginContainer.new()
	scroll_pad.add_theme_constant_override("margin_bottom", 16)
	scroll_pad.add_child(scroll)
	col.add_child(scroll_pad)

	add_child(_levels_screen)
	_levels_screen.visible = false


func _grid_columns() -> int:
	return maxi(4, int(_vp().x * _scale / maxf(_grid_min(), 1.0)))


func _grid_min() -> float:
	match _tier():
		0: return GRID_MIN_A
		1: return GRID_MIN_B
	return GRID_MIN_C


func _grid_gap() -> float:
	match _tier():
		0: return GRID_GAP_A
		1: return GRID_GAP_B
	return GRID_GAP_C


func _grid_pad() -> float:
	match _tier():
		0: return GRID_PAD_A
		1: return GRID_PAD_B
	return GRID_PAD_C


func _build_settings() -> void:
	_settings_screen = _screen_root()
	var col := VBoxContainer.new()
	col.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	col.add_theme_constant_override("separation", 12)
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	_settings_screen.add_child(col)

	var head: Array = _header(func() -> void: gm.hide_settings(), "SETTINGS")
	col.add_child(head[0])

	var section := _label("INPUT", 14, COL_MUTED)
	section.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	section.custom_minimum_size = Vector2(320, 0)
	col.add_child(section)

	var opts := HBoxContainer.new()
	opts.add_theme_constant_override("separation", 16)
	opts.custom_minimum_size = Vector2(320, 0)
	_dpad_option = _button("KEYS\n^ v", 152, 74, 18)
	_dpad_option.pressed.connect(func() -> void: gm.set_input_mode("dpad"))
	opts.add_child(_dpad_option)
	_swipe_option = _button("SWIPE\n< >", 152, 74, 18)
	_swipe_option.pressed.connect(func() -> void: gm.set_input_mode("swipe"))
	opts.add_child(_swipe_option)
	col.add_child(opts)

	var tut := _pill_button("TUTORIAL", 320, 56, 22)
	tut.pressed.connect(func() -> void: gm.launch_tutorial())
	col.add_child(tut)

	var reset := _pill_button("RESET PROGRESS", 320, 56, 22, true)
	reset.pressed.connect(func() -> void: gm.reset_progress())
	col.add_child(reset)

	add_child(_settings_screen)
	_settings_screen.visible = false


func _build_popups() -> void:
	_pause_popup = _card_popup("GAME PAUSED")
	var pause_home: Button = _pause_popup["home"]
	var pause_stay: Button = _pause_popup["stay"]
	pause_stay.text = "RESUME"
	pause_stay.pressed.connect(func() -> void: gm.resume_from_pause())
	pause_home.pressed.connect(func() -> void: gm.back_to_menu())
	_pause_popup["root"].visible = false
	add_child(_pause_popup["root"])

	_win_popup = _card_popup("LEVEL COMPLETE!")
	var win_stay: Button = _win_popup["stay"]
	var win_home: Button = _win_popup["home"]
	win_stay.pressed.connect(func() -> void: gm.win_action())
	win_home.visible = false
	_win_popup["root"].visible = false
	add_child(_win_popup["root"])

	_over_popup = _card_popup("GAME OVER")
	var over_stay: Button = _over_popup["stay"]
	var over_home: Button = _over_popup["home"]
	over_stay.pressed.connect(func() -> void: gm.restart())
	over_home.visible = false
	_over_popup["root"].visible = false
	add_child(_over_popup["root"])


## Popup shell matching the JS card screens: title, optional subtitle, a pill
## action and a ghost action. Returns {"root", "title", "sub", "stay", "home"}.
func _card_popup(title: String) -> Dictionary:
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	var dim := ColorRect.new()
	dim.color = Color(0.745, 0.882, 0.953, 0.5)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(dim)

	var card := VBoxContainer.new()
	card.add_theme_constant_override("separation", 12)
	_center(card, 300, 260)
	root.add_child(card)

	var t := _label(title, 34, COL_DANGER)
	card.add_child(t)
	var sub := _label("", 20, COL_MUTED)
	card.add_child(sub)
	# #final-level: the score line under the subtitle
	var detail := _label("", 26, COL_TEAL)
	card.add_child(detail)

	var stay := _pill_button("TRY AGAIN", 260, 56, 20)
	card.add_child(stay)
	var home := _button("HOME", 260, 48, 18)
	card.add_child(home)
	return {"root": root, "title": t, "sub": sub, "detail": detail, "stay": stay, "home": home}


# --- layout ------------------------------------------------------------------

func _layout_hud() -> void:
	var top := _info_top()
	var w := _vp().x * _scale
	# JS .game-active #level-indicator: absolutely centred at the top
	_level_pill.anchor_left = 0.5
	_level_pill.anchor_right = 0.5
	_level_pill.anchor_top = 0
	_level_pill.anchor_bottom = 0
	_level_pill.offset_left = -70
	_level_pill.offset_right = 70
	_level_pill.offset_top = top
	_level_pill.offset_bottom = top + 28
	# phase text sits on the right of the info bar when a level is not active
	_phase_label.offset_left = w - 240
	_phase_label.offset_right = w - 20
	_phase_label.offset_top = top + 2
	_phase_label.offset_bottom = top + 30
	_phase_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT

	var hsize := 18.0 if _tier() == 0 else 14.0
	var gap := 6.0 if _tier() == 0 else 4.0
	_heart_box.add_theme_constant_override("separation", int(gap))
	_heart_box.offset_left = 64.0 if _tier() == 0 else 48.0
	_heart_box.offset_right = 64.0 + Cfg.MAX_HEARTS * (hsize + gap)
	_heart_box.offset_top = 12.0 if _tier() == 0 else 6.0
	_heart_box.offset_bottom = _heart_box.offset_top + hsize
	for p in _hearts:
		p.custom_minimum_size = Vector2(hsize, hsize)
		var sb: StyleBoxFlat = p.get_theme_stylebox("panel")
		sb.set_corner_radius_all(int(hsize * 0.5))

	# JS top bar: pause left 15px; skip right 15, hint right 65, rotate right 121
	var bs := 40.0 if _tier() == 0 else 34.0
	for b in [_pause_btn, _skip_btn, _hint_btn, _rotate_btn]:
		b.custom_minimum_size = Vector2(bs, bs)
	_pause_btn.offset_left = 15
	_pause_btn.offset_top = top
	_pause_btn.offset_right = 15 + bs
	_pause_btn.offset_bottom = top + bs
	_skip_btn.anchor_left = 1
	_skip_btn.anchor_right = 1
	_skip_btn.offset_left = -(15 if _tier() == 0 else 8) - bs
	_skip_btn.offset_right = -(15 if _tier() == 0 else 8)
	_hint_btn.anchor_left = 1
	_hint_btn.anchor_right = 1
	_hint_btn.offset_left = -(65 if _tier() == 0 else 48) - bs
	_hint_btn.offset_right = -(65 if _tier() == 0 else 48)
	_rotate_btn.anchor_left = 1
	_rotate_btn.anchor_right = 1
	_rotate_btn.offset_left = -(121 if _tier() == 0 else 88) - bs
	_rotate_btn.offset_right = -(121 if _tier() == 0 else 88)
	for dir in _tnt_btn.values():
		var b: Button = dir
		b.custom_minimum_size = Vector2(bs, bs)

	_tap_label.offset_top = _vp().y * _scale - _tap_pad() - 30
	_tap_label.offset_bottom = _vp().y * _scale - _tap_pad()


func _layout_controls() -> void:
	var s := _ctrl_size()
	var bottom := _controls_bottom()
	var pad := 24.0
	var gap := 14.0 if _tier() == 0 else 8.0
	var w := _vp().x * _scale

	# left cluster: a column, up over down, 24px from the left
	var up: Button = _dpad["up"]
	var down: Button = _dpad["down"]
	up.anchor_left = 0
	up.anchor_right = 0
	up.offset_left = pad
	up.offset_right = pad + s
	up.offset_top = bottom + s + gap
	up.offset_bottom = bottom + s + gap + s
	down.anchor_left = 0
	down.anchor_right = 0
	down.offset_left = pad
	down.offset_right = pad + s
	down.offset_top = bottom
	down.offset_bottom = bottom + s

	# right cluster: a row, left then right, 24px from the right
	var left: Button = _dpad["left"]
	var right: Button = _dpad["right"]
	left.anchor_left = 1
	left.anchor_right = 1
	left.offset_left = -(pad + s * 2 + gap)
	left.offset_right = -(pad + s + gap)
	left.offset_top = bottom
	left.offset_bottom = bottom + s
	right.anchor_left = 1
	right.anchor_right = 1
	right.offset_left = -pad - s
	right.offset_right = -pad
	right.offset_top = bottom
	right.offset_bottom = bottom + s

	for b in _dpad.values():
		(b as Button).custom_minimum_size = Vector2(s, s)
	_tut_banner.anchor_left = 0.5
	_tut_banner.anchor_right = 0.5
	_tut_banner.offset_left = -minf(w * 0.46, 460)
	_tut_banner.offset_right = minf(w * 0.46, 460)
	_tut_banner.offset_top = 78.0
	_tut_banner.offset_bottom = 78.0 + 40


func _layout_popups() -> void:
	for pop: Dictionary in [_pause_popup, _win_popup, _over_popup]:
		var card: VBoxContainer = pop["root"].get_child(1)
		_center(card, 300, 280)


func _layout_screens() -> void:
	if _level_grid != null:
		_level_grid.columns = _grid_columns()
		_level_grid.add_theme_constant_override("h_separation", int(_grid_gap()))
		_level_grid.add_theme_constant_override("v_separation", int(_grid_gap()))


# --- public api --------------------------------------------------------------

func set_level(text: String) -> void:
	_level_pill.text = text


func set_phase(text: String) -> void:
	_phase_label.text = text


func set_hearts(h: int) -> void:
	for i in _hearts.size():
		var sb: StyleBoxFlat = _hearts[i].get_theme_stylebox("panel")
		sb.bg_color = Color(0.878, 0.322, 0.322) if i < h else Color(0.235, 0.314, 0.353, 0.25)


func show_info(v: bool) -> void:
	_level_pill.visible = v
	_heart_box.visible = v
	_pause_btn.visible = v
	# JS .game-active #phase-text { display: none } - the pill replaces it
	_phase_label.visible = not v


func show_hearts(v: bool) -> void:
	_heart_box.visible = v


func show_action_buttons(v: bool) -> void:
	_hint_btn.visible = v
	_rotate_btn.visible = v


func show_dpad(v: bool) -> void:
	for b in _dpad.values():
		(b as Button).visible = v


func set_skip_visible(v: bool) -> void:
	_skip_btn.visible = v


func set_hint_glow(on: bool) -> void:
	_hint_btn.modulate = Color(1.0, 0.835, 0.31) if on else Color(1, 1, 1)


func highlight_tnt_back(dir: String) -> void:
	clear_tnt_back()
	if _tnt_btn.has(dir):
		_tnt_btn[dir].visible = true


func clear_tnt_back() -> void:
	for b in _tnt_btn.values():
		(b as Button).visible = false


func show_tap_overlay(v: bool) -> void:
	_tap_overlay.visible = v


func hide_tap_overlay() -> void:
	_tap_overlay.visible = false


func show_pause() -> void:
	_pause_popup["root"].visible = true


func hide_pause() -> void:
	_pause_popup["root"].visible = false


func show_win(title: String, sub: String, action: String) -> void:
	var t: Label = _win_popup["title"]
	var s: Label = _win_popup["sub"]
	var b: Button = _win_popup["stay"]
	t.text = title
	t.add_theme_color_override("font_color", COL_SUCCESS)
	s.text = sub
	s.visible = sub != ""
	b.text = action
	_win_popup["root"].visible = true


func show_game_over(title: String, sub: String, detail: String, action: String) -> void:
	var t: Label = _over_popup["title"]
	var s: Label = _over_popup["sub"]
	var d: Label = _over_popup["detail"]
	var b: Button = _over_popup["stay"]
	t.text = title
	t.add_theme_color_override("font_color", COL_DANGER)
	s.text = sub
	s.visible = sub != ""
	d.text = detail
	d.visible = detail != ""
	b.text = action
	_over_popup["root"].visible = true


func hide_all() -> void:
	show_info(false)
	show_action_buttons(false)
	show_dpad(false)
	set_skip_visible(false)
	hide_tap_overlay()
	hide_pause()
	_win_popup["root"].visible = false
	_over_popup["root"].visible = false
	_fire_bar.visible = false
	clear_tnt_back()
	_tut_banner.visible = false
	_menu_screen.visible = false
	_levels_screen.visible = false
	_settings_screen.visible = false
	screen = Screen.NONE


func show_menu() -> void:
	hide_all()
	screen = Screen.MENU
	_menu_screen.visible = true


func show_levels(current_level: int) -> void:
	hide_all()
	screen = Screen.LEVELS
	_ls_subtitle.text = "CAMPAIGN"
	_levels_screen.visible = true
	_build_grid(current_level)


func _build_grid(current_level: int) -> void:
	for c in _level_grid.get_children():
		c.queue_free()
	var completed := Save.completed()
	var skipped := Save.skipped()
	var pad := int(_grid_pad())
	for i in range(1, TOTAL_LEVELS + 1):
		_level_grid.add_child(_level_cell(i, current_level, completed, skipped))
	_level_grid.add_theme_constant_override("h_separation", pad)
	_level_grid.add_theme_constant_override("v_separation", pad)


func _level_cell(n: int, current_level: int, completed: Array[int], skipped: Array[int]) -> Control:
	var side := _grid_min()
	var btn := Button.new()
	btn.custom_minimum_size = Vector2(side, side)
	btn.focus_mode = Control.FOCUS_NONE
	var state := "locked"
	var status := ""
	if completed.has(n):
		state = "complete"
		status = "COMPLETE"
	elif skipped.has(n):
		state = "skipped"
		status = "SKIPPED"
	elif n == current_level:
		state = "current"
		status = "CURRENT"
	elif n < current_level:
		state = "available"
		status = "PLAY"
	else:
		status = "LOCKED"

	var border := Color(0.059, 0.165, 0.239, 0.45)
	var num_col := Color(0.169, 0.255, 0.322)
	match state:
		"complete":
			border = Color(0.180, 0.620, 0.357)
			num_col = Color(0.055, 0.478, 0.239)
		"skipped":
			border = COL_DANGER
			num_col = Color(0.776, 0.157, 0.157)
		"current":
			border = Color(0.961, 0.620, 0.043)
			num_col = Color(0.761, 0.416, 0.0)
	var sb := StyleBoxFlat.new()
	sb.bg_color = COL_CARD if state != "locked" else Color(1, 1, 1, 0.5)
	sb.set_border_width_all(2)
	sb.border_color = border
	sb.set_corner_radius_all(10 if _tier() == 2 else 14)
	btn.add_theme_stylebox_override("normal", sb)
	var hover := sb.duplicate() as StyleBoxFlat
	hover.bg_color = Color(0.839, 0.957, 0.969)
	btn.add_theme_stylebox_override("hover", hover)
	btn.add_theme_stylebox_override("pressed", sb)
	if state == "locked":
		btn.modulate = Color(1, 1, 1, 0.5)
	else:
		btn.pressed.connect(func() -> void: gm.start_level(n))

	var col := VBoxContainer.new()
	col.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	col.alignment = BoxContainer.ALIGNMENT_CENTER
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	col.add_theme_constant_override("separation", 4)
	btn.add_child(col)
	var num := _label(str(n), 18 if _tier() == 0 else 13, num_col)
	col.add_child(num)
	col.add_child(_label(status, 9 if _tier() == 0 else 8, border))
	return btn


func show_settings() -> void:
	hide_all()
	screen = Screen.SETTINGS
	_settings_screen.visible = true
	var mode := Save.input_mode()
	_dpad_option.modulate = Color(1.0, 0.835, 0.31) if mode == "dpad" else Color(1, 1, 1)
	_swipe_option.modulate = Color(1.0, 0.835, 0.31) if mode == "swipe" else Color(1, 1, 1)


func hide_settings() -> void:
	show_menu()


func show_tutorial(text: String, keys: Array) -> void:
	_tut_label.text = text
	_tut_banner.visible = true
	for b in _dpad.values():
		(b as Button).modulate = Color(1, 1, 1)
	for key in keys:
		if _dpad.has(key):
			(_dpad[key] as Button).modulate = Color(1.0, 0.835, 0.31)
		elif key == "hint-btn":
			_hint_btn.modulate = Color(1.0, 0.835, 0.31)
		elif key == "rotate-right-btn":
			_rotate_btn.modulate = Color(1.0, 0.835, 0.31)


func hide_tutorial() -> void:
	_tut_banner.visible = false
	for b in _dpad.values():
		(b as Button).modulate = Color(1, 1, 1)


func set_fire_bar(v: bool, percent: float) -> void:
	if not v or gm == null or gm.camera_rig == null or gm.camera_rig.camera == null:
		_fire_bar.visible = false
		return
	var cam: Camera3D = gm.camera_rig.camera
	var world: Vector3 = gm.player.global_position + Vector3(0.0, 1.6, 0.0)
	if cam.is_position_behind(world):
		_fire_bar.visible = false
		return
	_fire_bar.visible = true
	_fire_bar.position = cam.unproject_position(world) - _fire_bar.size * 0.5
	_fire_fill.size.x = 56.0 * clampf(percent, 0.0, 1.0)


# --- input -------------------------------------------------------------------

func _on_dpad(dir: String) -> void:
	if gm == null:
		return
	var now := Time.get_ticks_msec()
	if now < _move_lock_until:
		return
	_move_lock_until = now + int(Cfg.MOVE_LOCK_S * 1000.0)
	gm.handle_move(dir)


func _unhandled_input(event: InputEvent) -> void:
	var is_press: bool = (event is InputEventScreenTouch) \
		or (event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT)
	if is_press:
		if event.is_pressed():
			_swipe_start = event.position
		elif _swipe_start != null:
			var from: Vector2 = _swipe_start
			_swipe_start = null
			_swipe(_end_position(event) - from)
		return

	if event is InputEventKey and event.pressed and not event.echo and gm != null:
		match event.keycode:
			KEY_UP:
				gm.handle_move("up")
			KEY_DOWN:
				gm.handle_move("down")
			KEY_LEFT:
				gm.handle_move("left")
			KEY_RIGHT:
				gm.handle_move("right")
			KEY_S:
				gm.skip_show()
			KEY_SPACE, KEY_ENTER:
				gm.confirm()
			KEY_H:
				gm.hint_move()
			KEY_R:
				gm.rotate_view()
			KEY_P, KEY_ESCAPE:
				gm.toggle_pause()


func _end_position(event: InputEvent) -> Vector2:
	if event is InputEventScreenTouch:
		return event.position
	if event is InputEventMouseButton:
		return event.position
	return Vector2.ZERO


func _swipe(d: Vector2) -> void:
	if gm == null or not gm.is_playing() or gm.paused or gm.player.is_moving:
		return
	if Save.input_mode() == "dpad":
		return
	if maxf(absf(d.x), absf(d.y)) < Cfg.SWIPE_MIN_PX:
		return
	if absf(d.x) > absf(d.y):
		gm.handle_move("right" if d.x > 0.0 else "left")
	else:
		gm.handle_move("down" if d.y > 0.0 else "up")