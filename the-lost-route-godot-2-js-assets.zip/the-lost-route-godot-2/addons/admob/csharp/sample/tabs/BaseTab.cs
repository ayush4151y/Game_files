// MIT License
//
// Copyright (c) 2023-present Poing Studios
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

using Godot;

namespace PoingStudios.AdMob.Sample
{
    public partial class BaseTab : VBoxContainer
    {
        public override void _Ready()
        {
            OptimizeForScrolling(this);
            GetViewport().SizeChanged += OnViewportSizeChanged;
            OnViewportSizeChanged();
        }

        private void OnViewportSizeChanged()
        {
            Vector2 vp = GetViewportRect().Size;
            Vector2 winSize = GetWindow().Size;
            if (vp.X <= 0 || vp.Y <= 0 || winSize.X <= 0 || winSize.Y <= 0)
                return;

            float scaleFactor = vp.Y / (float)winSize.Y;
            float windowFactor = (winSize.X + winSize.Y) / 1140.0f;
            float totalFactor = windowFactor * scaleFactor;

            UIScaler.ScaleUi(this, totalFactor, scaleFactor);
        }

        private void OptimizeForScrolling(Node node)
        {
            if (node is Control control)
            {
                bool isInteractive = control is Button ||
                                     control is LineEdit ||
                                     control is TextEdit ||
                                     control is Slider ||
                                     control is OptionButton ||
                                     control is CheckButton ||
                                     control is CheckBox ||
                                     control is ColorPickerButton ||
                                     control is MenuButton;

                if (!isInteractive)
                {
                    control.MouseFilter = Control.MouseFilterEnum.Ignore;
                }
            }

            foreach (Node child in node.GetChildren())
            {
                OptimizeForScrolling(child);
            }
        }
    }
}
