// MIT License

// Copyright (c) 2023-present Poing Studios

// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:

// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.

// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.


using Godot;
using PoingStudios.AdMob.Api.Listeners;

namespace PoingStudios.AdMob.Api.Core
{
    public class AdVideoController
    {
        private readonly int _uid;
        private readonly GodotObject _plugin;

        public VideoLifecycleCallbacks VideoLifecycleCallbacks { get; set; }

        public AdVideoController(int uid, GodotObject plugin)
        {
            _uid = uid;
            _plugin = plugin;
        }

        public bool IsMuted()
        {
            if (_plugin != null)
            {
                return (bool)_plugin.Call("is_video_muted", _uid);
            }
            return true;
        }

        public bool IsCustomControlsEnabled()
        {
            if (_plugin != null)
            {
                return (bool)_plugin.Call("is_video_custom_controls_enabled", _uid);
            }
            return false;
        }
    }
}
