# Ads integration — test APK via GitHub Actions

Date: 2026-10-08
Status: approved by user (verbal, in session)

## Goal

Show **Google test ads** in the game, deliver one **APK** built entirely by
GitHub Actions. **No Play Store release yet** — release steps (AAB, keystore
secrets, Play Console, AdMob account) are deferred until the game is finished.

## Decisions

| Topic | Decision |
|---|---|
| Ad service | Google AdMob via **Poing Studios plugin v5.1.0** (Godot 4.5+, tested with 4.7.2) |
| Ad IDs | Google **public test IDs** everywhere — no AdMob account needed |
| Build | **GitHub Actions** (repo is public → free). No on-device SDK, no PC |
| Sign | **debug keystore** generated per-run on CI — fine for test installs, no secrets needed now |
| Banner | home screen (menu) only, bottom-right, anchored adaptive |
| Rewarded #1 | HINT: **3 lifetime free hints** (persist in Save), then 1 ad per hint |
| Rewarded #2 | SKIP (level skip): always 1 ad. Reveal-animation skip stays free |
| Interstitial | not wired yet; Ads API will expose it later |
| Fallback | plugin/Android absent (desktop, headless tests) → `show_rewarded` calls back `true` immediately, banner no-ops. Game never breaks |
| Export | preset stays **APK** (`export_format=0`) for now; flip to AAB only at release time |

## Player-facing behaviour

- Hint button gets a small bubble: `3 → 2 → 1` while free hints remain, then `AD`.
  Count persists across sessions/levels (`rak_free_hints`, default 3).
- Tap hint with 0 free → rewarded ad → on reward granted, hint executes.
  Ad not granted (dismissed/failed) → no hint, button immediately tappable again.
- Game is paused while a rewarded ad is on screen, resumed on callback.
- Skip tap → ad first, only after grant does the existing skip path run.

## Files (all in `the-lost-route-godot-2/`)

- `scripts/ads.gd` — autoload `Ads`: `init()`, `show_banner()`, `hide_banner()`,
  `show_rewarded(cb)`. Uses `Engine.has_singleton("GodotAdMob")` / plugin API.
- `scripts/save.gd` — `rak_free_hints` (int, default 3), wiped with the rest in
  reset-progress.
- `scripts/game_manager.gd` — `hint_move()` and `skip_show()` gates.
- `scripts/ui.gd` — hint badge bubble; menu show/hide calls `Ads.show_banner()`
  / `hide_banner()`.
- `project.godot` — autoload `Ads`, plugin `admob` enabled, `admob/` project
  settings (test app id).
- `export_presets.cfg` — `permissions/internet=true`,
  `gradle_build/use_gradle_build=true`.
- `addons/admob/**` — plugin editor files (commit) + `android-template-v4.7.2.zip`
  natives extracted to `addons/admob/android/bin/` (commit).
- `tests/check.gd` — free-hint persistence, Ads fallback returns granted,
  export config assertions (internet + gradle on).

## CI (`.github/workflows/android.yml`, lives in the ZIP repo root)

1. checkout → unzip `the-lost-route-godot-2-js-assets.zip`
2. `actions/setup-java@v4` (temurin 17) + `android-actions/setup-android@v3`,
   install `platforms;android-35` + `build-tools;35.0.0`, accept licenses
3. download Godot 4.7.2 linux x86_64 + export templates tpz (cached)
4. write `editor_settings-4.tres` (android_sdk_path, debug keystore), generate
   debug keystore with `keytool`
5. preheat: `godot --headless --editor --quit || true` (imports assets)
6. `godot --headless --path . --install-android-build-template
   --export-release "Android" build/the-lost-route.apk`
7. `actions/upload-artifact` → APK

Triggers: `workflow_dispatch` + push to `main`.

## Test plan

- Both headless suites pass (`tests/check.gd`, `tests/check_tap.gd`).
- CI run green → download APK artifact → install on phone:
  menu shows test banner; hint shows `3` and decrements across 3 uses, 4th
  plays a test rewarded ad; skip plays a test ad before skipping.

## Known risks

- Headless import on CI can crash (`--editor --quit` guarded with `|| true`,
  retry as needed).
- Plugin export plugin blocks export if natives missing → natives committed.
- Banner overlaps menu art (island) — adjust on visual QA if needed.
