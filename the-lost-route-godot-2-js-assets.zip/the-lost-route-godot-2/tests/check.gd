extends SceneTree

## Self-check: run with
##   godot --headless --path . --script res://tests/check.gd
##
## 1. Path generation must match the JS output byte for byte (tests/expected_paths.json
##    is produced by running the original PathGenerator.js under node).
## 2. A booted level must accept a step and advance the player by exactly one cell.
## 3. Endless appends segments without overlapping old islands, and the daily
##    level matches its fixed setup.

var _fails := 0


func _check(label: String, ok: bool) -> void:
	if ok:
		print("  ok  ", label)
	else:
		_fails += 1
		printerr("  FAIL ", label)


func _initialize() -> void:
	# the boot flow writes user:// state; start from a clean slate so the menu
	# routing and the tutorial auto-start are deterministic
	Save.reset_progress()
	_check_paths()
	_check_blocks()
	await _check_gameplay()
	await _check_modes()
	await _check_camera_fits()
	if _fails == 0:
		print("PASS: path + block parity, full walk to win, mode setup, real-asset islands, audio")
	else:
		printerr("FAIL: ", _fails, " check(s)")
	quit(1 if _fails else 0)


## The camera is zoomed in, so the whole framed path has to stay on screen.
## Unprojecting the real cube corners is the same check a player would make by
## looking, and it is what stops a tighter CAM_SCREEN_FILL from clipping a level.
func _check_camera_fits() -> void:
	var main: Node = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	root.add_child(main)
	for _i in range(8):
		await process_frame
	var gm: GameManager = main.get_node("Game")
	gm.start_level(7)
	# the rig frames the path over a tween, so let it land before measuring
	for _i in range(90):
		await process_frame
	var cam: Camera3D = gm.camera_rig.camera
	if cam == null or not cam.is_inside_tree():
		_check("camera: every path corner stays on screen", false)
		printerr("      no camera in the tree")
		main.queue_free()
		await process_frame
		return
	var vp: Vector2 = cam.get_viewport().get_visible_rect().size
	# short, medium and long, plus a rotated view: the fit is yaw aware and a
	# single level would not catch a bad fit at the other yaws
	var clipped := []
	var tiny: Array = []
	for spec in [[1, 0], [7, 0], [7, 90], [30, 0], [68, 0], [120, 45]]:
		gm.camera_rig.cam_yaw = 0.0
		gm.start_level(int(spec[0]))
		if int(spec[1]) != 0:
			gm.rotate_view()
		for _i in range(70):
			await process_frame
		var lo := Vector2(INF, INF)
		var hi := Vector2(-INF, -INF)
		for c in gm.cube_grid._path_cubes:
			var w: Vector3 = c.mesh.global_position
			for corner in [Vector3(-0.5, 0, -0.5), Vector3(0.5, 0, -0.5),
					Vector3(0.5, 0, 0.5), Vector3(-0.5, 0, 0.5)]:
				var p: Vector2 = cam.unproject_position(w + corner)
				if cam.is_position_behind(w + corner) or p.x < 0.0 or p.y < 0.0 \
						or p.x > vp.x or p.y > vp.y:
					clipped.append("L%d yaw%d (%s,%s) px=%s" % [spec[0], spec[1],
						w.x, w.z, str(p.snapped(Vector2(0.1, 0.1)))])
				lo = lo.min(p)
				hi = hi.max(p)
		var span: Vector2 = (hi - lo) / vp
		print("[cam] level ", spec[0], " yaw ", spec[1], " covers ",
			snappedf(span.x * 100.0, 1.0), "% x ", snappedf(span.y * 100.0, 1.0),
			"% dist ", snappedf(gm.camera_rig.cam_distance, 0.1))
		if span.x < 0.4 and span.y < 0.4:
			tiny.append("L%d yaw%d" % [spec[0], spec[1]])
	_check("camera: every path corner stays on screen", clipped.is_empty())
	if not clipped.is_empty():
		printerr("      clipped: ", clipped.slice(0, 4))
	# "stays on screen" is only half the ask; a camera parked at its maximum
	# distance would also pass it, so require the cubes to actually fill the frame
	_check("camera: zoomed in, path fills the frame at every level and yaw", tiny.is_empty())
	if not tiny.is_empty():
		printerr("      too small: ", tiny)
	main.queue_free()
	await process_frame


func _check_paths() -> void:
	var cases: Array = JSON.parse_string(FileAccess.get_file_as_string("res://tests/expected_paths.json"))
	var gen := PathGenerator.new()
	for c in cases:
		var got: Array[Vector2i] = gen.generate(int(c["len"]), int(c["seed"]), float(c["bias"]), int(c["min_turns"]))
		var want: Array = c["path"]
		if got.size() != want.size():
			_fails += 1
			printerr("level ", c["level"], ": length ", got.size(), " != ", want.size())
			continue
		for i in got.size():
			var w: Array = want[i]
			if got[i] != Vector2i(int(w[0]), int(w[1])):
				_fails += 1
				printerr("level ", c["level"], " step ", i, ": ", got[i], " != ", w)
				break


func _check_blocks() -> void:
	var cases: Array = JSON.parse_string(FileAccess.get_file_as_string("res://tests/expected_paths.json"))
	for c in cases:
		var path: Array[Vector2i] = []
		for raw in c["path"]:
			path.append(Vector2i(int(raw[0]), int(raw[1])))
		var bm := BlockManager.new()
		bm.reset()
		bm.assign(path, int(c["seed"]), int(c["level"]))
		var want_types: Array = c["types"]
		if bm.types.size() != want_types.size():
			_fails += 1
			printerr("level ", c["level"], ": block count ", bm.types.size(), " != ", want_types.size())
			continue
		var bad := -1
		for i in want_types.size():
			if bm.types[i] != want_types[i]:
				bad = i
				break
		if bad >= 0:
			_fails += 1
			printerr("level ", c["level"], ": block ", bad, " is ", bm.types[bad], " != ", want_types[bad])
		# decoys are compared relative to path[0]: the JS centre offset is a
		# float shift, ours is rounded, so absolute coords differ by half a cell
		var origin := path[0]
		var want_decoys: Array = c["decoys"]
		if bm.decoys.size() != want_decoys.size():
			_fails += 1
			printerr("level ", c["level"], ": decoy count ", bm.decoys.size(), " != ", want_decoys.size())
			continue
		for i in want_decoys.size():
			var w: Array = want_decoys[i]
			if bm.decoys[i] - origin != Vector2i(int(w[0]), int(w[1])):
				_fails += 1
				printerr("level ", c["level"], ": decoy ", i, " ", bm.decoys[i] - origin, " != ", w)
				break


func _check_gameplay() -> void:
	var scene: PackedScene = load("res://scenes/main.tscn")
	var main: Node = scene.instantiate()
	root.add_child(main)
	await process_frame
	await process_frame

	var gm: GameManager = main.get_node("Game")
	assert(gm != null, "GameManager missing from main.tscn")

	# the tutorial auto-starts on a fresh install, so jump straight to level 2
	gm.stop_tutorial(false)
	gm.is_tutorial = false
	gm.start_level(2)
	await process_frame
	gm.tap_to_start()
	for _i in range(600):
		await process_frame
		if gm.is_playing():
			break
	if not gm.is_playing():
		_fails += 1
		printerr("tap_to_start did not reach playing, state=", gm.state)
		return
	# regression: exponential fog at density 1.0 whites out the scene the moment
	# play begins, so the fog must be linear (three.js Fog near/far)
	var env: EnvironmentBuilder = main.get_node("Environment")
	if not env._env.fog_enabled or env._env.fog_mode != Environment.FOG_MODE_DEPTH:
		_fails += 1
		printerr("fog is not linear: enabled=", env._env.fog_enabled, " mode=", env._env.fog_mode)
	var first := Cfg.dir_between(gm.path[0], gm.path[1])
	var target := gm.path[1]
	gm.handle_move(first)
	for _i in range(120):
		await process_frame
		if not gm.player.is_moving:
			break
	if gm.current_path_index != 1 or gm.player.position.x != float(target.x) or gm.player.position.z != float(target.y):
		_fails += 1
		printerr("step failed: index=", gm.current_path_index, " pos=", gm.player.position, " want=", target)
		return
	# level 2 is pure grass (tier 1 has no ice/fire/tnt), so walking the whole
	# path must end in a win
	while gm.current_path_index < gm.path.size() - 1:
		if not gm.is_playing():
			break
		var step := Cfg.dir_between(gm.path[gm.current_path_index], gm.path[gm.current_path_index + 1])
		gm.handle_move(step)
		for _i in range(240):
			await process_frame
			if not gm.player.is_moving:
				break
		if gm.state == GameManager.State.GAMEOVER:
			break
	if gm.state != GameManager.State.WON:
		_fails += 1
		printerr("walk did not win: state=", gm.state, " index=", gm.current_path_index, "/", gm.path.size() - 1)

	await _check_island(main)
	_check_audio()


## GameAudio.js registers 16 sounds; every one must decode, or the game is
## silent on a device and no other check would notice.
func _check_audio() -> void:
	var missing := []
	for id in Snd.SOUNDS:
		if Snd.stream(id) == null:
			missing.append(id)
	_check("audio: all %d JS sounds load" % Snd.SOUNDS.size(), missing.is_empty())
	if not missing.is_empty():
		printerr("      missing audio: ", missing)
	# hearts and the settings glyphs draw from this ttf, so a font that only loads
	# after an editor import leaves them silently invisible on a fresh checkout
	var f := Art.fa_font()
	_check("ui: FontAwesome loads without an editor import", f != null)
	if f != null:
		var fr := f.get_string_size(Art.fa_text("heart"), HORIZONTAL_ALIGNMENT_LEFT, -1, 20)
		_check("ui: heart glyph has width (font really parsed)",
			fr.x > 1.0 and fr.x < 200.0)

	_check("audio: step-hop ships but is unwired, as in JS",
		FileAccess.file_exists("res://assets/audio/sfx/step-hop.mp3")
		and not Snd.SOUNDS.has("step-hop"))


## The islands now use the real assets from the JS build: the grass tops and
## sides are the shipped grass_top/grass_side textures, every other surface is a
## flat JS colour, and the tree/sign/ruins are where build() puts them.
func _check_island(main: Node) -> void:
	var im: IslandBuilder = main.get_node("World/Islands")
	var gm: GameManager = main.get_node("Game")
	if gm.path.size() > 1:
		im.build(gm.path)
	# the path cubes must carry the shipped block textures, top face included
	var cg: CubeGrid = gm.cube_grid
	if cg._path_cubes.is_empty() and gm.path.size() > 1:
		cg.build_from_path(gm.path, gm.blocks)
	# grass and ice are the two rules that differ, so check the mapping directly
	var gm2 := Art.block_mats(Cfg.T_GRASS)
	_check("block: grass top face uses grass_top.jpg",
		gm2.size() == 2 and gm2[0].albedo_texture == Art.tex("res://assets/texture/grass_top.jpg"))
	_check("block: grass sides use grass_side.jpg",
		gm2.size() == 2 and gm2[1].albedo_texture == Art.tex("res://assets/texture/grass_side.jpg"))
	_check("block: a cube splits top from sides on surface 2", _split_faces(cg))
	var ends: Array[CubeGrid.Cube] = []
	for c in cg._path_cubes:
		if c.is_start or c.is_end:
			ends.append(c)
	_check("block: start/end cubes use their own textures",
		ends.size() == 2 and ends[0].top_mat.albedo_texture == Art.tex("res://assets/texture/start_top.jpg")
		and ends[1].top_mat.albedo_texture == Art.tex("res://assets/texture/end_top.jpg"))
	var ice := Art.block_mats(Cfg.T_ICE)
	_check("block: ice uses ice.jpeg on all faces",
		ice.size() == 2 and ice[0].albedo_texture == Art.tex("res://assets/texture/ice.jpeg")
		and ice[1].albedo_texture == Art.tex("res://assets/texture/ice.jpeg"))
	_check("block: heart has no texture, as in JS", Art.block_mats(Cfg.T_HEART).is_empty())

	# Back-face culling hides a mis-wound face completely, and a cube whose top
	# quad is culled looks exactly like a cube with no top texture.
	var wound := []
	for i in Art.unit_cube().get_surface_count():
		var a := Art.unit_cube().surface_get_arrays(i)
		var vv: PackedVector3Array = a[Mesh.ARRAY_VERTEX]
		var nn: PackedVector3Array = a[Mesh.ARRAY_NORMAL]
		var ii: PackedInt32Array = a[Mesh.ARRAY_INDEX]
		for t in range(0, ii.size(), 3):
			var rh := (vv[ii[t + 1]] - vv[ii[t]]).cross(vv[ii[t + 2]] - vv[ii[t]])
			if rh.dot(nn[ii[t]]) > 0.0:
				wound.append("surface %d tri %d faces inward" % [i, t / 3])
	_check("block: all 6 cube faces are front-facing", wound.is_empty())
	if not wound.is_empty():
		printerr("      culled faces: ", wound)

	# pulseCube() only drives emissiveIntensity and scale, so the start and goal
	# cubes must keep the albedo they were built with, not the pulse colour.
	# the pulse tints nothing, so actually run it and look at the cubes
	cg.start_idle_animations()
	var pulsed := []
	for c3 in cg._path_cubes:
		if (c3.is_start or c3.is_end) and c3.mat.albedo_color != Color.WHITE:
			pulsed.append("%s=%s" % [c3.type, c3.mat.albedo_color])
		if (c3.is_start or c3.is_end) and c3.top_mat != null and c3.top_mat.albedo_color != Color.WHITE:
			pulsed.append("%s top=%s" % [c3.type, c3.top_mat.albedo_color])
	_check("block: start/goal pulses never recolour the cube", pulsed.is_empty())
	if not pulsed.is_empty():
		printerr("      pulsed colours: ", pulsed)

	# Every side quad has to map U along its own horizontal axis. U running up
	# the face is what rotated the grass side texture 90 degrees on the X faces.
	var tilted := []
	for i in [0, 1, 4, 5]:
		var a2 := Art.unit_cube().surface_get_arrays(i)
		var vv2: PackedVector3Array = a2[Mesh.ARRAY_VERTEX]
		var uu: PackedVector2Array = a2[Mesh.ARRAY_TEX_UV]
		# the quad edge that moves in U must be horizontal (no Y change)
		for e in [[0, 1], [1, 2], [2, 3], [3, 0]]:
			var du: float = uu[e[1]].x - uu[e[0]].x
			if is_zero_approx(du):
				continue
			if not is_equal_approx(vv2[e[1]].y, vv2[e[0]].y):
				tilted.append("surface %d edge %d runs U along Y" % [i, e[0]])
	_check("block: side textures are upright on all four sides", tilted.is_empty())
	if not tilted.is_empty():
		printerr("      rotated faces: ", tilted)

	# getTypeMaterial() only sets `map`, so three.js keeps a white diffuse. Any
	# leftover flat colour multiplied on top and muddied the shipped textures.
	var tinted := []
	for t in [Cfg.T_GRASS, Cfg.T_ICE, Cfg.T_FIRE, Cfg.T_TNT, Cfg.T_START, Cfg.T_END]:
		for m in Art.block_mats(t):
			if m.albedo_color != Color.WHITE:
				tinted.append("%s=%s" % [t, m.albedo_color])
	_check("block: textures are untinted (albedo stays white)", tinted.is_empty())
	if not tinted.is_empty():
		printerr("      tinted: ", tinted)

	# retypeCube() installs getTypeMaterial(type) on every face, so the endless
	# goal cube has to get real grass textures back, not just a green albedo
	var last: int = cg._path_cubes.size() - 1
	var c0: CubeGrid.Cube = cg._path_cubes[last]
	_check("block: end cube starts on the end texture",
		c0.top_mat.albedo_texture == Art.tex("res://assets/texture/end_top.jpg"))
	cg.retype_cube(last, Cfg.T_GRASS)
	_check("block: retype swaps in grass textures, not just colour",
		c0.top_mat.albedo_texture == Art.tex("res://assets/texture/grass_top.jpg")
		and c0.mat.albedo_texture == Art.tex("res://assets/texture/grass_side.jpg"))
	# the material objects alone are not enough: the per-face surface overrides
	# are what actually get drawn, so assert those too
	var ov_top := c0.mesh.get_surface_override_material(2)
	var ov_side := c0.mesh.get_surface_override_material(0)
	_check("block: retype repaints the drawn surfaces",
		ov_top != null and ov_side != null and ov_top != ov_side
		and ov_top.albedo_texture == Art.tex("res://assets/texture/grass_top.jpg")
		and ov_side.albedo_texture == Art.tex("res://assets/texture/grass_side.jpg"))

	var grass := im._grass_mat()
	_check("island: grass top uses grass_top.jpg",
		Art.tex("res://assets/texture/grass_top.jpg") != null and grass[0].albedo_texture != null)
	_check("island: grass side uses grass_side.jpg",
		Art.tex("res://assets/texture/grass_side.jpg") != null and grass[1].albedo_texture != null)
	# JS paints island rock/dirt flat, so nothing else may carry a texture
	_check("island: rock is flat JS colour", im._mat(0x9aa8b5).albedo_texture == null)
	_check("island: grass textures are untinted too",
		grass[0].albedo_color == Color.WHITE and grass[1].albedo_color == Color.WHITE)
	_check("island: decor built", im._group.get_child_count() > 100)
	_check("island: start tree built", _count_boxes(im, Vector3(0.5, 1.1, 0.5)) == 1)
	_check("island: sign board built", _count_boxes(im, Vector3(0.62, 0.42, 0.1)) == 1)
	_check("island: end pillars built", _count_boxes(im, Vector3(0.34, 1.5, 0.34)) >= 0)
	# the JS scene has no water at all
	_check("scene: no invented sea", main.get_node("Environment").get_node_or_null("Sea") == null)


## At least one live cube must override surface 2 with a different material
## from its other five faces, which is the whole point of the top/side split.
func _split_faces(cg: CubeGrid) -> bool:
	for c in cg._path_cubes:
		if c.top_mat == null or c.mat == null or c.mesh.mesh == null:
			continue
		if c.top_mat == c.mat:
			continue
		return c.mesh.get_surface_override_material(2) == c.top_mat \
			and c.mesh.get_surface_override_material(0) == c.mat
	return false


## Exact-scale match, within float slop: the JS decor passes literal sizes.
func _count_boxes(im: IslandBuilder, size: Vector3) -> int:
	var n := 0
	for c in im._group.get_children():
		if c is MeshInstance3D:
			var s: Vector3 = (c as MeshInstance3D).scale
			if absf(s.x - size.x) < 0.01 and absf(s.y - size.y) < 0.01 and absf(s.z - size.z) < 0.01:
				n += 1
	return n


func _check_modes() -> void:
	var main: Node = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	root.add_child(main)
	await process_frame
	await process_frame
	var gm: GameManager = main.get_node("Game")
	gm.stop_tutorial(false)
	gm.is_tutorial = false

	# daily: fixed 25-cell path, level 200 tier, no hearts, no skip
	gm.start_daily()
	await process_frame
	if gm.mode != GameManager.Mode.DAILY:
		_fails += 1
		printerr("start_daily did not set daily mode, got ", gm.mode)
	# JS generate(25) returns 26 cells: it starts at startPos then steps 25 times
	if gm.path.size() != 26:
		_fails += 1
		printerr("daily path length is ", gm.path.size(), ", want 26")
	Save.mark_daily_complete()

	# endless: three segments must all place a fresh, non-overlapping island and
	# append rather than restart the path
	gm.start_endless()
	await process_frame
	var lengths: Array[int] = [gm.path.size()]
	var island_counts: Array[int] = [gm.island_builder.islands.size()]
	for _i in range(2):
		if gm.state != GameManager.State.SHOWING:
			_fails += 1
			printerr("endless segment not in showing state, got ", gm.state)
			break
		gm._endless_complete()
		for _j in range(60):
			await process_frame
		lengths.append(gm.path.size())
		island_counts.append(gm.island_builder.islands.size())
		if gm.state != GameManager.State.SHOWING:
			# the segment wave is still running; wait it out
			for _k in range(400):
				await process_frame
			if gm.state != GameManager.State.SHOWING:
				break
	if gm.run_streak < 2:
		_fails += 1
		printerr("endless streak only reached ", gm.run_streak)
	for i in range(1, lengths.size()):
		if lengths[i] <= lengths[i - 1]:
			_fails += 1
			printerr("endless segment ", i, " did not grow the path: ", lengths[i - 1], " -> ", lengths[i])
		if island_counts[i] != island_counts[i - 1] + 1:
			_fails += 1
			printerr("endless segment ", i, " islands ", island_counts[i - 1], " -> ", island_counts[i])
	if Save.best_endless() < 1:
		_fails += 1
		printerr("best endless score not saved, got ", Save.best_endless())
	main.queue_free()