extends SceneTree

## Self-check: run with
##   godot --headless --path . --script res://tests/check.gd
##
## 1. Path generation must match the JS output byte for byte (tests/expected_paths.json
##    is produced by running the original PathGenerator.js under node).
## 2. A booted level must accept a step and advance the player by exactly one cell.
## 3. Endless appends segments without overlapping old islands, and the daily
##    level matches its fixed setup.

var _fails := 0


func _check(label: String, ok: bool) -> void:
	if ok:
		print("  ok  ", label)
	else:
		_fails += 1
		printerr("  FAIL ", label)


func _initialize() -> void:
	# the boot flow writes user:// state; start from a clean slate so the menu
	# routing and the tutorial auto-start are deterministic
	Save.reset_progress()
	_check_paths()
	_check_blocks()
	await _check_gameplay()
	await _check_modes()
	if _fails == 0:
		print("PASS: path + block parity, full walk to win, mode setup, real-asset islands, audio")
	else:
		printerr("FAIL: ", _fails, " check(s)")
	quit(1 if _fails else 0)


func _check_paths() -> void:
	var cases: Array = JSON.parse_string(FileAccess.get_file_as_string("res://tests/expected_paths.json"))
	var gen := PathGenerator.new()
	for c in cases:
		var got: Array[Vector2i] = gen.generate(int(c["len"]), int(c["seed"]), float(c["bias"]), int(c["min_turns"]))
		var want: Array = c["path"]
		if got.size() != want.size():
			_fails += 1
			printerr("level ", c["level"], ": length ", got.size(), " != ", want.size())
			continue
		for i in got.size():
			var w: Array = want[i]
			if got[i] != Vector2i(int(w[0]), int(w[1])):
				_fails += 1
				printerr("level ", c["level"], " step ", i, ": ", got[i], " != ", w)
				break


func _check_blocks() -> void:
	var cases: Array = JSON.parse_string(FileAccess.get_file_as_string("res://tests/expected_paths.json"))
	for c in cases:
		var path: Array[Vector2i] = []
		for raw in c["path"]:
			path.append(Vector2i(int(raw[0]), int(raw[1])))
		var bm := BlockManager.new()
		bm.reset()
		bm.assign(path, int(c["seed"]), int(c["level"]))
		var want_types: Array = c["types"]
		if bm.types.size() != want_types.size():
			_fails += 1
			printerr("level ", c["level"], ": block count ", bm.types.size(), " != ", want_types.size())
			continue
		var bad := -1
		for i in want_types.size():
			if bm.types[i] != want_types[i]:
				bad = i
				break
		if bad >= 0:
			_fails += 1
			printerr("level ", c["level"], ": block ", bad, " is ", bm.types[bad], " != ", want_types[bad])
		# decoys are compared relative to path[0]: the JS centre offset is a
		# float shift, ours is rounded, so absolute coords differ by half a cell
		var origin := path[0]
		var want_decoys: Array = c["decoys"]
		if bm.decoys.size() != want_decoys.size():
			_fails += 1
			printerr("level ", c["level"], ": decoy count ", bm.decoys.size(), " != ", want_decoys.size())
			continue
		for i in want_decoys.size():
			var w: Array = want_decoys[i]
			if bm.decoys[i] - origin != Vector2i(int(w[0]), int(w[1])):
				_fails += 1
				printerr("level ", c["level"], ": decoy ", i, " ", bm.decoys[i] - origin, " != ", w)
				break


func _check_gameplay() -> void:
	var scene: PackedScene = load("res://scenes/main.tscn")
	var main: Node = scene.instantiate()
	root.add_child(main)
	await process_frame
	await process_frame

	var gm: GameManager = main.get_node("Game")
	assert(gm != null, "GameManager missing from main.tscn")

	# the tutorial auto-starts on a fresh install, so jump straight to level 2
	gm.stop_tutorial(false)
	gm.is_tutorial = false
	gm.start_level(2)
	await process_frame
	gm.tap_to_start()
	for _i in range(600):
		await process_frame
		if gm.is_playing():
			break
	if not gm.is_playing():
		_fails += 1
		printerr("tap_to_start did not reach playing, state=", gm.state)
		return
	# regression: exponential fog at density 1.0 whites out the scene the moment
	# play begins, so the fog must be linear (three.js Fog near/far)
	var env: EnvironmentBuilder = main.get_node("Environment")
	if not env._env.fog_enabled or env._env.fog_mode != Environment.FOG_MODE_DEPTH:
		_fails += 1
		printerr("fog is not linear: enabled=", env._env.fog_enabled, " mode=", env._env.fog_mode)
	var first := Cfg.dir_between(gm.path[0], gm.path[1])
	var target := gm.path[1]
	gm.handle_move(first)
	for _i in range(120):
		await process_frame
		if not gm.player.is_moving:
			break
	if gm.current_path_index != 1 or gm.player.position.x != float(target.x) or gm.player.position.z != float(target.y):
		_fails += 1
		printerr("step failed: index=", gm.current_path_index, " pos=", gm.player.position, " want=", target)
		return
	# level 2 is pure grass (tier 1 has no ice/fire/tnt), so walking the whole
	# path must end in a win
	while gm.current_path_index < gm.path.size() - 1:
		if not gm.is_playing():
			break
		var step := Cfg.dir_between(gm.path[gm.current_path_index], gm.path[gm.current_path_index + 1])
		gm.handle_move(step)
		for _i in range(240):
			await process_frame
			if not gm.player.is_moving:
				break
		if gm.state == GameManager.State.GAMEOVER:
			break
	if gm.state != GameManager.State.WON:
		_fails += 1
		printerr("walk did not win: state=", gm.state, " index=", gm.current_path_index, "/", gm.path.size() - 1)

	await _check_island(main)
	_check_audio()


## GameAudio.js registers 16 sounds; every one must decode, or the game is
## silent on a device and no other check would notice.
func _check_audio() -> void:
	var missing := []
	for id in Snd.SOUNDS:
		if Snd.stream(id) == null:
			missing.append(id)
	_check("audio: all %d JS sounds load" % Snd.SOUNDS.size(), missing.is_empty())
	if not missing.is_empty():
		printerr("      missing audio: ", missing)
	# hearts and the settings glyphs draw from this ttf, so a font that only loads
	# after an editor import leaves them silently invisible on a fresh checkout
	var f := Art.fa_font()
	_check("ui: FontAwesome loads without an editor import", f != null)
	if f != null:
		var fr := f.get_string_size(Art.fa_text("heart"), HORIZONTAL_ALIGNMENT_LEFT, -1, 20)
		_check("ui: heart glyph has width (font really parsed)",
			fr.x > 1.0 and fr.x < 200.0)

	_check("audio: step-hop ships but is unwired, as in JS",
		FileAccess.file_exists("res://assets/audio/sfx/step-hop.mp3")
		and not Snd.SOUNDS.has("step-hop"))


## The islands now use the real assets from the JS build: the grass tops and
## sides are the shipped grass_top/grass_side textures, every other surface is a
## flat JS colour, and the tree/sign/ruins are where build() puts them.
func _check_island(main: Node) -> void:
	var im: IslandBuilder = main.get_node("World/Islands")
	var gm: GameManager = main.get_node("Game")
	if gm.path.size() > 1:
		im.build(gm.path)
	# the path cubes must carry the shipped block textures, top face included
	var cg: CubeGrid = gm.cube_grid
	if cg._path_cubes.is_empty() and gm.path.size() > 1:
		cg.build_from_path(gm.path, gm.blocks)
	# grass and ice are the two rules that differ, so check the mapping directly
	var gm2 := Art.block_mats(Cfg.T_GRASS)
	_check("block: grass top face uses grass_top.jpg",
		gm2.size() == 2 and gm2[0].albedo_texture == Art.tex("res://assets/texture/grass_top.jpg"))
	_check("block: grass sides use grass_side.jpg",
		gm2.size() == 2 and gm2[1].albedo_texture == Art.tex("res://assets/texture/grass_side.jpg"))
	_check("block: a cube splits top from sides on surface 2", _split_faces(cg))
	var ends: Array[CubeGrid.Cube] = []
	for c in cg._path_cubes:
		if c.is_start or c.is_end:
			ends.append(c)
	_check("block: start/end cubes use their own textures",
		ends.size() == 2 and ends[0].top_mat.albedo_texture == Art.tex("res://assets/texture/start_top.jpg")
		and ends[1].top_mat.albedo_texture == Art.tex("res://assets/texture/end_top.jpg"))
	var ice := Art.block_mats(Cfg.T_ICE)
	_check("block: ice uses ice.jpeg on all faces",
		ice.size() == 2 and ice[0].albedo_texture == Art.tex("res://assets/texture/ice.jpeg")
		and ice[1].albedo_texture == Art.tex("res://assets/texture/ice.jpeg"))
	_check("block: heart has no texture, as in JS", Art.block_mats(Cfg.T_HEART).is_empty())

	var grass := im._grass_mat()
	_check("island: grass top uses grass_top.jpg",
		Art.tex("res://assets/texture/grass_top.jpg") != null and grass[0].albedo_texture != null)
	_check("island: grass side uses grass_side.jpg",
		Art.tex("res://assets/texture/grass_side.jpg") != null and grass[1].albedo_texture != null)
	# JS paints island rock/dirt flat, so nothing else may carry a texture
	_check("island: rock is flat JS colour", im._mat(0x9aa8b5).albedo_texture == null)
	_check("island: decor built", im._group.get_child_count() > 100)
	_check("island: start tree built", _count_boxes(im, Vector3(0.5, 1.1, 0.5)) == 1)
	_check("island: sign board built", _count_boxes(im, Vector3(0.62, 0.42, 0.1)) == 1)
	_check("island: end pillars built", _count_boxes(im, Vector3(0.34, 1.5, 0.34)) >= 0)
	# the JS scene has no water at all
	_check("scene: no invented sea", main.get_node("Environment").get_node_or_null("Sea") == null)


## At least one live cube must override surface 2 with a different material
## from its other five faces, which is the whole point of the top/side split.
func _split_faces(cg: CubeGrid) -> bool:
	for c in cg._path_cubes:
		if c.top_mat == null or c.mat == null or c.mesh.mesh == null:
			continue
		if c.top_mat == c.mat:
			continue
		return c.mesh.get_surface_override_material(2) == c.top_mat \
			and c.mesh.get_surface_override_material(0) == c.mat
	return false


## Exact-scale match, within float slop: the JS decor passes literal sizes.
func _count_boxes(im: IslandBuilder, size: Vector3) -> int:
	var n := 0
	for c in im._group.get_children():
		if c is MeshInstance3D:
			var s: Vector3 = (c as MeshInstance3D).scale
			if absf(s.x - size.x) < 0.01 and absf(s.y - size.y) < 0.01 and absf(s.z - size.z) < 0.01:
				n += 1
	return n


func _check_modes() -> void:
	var main: Node = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	root.add_child(main)
	await process_frame
	await process_frame
	var gm: GameManager = main.get_node("Game")
	gm.stop_tutorial(false)
	gm.is_tutorial = false

	# daily: fixed 25-cell path, level 200 tier, no hearts, no skip
	gm.start_daily()
	await process_frame
	if gm.mode != GameManager.Mode.DAILY:
		_fails += 1
		printerr("start_daily did not set daily mode, got ", gm.mode)
	# JS generate(25) returns 26 cells: it starts at startPos then steps 25 times
	if gm.path.size() != 26:
		_fails += 1
		printerr("daily path length is ", gm.path.size(), ", want 26")
	Save.mark_daily_complete()

	# endless: three segments must all place a fresh, non-overlapping island and
	# append rather than restart the path
	gm.start_endless()
	await process_frame
	var lengths: Array[int] = [gm.path.size()]
	var island_counts: Array[int] = [gm.island_builder.islands.size()]
	for _i in range(2):
		if gm.state != GameManager.State.SHOWING:
			_fails += 1
			printerr("endless segment not in showing state, got ", gm.state)
			break
		gm._endless_complete()
		for _j in range(60):
			await process_frame
		lengths.append(gm.path.size())
		island_counts.append(gm.island_builder.islands.size())
		if gm.state != GameManager.State.SHOWING:
			# the segment wave is still running; wait it out
			for _k in range(400):
				await process_frame
			if gm.state != GameManager.State.SHOWING:
				break
	if gm.run_streak < 2:
		_fails += 1
		printerr("endless streak only reached ", gm.run_streak)
	for i in range(1, lengths.size()):
		if lengths[i] <= lengths[i - 1]:
			_fails += 1
			printerr("endless segment ", i, " did not grow the path: ", lengths[i - 1], " -> ", lengths[i])
		if island_counts[i] != island_counts[i - 1] + 1:
			_fails += 1
			printerr("endless segment ", i, " islands ", island_counts[i - 1], " -> ", island_counts[i])
	if Save.best_endless() < 1:
		_fails += 1
		printerr("best endless score not saved, got ", Save.best_endless())
	main.queue_free()