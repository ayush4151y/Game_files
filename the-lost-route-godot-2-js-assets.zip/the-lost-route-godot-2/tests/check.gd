extends SceneTree

## Self-check: run with
##   godot --headless --path . --script res://tests/check.gd
##
## 1. Path generation must match the JS output byte for byte (tests/expected_paths.json
##    is produced by running the original PathGenerator.js under node).
## 2. A booted level must accept a step and advance the player by exactly one cell.
## 3. Endless appends segments without overlapping old islands, and the daily
##    level matches its fixed setup.

var _fails := 0


func _check(label: String, ok: bool) -> void:
	if ok:
		print("  ok  ", label)
	else:
		_fails += 1
		printerr("  FAIL ", label)


func _initialize() -> void:
	# the boot flow writes user:// state; start from a clean slate so the menu
	# routing and the tutorial auto-start are deterministic
	Save.reset_progress()
	_check_ads_and_hints()
	_check_paths()
	_check_blocks()
	await _check_gameplay()
	await _check_modes()
	await _check_camera_fits()
	if _fails == 0:
		print("PASS: path + block parity, full walk to win, mode setup, real-asset islands, audio")
	else:
		printerr("FAIL: ", _fails, " check(s)")
	quit(1 if _fails else 0)


## Ads fall back to an instant grant without the native plugin, the free-hint
## counter is a lifetime 3 that resets with progress, and the preset is wired
## for ads (internet + gradle build).
func _check_ads_and_hints() -> void:
	var got := [null]
	Ads.show_rewarded(func(ok: bool) -> void: got[0] = ok)
	_check("ads: rewarded grants immediately without the native plugin", got[0] == true)
	Ads.set_banner_visible(true)
	Ads.set_banner_visible(false)
	_check("ads: banner calls are no-ops without the native plugin", true)
	_check("ads: starts with 3 free hints", Save.free_hints() == 3)
	Save.use_free_hint()
	Save.use_free_hint()
	_check("ads: free hints decrement", Save.free_hints() == 1)
	Save.reset_progress()
	_check("ads: reset restores the 3 free hints", Save.free_hints() == 3)

	var cfg := ConfigFile.new()
	var err := cfg.load("res://export_presets.cfg")
	_check("export: presets load", err == OK)
	if err == OK:
		var opts := "preset.0.options"
		_check(
			"export: internet permission on (ads)",
			bool(cfg.get_value(opts, "permissions/internet", false))
		)
		_check(
			"export: gradle build on (AdMob plugin)",
			bool(cfg.get_value(opts, "gradle_build/use_gradle_build", false))
		)


## The camera is zoomed in, so the whole framed path has to stay on screen.
## Unprojecting the real cube corners is the same check a player would make by
## looking, and it is what stops a tighter CAM_SCREEN_FILL from clipping a level.
func _check_camera_fits() -> void:
	var main: Node = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	root.add_child(main)
	for _i in range(8):
		await process_frame
	var gm: GameManager = main.get_node("Game")
	gm.start_level(7)
	# the rig frames the path over a tween, so let it land before measuring
	for _i in range(90):
		await process_frame
	var cam: Camera3D = gm.camera_rig.camera
	if cam == null or not cam.is_inside_tree():
		_check("camera: every path corner stays on screen", false)
		printerr("      no camera in the tree")
		main.queue_free()
		await process_frame
		return
	var vp: Vector2 = cam.get_viewport().get_visible_rect().size
	# short, medium and long, plus a rotated view: the fit is yaw aware and a
	# single level would not catch a bad fit at the other yaws
	var clipped := []
	var tiny: Array = []
	for spec in [[1, 0], [7, 0], [7, 90], [30, 0], [68, 0], [120, 45]]:
		gm.camera_rig.cam_yaw = 0.0
		gm.start_level(int(spec[0]))
		if int(spec[1]) != 0:
			gm.rotate_view()
		for _i in range(70):
			await process_frame
		var lo := Vector2(INF, INF)
		var hi := Vector2(-INF, -INF)
		for c in gm.cube_grid._path_cubes:
			var w: Vector3 = c.mesh.global_position
			for corner in [Vector3(-0.5, 0, -0.5), Vector3(0.5, 0, -0.5),
					Vector3(0.5, 0, 0.5), Vector3(-0.5, 0, 0.5)]:
				var p: Vector2 = cam.unproject_position(w + corner)
				if cam.is_position_behind(w + corner) or p.x < 0.0 or p.y < 0.0 \
						or p.x > vp.x or p.y > vp.y:
					clipped.append("L%d yaw%d (%s,%s) px=%s" % [spec[0], spec[1],
						w.x, w.z, str(p.snapped(Vector2(0.1, 0.1)))])
				lo = lo.min(p)
				hi = hi.max(p)
		var span: Vector2 = (hi - lo) / vp
		print("[cam] level ", spec[0], " yaw ", spec[1], " covers ",
			snappedf(span.x * 100.0, 1.0), "% x ", snappedf(span.y * 100.0, 1.0),
			"% dist ", snappedf(gm.camera_rig.cam_distance, 0.1))
		if span.x < 0.4 and span.y < 0.4:
			tiny.append("L%d yaw%d" % [spec[0], spec[1]])
	_check("camera: every path corner stays on screen", clipped.is_empty())
	if not clipped.is_empty():
		printerr("      clipped: ", clipped.slice(0, 4))
	# "stays on screen" is only half the ask; a camera parked at its maximum
	# distance would also pass it, so require the cubes to actually fill the frame
	_check("camera: zoomed in, path fills the frame at every level and yaw", tiny.is_empty())
	if not tiny.is_empty():
		printerr("      too small: ", tiny)
	main.queue_free()
	await process_frame


func _check_paths() -> void:
	var cases: Array = JSON.parse_string(FileAccess.get_file_as_string("res://tests/expected_paths.json"))
	var gen := PathGenerator.new()
	for c in cases:
		var got: Array[Vector2i] = gen.generate(int(c["len"]), int(c["seed"]), float(c["bias"]), int(c["min_turns"]))
		var want: Array = c["path"]
		if got.size() != want.size():
			_fails += 1
			printerr("level ", c["level"], ": length ", got.size(), " != ", want.size())
			continue
		for i in got.size():
			var w: Array = want[i]
			if got[i] != Vector2i(int(w[0]), int(w[1])):
				_fails += 1
				printerr("level ", c["level"], " step ", i, ": ", got[i], " != ", w)
				break


func _check_blocks() -> void:
	var cases: Array = JSON.parse_string(FileAccess.get_file_as_string("res://tests/expected_paths.json"))
	for c in cases:
		var path: Array[Vector2i] = []
		for raw in c["path"]:
			path.append(Vector2i(int(raw[0]), int(raw[1])))
		var bm := BlockManager.new()
		bm.reset()
		bm.assign(path, int(c["seed"]), int(c["level"]))
		var want_types: Array = c["types"]
		if bm.types.size() != want_types.size():
			_fails += 1
			printerr("level ", c["level"], ": block count ", bm.types.size(), " != ", want_types.size())
			continue
		var bad := -1
		for i in want_types.size():
			if bm.types[i] != want_types[i]:
				bad = i
				break
		if bad >= 0:
			_fails += 1
			printerr("level ", c["level"], ": block ", bad, " is ", bm.types[bad], " != ", want_types[bad])
		# decoys are compared relative to path[0]: the JS centre offset is a
		# float shift, ours is rounded, so absolute coords differ by half a cell
		var origin := path[0]
		var want_decoys: Array = c["decoys"]
		if bm.decoys.size() != want_decoys.size():
			_fails += 1
			printerr("level ", c["level"], ": decoy count ", bm.decoys.size(), " != ", want_decoys.size())
			continue
		for i in want_decoys.size():
			var w: Array = want_decoys[i]
			if bm.decoys[i] - origin != Vector2i(int(w[0]), int(w[1])):
				_fails += 1
				printerr("level ", c["level"], ": decoy ", i, " ", bm.decoys[i] - origin, " != ", w)
				break


func _check_gameplay() -> void:
	var scene: PackedScene = load("res://scenes/main.tscn")
	var main: Node = scene.instantiate()
	root.add_child(main)
	await process_frame
	await process_frame

	var gm: GameManager = main.get_node("Game")
	assert(gm != null, "GameManager missing from main.tscn")

	# the tutorial auto-starts on a fresh install, so jump straight to level 2
	gm.stop_tutorial(false)
	gm.is_tutorial = false
	gm.start_level(2)
	await process_frame
	# the skip button is now a "skip reveal" control while the path is showing;
# pressing it must snap the whole path up and raise the tap overlay, NOT sink
	_check("ui: skip is offered while the path is showing",
		(gm.ui._skip_btn as Button).visible)
	(gm.ui._skip_btn as Button).pressed.emit()
	await process_frame
	var shown := 0
	for c in gm.cube_grid._path_cubes:
		if c.mesh.visible and not c.hidden:
			shown += 1
	_check("ui: skip_reveal snaps every path cube up",
		shown == gm.cube_grid._path_cubes.size())
	_check("ui: skip_reveal raises the tap overlay",
		gm.ui._tap_overlay.visible)
	gm.tap_to_start()
	for _i in range(600):
		await process_frame
		if gm.is_playing():
			break
	if not gm.is_playing():
		_fails += 1
		printerr("tap_to_start did not reach playing, state=", gm.state)
		return
	_check_hud(gm)
	# regression: exponential fog at density 1.0 whites out the scene the moment
	# play begins, so the fog must be linear (three.js Fog near/far)
	var env: EnvironmentBuilder = main.get_node("Environment")
	if not env._env.fog_enabled or env._env.fog_mode != Environment.FOG_MODE_DEPTH:
		_fails += 1
		printerr("fog is not linear: enabled=", env._env.fog_enabled, " mode=", env._env.fog_mode)
	# regression: Godot's fog_sky_affect defaults to 1.0, so turning fog on at
	# game start bleached the painted sky to flat pale grey (the "white bg"
	# after tap). The sky must be exempt from fog.
	if env._env.fog_sky_affect != 0.0:
		_fails += 1
		printerr("fog bleaches the sky: fog_sky_affect=", env._env.fog_sky_affect)
	var first := Cfg.dir_between(gm.path[0], gm.path[1])
	var target := gm.path[1]
	gm.handle_move(first)
	for _i in range(120):
		await process_frame
		if not gm.player.is_moving:
			break
	if gm.current_path_index != 1 or gm.player.position.x != float(target.x) or gm.player.position.z != float(target.y):
		_fails += 1
		printerr("step failed: index=", gm.current_path_index, " pos=", gm.player.position, " want=", target)
		return
	# level 2 is pure grass (tier 1 has no ice/fire/tnt), so walking the whole
	# path must end in a win
	while gm.current_path_index < gm.path.size() - 1:
		if not gm.is_playing():
			break
		var step := Cfg.dir_between(gm.path[gm.current_path_index], gm.path[gm.current_path_index + 1])
		gm.handle_move(step)
		for _i in range(240):
			await process_frame
			if not gm.player.is_moving:
				break
		if gm.state == GameManager.State.GAMEOVER:
			break
	if gm.state != GameManager.State.WON:
		_fails += 1
		printerr("walk did not win: state=", gm.state, " index=", gm.current_path_index, "/", gm.path.size() - 1)
	elif gm.cube_grid.get_node_or_null("WinBurst") == null:
		_fails += 1
		printerr("win has no confetti burst on the end block")
	elif (gm.cube_grid.get_node_or_null("WinBurst") as GPUParticles3D).draw_pass_1 == null:
		_fails += 1
		printerr("win burst has no draw mesh, renders nothing")

	await _check_island(main)
	_check_audio()


## Everything the HUD is supposed to do the instant the path disappears:
## the actions arrive, the level number sits over the hearts clear of the pause
## button, and the goal cube is no longer glowing red.
func _check_hud(gm: GameManager) -> void:
	var ui: UI = gm.ui
	_check("ui: skip appears once the path is gone",
		(ui._skip_btn as Button).visible)
	_check("ui: hint and camera appear with it",
		(ui._hint_btn as Button).visible and (ui._rotate_btn as Button).visible)
	var pill: Control = ui._level_pill
	var box: Control = ui._heart_box
	_check("ui: level number sits above the hearts with a gap",
		box.offset_top >= pill.offset_bottom + 8.0)
	_check("ui: level number clears the pause button",
		pill.offset_left >= (ui._pause_btn as Button).offset_right)
	var red := false
	for c in gm.cube_grid._path_cubes:
		if c.is_end and c.mat.emission.r > c.mat.emission.g + 0.1:
			red = true
	_check("ui: goal cube is not left red after the path hides", not red)


## Every registered sound must decode, or the game is silent on a device and no
## other check would notice. ui-back/ui-toggle stay out: back and pause share
## ui-pause and every other button shares ui-click.
func _check_audio() -> void:
	var missing := []
	for id in Snd.SOUNDS:
		if Snd.stream(id) == null:
			missing.append(id)
	_check("audio: all %d registered sounds load" % Snd.SOUNDS.size(), missing.is_empty())
	if not missing.is_empty():
		printerr("      missing audio: ", missing)
	_check("audio: ui-back and ui-toggle stay unmapped",
		not Snd.SOUNDS.has("ui-back") and not Snd.SOUNDS.has("ui-toggle")
		and Snd.SOUNDS.has("ui-click") and Snd.SOUNDS.has("ui-pause"))
	# regression: the ambience MP3s are mastered quiet (peak nearly at 0 dB), so
	# a plain volume raise would clip - the bus must carry the boost limiter, and
	# the two loops ride the same bus so they scale proportionally
	Snd._buses_ready()
	var a_idx := AudioServer.get_bus_index("ambience")
	var boosted := false
	if a_idx != -1:
		for i in AudioServer.get_bus_effect_count(a_idx):
			var fx := AudioServer.get_bus_effect(a_idx, i)
			if fx is AudioEffectHardLimiter and fx.pre_gain_db >= Snd.MUSIC_BOOST_DB - 0.01 and fx.ceiling_db <= -0.9:
				boosted = true
	_check("audio: music bus carries the boost limiter", boosted)
	_check("audio: ui-back and ui-toggle files are gone",
		not FileAccess.file_exists("res://assets/audio/ui/ui-back.mp3")
		and not FileAccess.file_exists("res://assets/audio/ui/ui-toggle.mp3"))
	# hearts and the settings glyphs draw from this ttf, so a font that only loads
	# after an editor import leaves them silently invisible on a fresh checkout
	var f := Art.fa_font()
	_check("ui: FontAwesome loads without an editor import", f != null)
	if f != null:
		var fr := f.get_string_size(Art.fa_text("heart"), HORIZONTAL_ALIGNMENT_LEFT, -1, 20)
		_check("ui: heart glyph has width (font really parsed)",
			fr.x > 1.0 and fr.x < 200.0)

	_check("audio: step-hop ships but is unwired, as in JS",
		FileAccess.file_exists("res://assets/audio/sfx/step-hop.mp3")
		and not Snd.SOUNDS.has("step-hop"))


## The islands now use the real assets from the JS build: the grass tops and
## sides are the shipped grass_top/grass_side textures, every other surface is a
## flat JS colour, and the tree/sign/ruins are where build() puts them.
func _check_island(main: Node) -> void:
	var im: IslandBuilder = main.get_node("World/Islands")
	var gm: GameManager = main.get_node("Game")
	if gm.path.size() > 1:
		im.build(gm.path)
	# the path cubes must carry the shipped block textures, top face included
	var cg: CubeGrid = gm.cube_grid
	if cg._path_cubes.is_empty() and gm.path.size() > 1:
		cg.build_from_path(gm.path, gm.blocks)
	# grass and ice are the two rules that differ, so check the mapping directly
	var gm2 := Art.block_mats(Cfg.T_GRASS)
	_check("block: grass top face uses grass_top.jpg",
		gm2.size() == 2 and gm2[0].albedo_texture == Art.tex("res://assets/texture/grass_top.jpg"))
	_check("block: grass sides use grass_side.jpg",
		gm2.size() == 2 and gm2[1].albedo_texture == Art.tex("res://assets/texture/grass_side.jpg"))
	_check("block: a cube splits top from sides on surface 2", _split_faces(cg))
	var ends: Array[CubeGrid.Cube] = []
	for c in cg._path_cubes:
		if c.is_start or c.is_end:
			ends.append(c)
	_check("block: start/end cubes use their own textures",
		ends.size() == 2 and ends[0].top_mat.albedo_texture == Art.tex("res://assets/texture/start_top.jpg")
		and ends[1].top_mat.albedo_texture == Art.tex("res://assets/texture/end_top.jpg"))
	var ice := Art.block_mats(Cfg.T_ICE)
	_check("block: ice uses ice.jpeg on all faces",
		ice.size() == 2 and ice[0].albedo_texture == Art.tex("res://assets/texture/ice.jpeg")
		and ice[1].albedo_texture == Art.tex("res://assets/texture/ice.jpeg"))
	_check("block: heart has no texture, as in JS", Art.block_mats(Cfg.T_HEART).is_empty())

	# Back-face culling hides a mis-wound face completely, and a cube whose top
	# quad is culled looks exactly like a cube with no top texture.
	var wound := []
	for i in Art.unit_cube().get_surface_count():
		var a := Art.unit_cube().surface_get_arrays(i)
		var vv: PackedVector3Array = a[Mesh.ARRAY_VERTEX]
		var nn: PackedVector3Array = a[Mesh.ARRAY_NORMAL]
		var ii: PackedInt32Array = a[Mesh.ARRAY_INDEX]
		for t in range(0, ii.size(), 3):
			var rh := (vv[ii[t + 1]] - vv[ii[t]]).cross(vv[ii[t + 2]] - vv[ii[t]])
			if rh.dot(nn[ii[t]]) > 0.0:
				wound.append("surface %d tri %d faces inward" % [i, t / 3])
	_check("block: all 6 cube faces are front-facing", wound.is_empty())
	if not wound.is_empty():
		printerr("      culled faces: ", wound)

	# pulseCube() only drives emissiveIntensity and scale, so the start and goal
	# cubes must keep the albedo they were built with, not the pulse colour.
	# the pulse tints nothing, so actually run it and look at the cubes
	cg.start_idle_animations()
	var pulsed := []
	for c3 in cg._path_cubes:
		if (c3.is_start or c3.is_end) and c3.mat.albedo_color != Color.WHITE:
			pulsed.append("%s=%s" % [c3.type, c3.mat.albedo_color])
		if (c3.is_start or c3.is_end) and c3.top_mat != null and c3.top_mat.albedo_color != Color.WHITE:
			pulsed.append("%s top=%s" % [c3.type, c3.top_mat.albedo_color])
	_check("block: start/goal pulses never recolour the cube", pulsed.is_empty())
	if not pulsed.is_empty():
		printerr("      pulsed colours: ", pulsed)

	# Every side quad has to map U along its own horizontal axis. U running up
	# the face is what rotated the grass side texture 90 degrees on the X faces.
	var tilted := []
	for i in [0, 1, 4, 5]:
		var a2 := Art.unit_cube().surface_get_arrays(i)
		var vv2: PackedVector3Array = a2[Mesh.ARRAY_VERTEX]
		var uu: PackedVector2Array = a2[Mesh.ARRAY_TEX_UV]
		# the quad edge that moves in U must be horizontal (no Y change)
		for e in [[0, 1], [1, 2], [2, 3], [3, 0]]:
			var du: float = uu[e[1]].x - uu[e[0]].x
			if is_zero_approx(du):
				continue
			if not is_equal_approx(vv2[e[1]].y, vv2[e[0]].y):
				tilted.append("surface %d edge %d runs U along Y" % [i, e[0]])
	_check("block: side textures are upright on all four sides", tilted.is_empty())
	if not tilted.is_empty():
		printerr("      rotated faces: ", tilted)

	# getTypeMaterial() only sets `map`, so three.js keeps a white diffuse. Any
	# leftover flat colour multiplied on top and muddied the shipped textures.
	var tinted := []
	for t in [Cfg.T_GRASS, Cfg.T_ICE, Cfg.T_FIRE, Cfg.T_TNT, Cfg.T_START, Cfg.T_END]:
		for m in Art.block_mats(t):
			if m.albedo_color != Color.WHITE:
				tinted.append("%s=%s" % [t, m.albedo_color])
	_check("block: textures are untinted (albedo stays white)", tinted.is_empty())
	if not tinted.is_empty():
		printerr("      tinted: ", tinted)

	# retypeCube() installs getTypeMaterial(type) on every face, so the endless
	# goal cube has to get real grass textures back, not just a green albedo
	var last: int = cg._path_cubes.size() - 1
	var c0: CubeGrid.Cube = cg._path_cubes[last]
	_check("block: end cube starts on the end texture",
		c0.top_mat.albedo_texture == Art.tex("res://assets/texture/end_top.jpg"))
	cg.retype_cube(last, Cfg.T_GRASS)
	_check("block: retype swaps in grass textures, not just colour",
		c0.top_mat.albedo_texture == Art.tex("res://assets/texture/grass_top.jpg")
		and c0.mat.albedo_texture == Art.tex("res://assets/texture/grass_side.jpg"))
	# the material objects alone are not enough: the per-face surface overrides
	# are what actually get drawn, so assert those too
	var ov_top := c0.mesh.get_surface_override_material(2)
	var ov_side := c0.mesh.get_surface_override_material(0)
	_check("block: retype repaints the drawn surfaces",
		ov_top != null and ov_side != null and ov_top != ov_side
		and ov_top.albedo_texture == Art.tex("res://assets/texture/grass_top.jpg")
		and ov_side.albedo_texture == Art.tex("res://assets/texture/grass_side.jpg"))

	var grass := im._grass_mat()
	_check("island: grass top uses grass_top.jpg",
		Art.tex("res://assets/texture/grass_top.jpg") != null and grass[0].albedo_texture != null)
	_check("island: grass side uses grass_side.jpg",
		Art.tex("res://assets/texture/grass_side.jpg") != null and grass[1].albedo_texture != null)
	# JS paints island rock/dirt flat, so nothing else may carry a texture
	_check("island: rock is flat JS colour", im._mat(0x9aa8b5).albedo_texture == null)
	_check("island: grass textures are untinted too",
		grass[0].albedo_color == Color.WHITE and grass[1].albedo_color == Color.WHITE)
	_check("island: decor built", im._group.get_child_count() > 100)
	_check("island: start tree built", _count_boxes(im, Vector3(0.5, 1.1, 0.5)) == 1)
	_check("island: sign board built", _count_boxes(im, Vector3(0.62, 0.42, 0.1)) == 1)
	_check("island: end pillars built", _count_boxes(im, Vector3(0.34, 1.5, 0.34)) >= 0)
	# the JS scene has no water at all
	_check("scene: no invented sea", main.get_node("Environment").get_node_or_null("Sea") == null)
	# the sky is the four painted sides stitched into one panorama, not a wash
	var skymat: Material = null
	for w in main.get_node("Environment").get_children():
		if w is WorldEnvironment:
			skymat = (w as WorldEnvironment).environment.sky.sky_material
	_check("scene: painted panorama sky wired",
		skymat is PanoramaSkyMaterial
		and (skymat as PanoramaSkyMaterial).panorama != null)


## At least one live cube must override surface 2 with a different material
## from its other five faces, which is the whole point of the top/side split.
func _split_faces(cg: CubeGrid) -> bool:
	for c in cg._path_cubes:
		if c.top_mat == null or c.mat == null or c.mesh.mesh == null:
			continue
		if c.top_mat == c.mat:
			continue
		return c.mesh.get_surface_override_material(2) == c.top_mat \
			and c.mesh.get_surface_override_material(0) == c.mat
	return false


## Exact-scale match, within float slop: the JS decor passes literal sizes.
func _count_boxes(im: IslandBuilder, size: Vector3) -> int:
	var n := 0
	for c in im._group.get_children():
		if c is MeshInstance3D:
			var s: Vector3 = (c as MeshInstance3D).scale
			if absf(s.x - size.x) < 0.01 and absf(s.y - size.y) < 0.01 and absf(s.z - size.z) < 0.01:
				n += 1
	return n


func _check_modes() -> void:
	var main: Node = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	root.add_child(main)
	await process_frame
	await process_frame
	var gm: GameManager = main.get_node("Game")
	gm.stop_tutorial(false)
	gm.is_tutorial = false

	# daily: fixed 25-cell path, level 200 tier, no hearts, no skip
	gm.start_daily()
	await process_frame
	if gm.mode != GameManager.Mode.DAILY:
		_fails += 1
		printerr("start_daily did not set daily mode, got ", gm.mode)
	# JS generate(25) returns 26 cells: it starts at startPos then steps 25 times
	if gm.path.size() != 26:
		_fails += 1
		printerr("daily path length is ", gm.path.size(), ", want 26")
	Save.mark_daily_complete()

	# endless: three segments must all place a fresh, non-overlapping island and
	# append rather than restart the path
	gm.start_endless()
	await process_frame
	if gm._can_skip:
		_fails += 1
		printerr("endless must not offer the skip button")
	var lengths: Array[int] = [gm.path.size()]
	var island_counts: Array[int] = [gm.island_builder.islands.size()]
	for _i in range(2):
		if gm.state != GameManager.State.SHOWING:
			_fails += 1
			printerr("endless segment not in showing state, got ", gm.state)
			break
		gm._endless_complete()
		for _j in range(60):
			await process_frame
		lengths.append(gm.path.size())
		island_counts.append(gm.island_builder.islands.size())
		if gm.state != GameManager.State.SHOWING:
			# the segment wave is still running; wait it out
			for _k in range(400):
				await process_frame
			if gm.state != GameManager.State.SHOWING:
				break
	if gm.run_streak < 2:
		_fails += 1
		printerr("endless streak only reached ", gm.run_streak)
	for i in range(1, lengths.size()):
		if lengths[i] <= lengths[i - 1]:
			_fails += 1
			printerr("endless segment ", i, " did not grow the path: ", lengths[i - 1], " -> ", lengths[i])
		if island_counts[i] != island_counts[i - 1] + 1:
			_fails += 1
			printerr("endless segment ", i, " islands ", island_counts[i - 1], " -> ", island_counts[i])
	if Save.best_endless() < 1:
		_fails += 1
		printerr("best endless score not saved, got ", Save.best_endless())

	# player: the body must be a rounded cube - a face still reaches the
	# half-extent (0.28) while the 8 corners are pulled in toward a sphere,
	# and every triangle must wind clockwise from outside or the cube renders
	# its far walls and looks see-through
	var rarr: Array = gm.player._rounded_cube(0.28).surface_get_arrays(0)
	var rverts: PackedVector3Array = rarr[Mesh.ARRAY_VERTEX]
	var ridx: PackedInt32Array = rarr[Mesh.ARRAY_INDEX]
	var reach := 0.0
	var corner := 0.0
	for p in rverts:
		reach = maxf(reach, maxf(absf(p.x), maxf(absf(p.y), absf(p.z))))
		corner = maxf(corner, minf(absf(p.x), minf(absf(p.y), absf(p.z))))
	var outward := 0
	for i in range(0, ridx.size(), 3):
		var p0 := rverts[ridx[i]]
		var p1 := rverts[ridx[i + 1]]
		var p2 := rverts[ridx[i + 2]]
		var cr := (p1 - p0).cross(p2 - p0)
		if cr.length_squared() < 1e-12:
			continue
		# right-hand normal must point inward, exactly like Art.unit_cube
		if cr.dot((p0 + p1 + p2) / 3.0) > 0.0:
			outward += 1
	# lighting reads the NORMAL array, not the winding: it must point away from
	# the body or the cube is lit from inside
	var rnrm: PackedVector3Array = rarr[Mesh.ARRAY_NORMAL]
	var inward_n := 0
	for i in rverts.size():
		if rnrm[i].length_squared() > 0.5 and rnrm[i].dot(rverts[i]) <= 0.0:
			inward_n += 1
	# the faces must dome, not sit flat: down the u=0 column of the +x face the
	# height has to fall well short of the 0.28 centre after just one ring.
	var col: Array[float] = []
	for p in rverts:
		if absf(p.y) < 1e-4 and p.x > 0.0:
			col.append(p.x)
	col.sort()
	col.reverse()
	var dome := col.size() >= 3 and is_equal_approx(col[0], 0.28) and col[1] <= 0.27
	print("[7] player face centre ", col[0] if not col.is_empty() else -1.0,
		" next ring ", col[1] if col.size() > 1 else -1.0, " (flat would be ~0.278)")
	_check("player: body is a rounded cube",
		is_equal_approx(reach, 0.28) and corner > 0.05 and corner < 0.28)
	_check("player: body triangles wind clockwise from outside", outward == 0)
	_check("player: body normals point outward", inward_n == 0)
	_check("player: body faces are domed, not flat", dome)
	main.queue_free()