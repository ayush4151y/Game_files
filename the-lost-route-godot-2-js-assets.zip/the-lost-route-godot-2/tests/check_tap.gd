extends SceneTree

## Verifies the tap-to-start handler really fires, by emitting a real input
## event through the overlay's own gui_input signal (headless cannot deliver
## physical mouse input, but the handler wiring is what was broken).
##   godot --headless --path . --script res://tests/check_tap.gd

var _main: Node
var _gm: GameManager
var _ui: UI


func _initialize() -> void:
	Save.reset_progress()
	_main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	root.add_child(_main)
	_go()


func _go() -> void:
	await _wait(4)
	_gm = _main.get_node("Game")
	_ui = _gm.ui
	var fails := 0

	# the regression: a STOP child under the overlay ate every tap
	for child in _ui._tap_overlay.get_children():
		if child is Control and (child as Control).mouse_filter != Control.MOUSE_FILTER_IGNORE:
			fails += 1
			printerr("tap overlay child ", child.get_class(),
				" has mouse_filter ", (child as Control).mouse_filter)
	print("[1] tap overlay children ignore input: ", "OK" if fails == 0 else "FAIL")

	fails += await _check_tap("tutorial", func() -> void: _gm.launch_tutorial())
	_gm.stop_tutorial(false)
	_gm.is_tutorial = false
	fails += await _check_tap("daily", func() -> void: _gm.start_daily())
	fails += await _check_tap("endless", func() -> void: _gm.start_endless())

	# the pause card is a real panel with a frame, so it reads as a card against
	# the pale background instead of type floating on the dim
	_gm.toggle_pause()
	await _sleep(0.6)
	var pop: Dictionary = _ui._pause_popup
	var pan := pop["panel"] as PanelContainer
	if pan == null or not pop["root"].visible:
		fails += 1
		printerr("[9] pause card has no panel or did not show")
	else:
		var box := pan.get_theme_stylebox("panel") as StyleBoxFlat
		print("[9] pause card ", pan.size, " border ", box.border_width_left,
			" scale ", pan.scale)
		if absf(pan.size.x - UI.CARD_W) > 2.0 or absf(pan.size.y - UI.CARD_H) > 2.0:
			fails += 1
			printerr("[9] pause card is ", pan.size, ", want ", UI.CARD_W, "x", UI.CARD_H)
		if box == null or box.border_width_left < 1:
			fails += 1
			printerr("[9] pause card has no border to separate it from the background")
		if pan.scale.x <= 0.99:
			fails += 1
			printerr("[9] pause card never popped in: scale=", pan.scale)
		if (pop["stay"] as Button).size.x < 200:
			fails += 1
			printerr("[9] pause actions too small: ", (pop["stay"] as Button).size)
	_gm.toggle_pause()
	await _sleep(0.3)

	# level select: eight cards per row, the list scrolls down, cells big enough
	# to tap and visible inside the scroll viewport
	_gm.stop_tutorial(false)
	_gm.is_tutorial = false
	_gm.start_game()
	await _wait(6)
	var strip := _ui._level_strip
	var scroll := _ui._level_scroll
	var rows := strip.get_child_count()
	var cells := 0
	var per_row: Array[int] = []
	for c in strip.get_children():
		per_row.append((c as Control).get_child_count())
		cells += per_row[-1]
	var scr := scroll.get_global_rect()
	print("[2] grid: ", rows, " rows x ", per_row, " cells, viewport ", scr.size)
	var want_rows := int(ceil(float(UI.TOTAL_LEVELS) / float(UI.LEVELS_PER_LINE)))
	if rows != want_rows or cells != UI.TOTAL_LEVELS:
		fails += 1
		printerr("[2] expected ", UI.TOTAL_LEVELS, " cells in ", want_rows,
			" rows of ", UI.LEVELS_PER_LINE, ", got ", cells, " in ", rows)
	for n in per_row:
		if n > UI.LEVELS_PER_LINE:
			fails += 1
			printerr("[2] row holds ", n, " cards, expected at most ", UI.LEVELS_PER_LINE)
	if not scroll.horizontal_scroll_mode == ScrollContainer.SCROLL_MODE_SHOW_NEVER \
			or scroll.vertical_scroll_mode != ScrollContainer.SCROLL_MODE_AUTO:
		fails += 1
		printerr("[2] grid scrolls ", scroll.horizontal_scroll_mode, "/",
			scroll.vertical_scroll_mode, ", expected SHOW_NEVER/AUTO")
	if scr.size.y <= 0.0 or scr.size.x <= 0.0:
		fails += 1
		printerr("[2] scroll collapsed: ", scr)

	# the first three rows have to be on screen, the rest is below the fold
	var f3 := 0
	for i in mini(3, rows):
		for cell in (strip.get_child(i) as Control).get_children():
			if not (cell as Control).get_global_rect().intersects(scr):
				f3 += 1
	if f3:
		fails += 1
		printerr("[2] ", f3, " visible cells sit outside the viewport")
	print("[3] first 3 rows inside a ", scr.size, " viewport: ",
		"OK" if f3 == 0 else "FAIL")

	# one row's cards share the width and none may run past the scroll viewport
	var wide := 0
	for cell in (strip.get_child(0) as Control).get_children():
		if (cell as Control).get_global_rect().size.x + \
				(cell as Control).get_global_rect().position.x > scr.end.x + 1.0:
			wide += 1
	if wide:
		fails += 1
		printerr("[2] ", wide, " cards overflow the row")
	print("[3b] a full row fits the scroll width: ", "OK" if wide == 0 else "FAIL")

	# a level box must be a real thumb target, not the 46px minimum
	var side := (strip.get_child(0) as Control).get_child(0) as Control
	print("[4] level box ", side.size, " d-pad ", (_ui._dpad["up"] as Button).size,
		" action ", _ui._pause_btn.size)
	if side.size.x < 56.0:
		fails += 1
		printerr("[4] level box is only ", side.size, " - too small to tap")
	if (_ui._dpad["up"] as Button).size.x < 64.0 or _ui._pause_btn.size.x < 44.0:
		fails += 1
		printerr("[4] buttons too small: dpad ", (_ui._dpad["up"] as Button).size,
			" action ", _ui._pause_btn.size)
	if _ui._pause_btn.icon == null:
		fails += 1
		printerr("[4] buttons have no icon")
	print("[5] every HUD button carries an icon: ",
		"OK" if _ui._pause_btn.icon != null and (_ui._dpad["up"] as Button).icon != null else "FAIL")

	# the pad belongs at the foot of the screen with the up arrow above the down
	# one - reading the CSS bottom inset as a top offset put it up in the corner
	var vps := _ui._vp()
	var up_b := _ui._dpad["up"] as Button
	var down_b := _ui._dpad["down"] as Button
	print("[6] dpad up top ", up_b.offset_top, " down top ", down_b.offset_top,
		" down floor ", down_b.offset_bottom, " of ", vps.y)
	if up_b.offset_top >= down_b.offset_top:
		fails += 1
		printerr("[6] up arrow is not above the down arrow")
	if down_b.offset_bottom < vps.y * 0.75:
		fails += 1
		printerr("[6] pad is not bottom aligned: it ends at ", down_b.offset_bottom,
			" of ", vps.y)

	# the cards wear the light-theme skin: white tile, a two pixel navy rule
	var cell := (strip.get_child(0) as Control).get_child(0) as Button
	var cbox := cell.get_theme_stylebox("normal") as StyleBoxFlat
	print("[10] card fill ", cbox.bg_color, " rule ", cbox.border_color,
		" width ", cbox.border_width_left, " shadow ", cbox.shadow_color)
	if cbox == null or cbox.bg_color.r < 0.95:
		fails += 1
		printerr("[10] level card is not a white tile: ", cbox.bg_color if cbox else "no stylebox")
	if cbox != null and cbox.border_width_left != 2:
		fails += 1
		printerr("[10] level card rule is ", cbox.border_width_left, "px, want 2")
	if cbox != null and cbox.shadow_color.a < 0.2:
		fails += 1
		printerr("[10] level card has no drop shadow to lift it off the gradient")

	# the camera replaced the rotate glyph
	var cam := Art.icon("camera", int(UI.ACTION_BTN), UI.COL_INK)
	if _ui._rotate_btn.icon == null or _ui._rotate_btn.icon != cam:
		fails += 1
		printerr("[10] rotate button is not carrying the camera icon")
	print("[10] card skin + camera icon: ",
		"OK" if not (_ui._rotate_btn.icon == null or _ui._rotate_btn.icon != cam) else "FAIL")

	# the tutorial banner must carry a working SKIP, and it must be big enough
	fails += await _check_tutorial_skip()
	fails += await _check_icons_render()
	fails += _check_menu_buttons_fit()
	fails += _check_edge_clearance()
	fails += await _check_back_routing()
	fails += await _check_settings_layout()
	fails += await _check_screen_cover()
	fails += await _check_popup_home()
	fails += _check_win_ad_gate()
	fails += await _check_ads_confirm()

	if fails == 0:
		print("PASS: tap overlay, mode taps, level select layout, settings card, screen cover, popup home")
	else:
		printerr("FAIL: ", fails, " check(s)")
	quit(1 if fails else 0)


## Android hardware-back mirror: settings/levels -> menu, in-play -> pause and
## pause -> resume, home -> exit confirm popup, popup open -> closes it.
func _check_back_routing() -> int:
	var f := 0
	_gm.back_to_menu()
	await _wait(2)
	_gm._last_back_ms = 0
	_gm._handle_back()
	if not _ui.exit_visible():
		f += 1
		printerr("[12] back on home did not raise the exit popup")
	_gm._last_back_ms = 0
	_gm._handle_back()
	if _ui.exit_visible():
		f += 1
		printerr("[12] back did not close the exit popup")

	_gm.show_settings()
	await _wait(1)
	_gm._last_back_ms = 0
	_gm._handle_back()
	if _ui.screen == UI.Screen.SETTINGS:
		f += 1
		printerr("[12] back in settings did not return to menu")

	_gm.start_game()
	await _wait(1)
	_gm._last_back_ms = 0
	_gm._handle_back()
	if _ui.screen == UI.Screen.LEVELS:
		f += 1
		printerr("[12] back in level select did not return to menu")

	_gm.start_level(3)
	await _wait(2)
	_gm._last_back_ms = 0
	_gm._handle_back()
	if not _gm.paused:
		f += 1
		printerr("[12] back while showing did not pause")
	_gm._last_back_ms = 0
	_gm._handle_back()
	if _gm.paused:
		f += 1
		printerr("[12] back while paused did not resume")

	print("[12] android back routing: ", "OK" if f == 0 else "FAIL")
	return f


## The settings body has to span the screen: the old 320px column sat centred
## with dead space down both sides.
## Settings is a card over the menu now, not a screen: it has to fit the
## viewport, fill its own width with round-ended thumb targets, and close back
## to the menu it was raised over.
func _check_settings_layout() -> int:
	var f := 0
	_gm.back_to_menu()
	await _wait(2)
	_gm.show_settings()
	await _wait(6)
	if not (_ui._settings_pop["root"] as Control).visible:
		printerr("[13] settings card did not open")
		return 1
	if _ui.screen != UI.Screen.SETTINGS:
		f += 1
		printerr("[13] settings card did not take the screen, screen=", _ui.screen)
	var vp := _ui._vp()
	var card := _ui._settings_pop["panel"] as PanelContainer
	var w := _ui._sound_btn.size.x
	var x := _ui._sound_btn.get_global_rect().position.x
	var box := _ui._sound_btn.get_theme_stylebox("normal") as StyleBoxFlat
	print("[13] settings card ", card.size, " controls ", w,
		" wide, left edge ", x, " of vp ", vp)
	if w < 300.0:
		f += 1
		printerr("[13] settings controls only ", w, " wide - too small to tap")
	if card.size.x > vp.x - 16.0 or card.size.y > vp.y - 16.0:
		f += 1
		printerr("[13] settings card does not fit the screen: ", card.size, " in ", vp)
	if box == null or box.corner_radius_top_left < 20:
		f += 1
		printerr("[13] settings buttons are not rounded: ",
			box.corner_radius_top_left if box else "no stylebox")
	_gm.hide_settings()
	await _wait(1)
	if _ui.screen != UI.Screen.MENU or (_ui._settings_pop["root"] as Control).visible:
		f += 1
		printerr("[13] closing the card did not return to the menu, screen=", _ui.screen)
	print("[13] settings card fits, fills and closes: ", "OK" if f == 0 else "FAIL")
	return f


## Every screen swap drops an opaque cover on the frame it changes on, then
## fades it out. Left up, or still swallowing taps afterwards, is the bug.
func _check_screen_cover() -> int:
	var f := 0
	_gm.back_to_menu()
	if _ui._fade == null:
		return 1
	if _ui._fade.modulate.a < 0.99:
		f += 1
		printerr("[14] screen swap did not raise the cover, alpha=", _ui._fade.modulate.a)
	elif _ui._fade.mouse_filter != Control.MOUSE_FILTER_STOP:
		f += 1
		printerr("[14] cover is up but still lets taps through")
	await _sleep(0.45)
	if _ui._fade.modulate.a > 0.001 or _ui._fade.mouse_filter != Control.MOUSE_FILTER_IGNORE:
		f += 1
		printerr("[14] cover never cleared: alpha=", _ui._fade.modulate.a,
			" filter=", _ui._fade.mouse_filter)
	print("[14] screen cover covers then clears: ", "OK" if f == 0 else "FAIL")
	return f


## The win and game-over cards shipped a single action; HOME has to be there
## too, and not doubled up when the action already reads MENU.
func _check_popup_home() -> int:
	var f := 0
	_ui.show_win("LEVEL COMPLETE!", "", "NEXT LEVEL")
	if not (_ui._win_popup["home"] as Button).visible:
		f += 1
		printerr("[15] win card has no HOME next to NEXT LEVEL")
	_ui.show_win("DAILY COMPLETE!", "Streak: 1 days", "MENU")
	if (_ui._win_popup["home"] as Button).visible:
		f += 1
		printerr("[15] win card offers HOME next to an identical MENU action")
	_ui.show_game_over("GAME OVER", "Wrong direction!", "Level 3", "TRY AGAIN")
	if not (_ui._over_popup["home"] as Button).visible:
		f += 1
		printerr("[15] game-over card has no HOME next to TRY AGAIN")
	(_ui._over_popup["home"] as Button).pressed.emit()
	if _ui.screen != UI.Screen.MENU:
		f += 1
		printerr("[15] game-over HOME did not go to the menu, screen=", _ui.screen)
	_ui.hide_all()
	print("[15] win/game-over cards offer HOME: ", "OK" if f == 0 else "FAIL")
	return f


## Every 5th campaign win arms the win popup so either option pays a rewarded ad
## first; unarmed wins pass straight through. Pure logic - no level walk needed.
func _check_win_ad_gate() -> int:
	var f := 0
	_gm.back_to_menu()
	_gm._wins_since_ad = 0
	_gm._win_ad_pending = false
	for _i in range(4):
		_gm._note_campaign_win()
	if _gm._win_ad_pending:
		f += 1
		printerr("[16] ad armed before the 5th win")
	var ran := [0]
	_gm.win_choice(func() -> void: ran[0] += 1)
	if _gm._win_ad_pending or ran[0] != 1:
		f += 1
		printerr("[16] sub-5th win choice was not free")
	_gm._note_campaign_win()
	if not _gm._win_ad_pending:
		f += 1
		printerr("[16] 5th win did not arm the ad")
	if _gm._wins_since_ad != 0:
		f += 1
		printerr("[16] ad counter did not reset after arming")
	_gm.win_choice(func() -> void: ran[0] += 1)
	if _gm._win_ad_pending or ran[0] != 2:
		f += 1
		printerr("[16] 5th-win choice did not run after the ad")
	_gm.win_choice(func() -> void: ran[0] += 1)
	if ran[0] != 3:
		f += 1
		printerr("[16] choice blocked after the ad was consumed")
	_gm._wins_since_ad = 0
	_gm._win_ad_pending = false
	print("[16] every-5th-win ad gate: ", "OK" if f == 0 else "FAIL")
	return f


## Hint and skip ads must be opted into explicitly: a single tap only asks, and
## game-over CONTINUE buys the exact death tile back with full hearts.
func _check_ads_confirm() -> int:
	var f := 0
	_gm.stop_tutorial(false)
	_gm.is_tutorial = false
	f += await _check_tap("adcv", func() -> void: _gm.start_level(2))
	if _gm.state != _gm.State.PLAYING:
		printerr("[16] ad confirm test could not reach playing")
		return f

	# hint with no free hints left: the first tap must only ask
	while Save.free_hints() > 0:
		Save.use_free_hint()
	var idx := _gm.current_path_index
	_gm.hint_move()
	await _wait(2)
	if not (_ui._ad_popup["root"] as Control).visible:
		f += 1
		printerr("[16] hint tap did not raise the ad confirm")
	if _gm.current_path_index != idx:
		f += 1
		printerr("[16] hint ran before the WATCH AD confirm")
	if not _gm.paused or not _gm.cube_grid.paused:
		f += 1
		printerr("[16] confirm did not pause the scene")
	(_ui._ad_popup["home"] as Button).pressed.emit()
	await _wait(2)
	if (_ui._ad_popup["root"] as Control).visible or _gm.paused or _gm.cube_grid.paused:
		f += 1
		printerr("[16] hint NO did not close and unpause")
	if _gm.current_path_index != idx:
		f += 1
		printerr("[16] hint moved after NO")
	# watching the ad earns the step; no plugin grants instantly
	_gm.hint_move()
	await _wait(2)
	(_ui._ad_popup["stay"] as Button).pressed.emit()
	await _wait(4)
	if _gm.paused or _gm.cube_grid.paused:
		f += 1
		printerr("[16] hint ad left the game paused")
	if _gm.current_path_index != idx + 1:
		f += 1
		printerr("[16] hint ad did not step the player: ", _gm.current_path_index,
			" want ", idx + 1)

	# skip: first tap asks, NO changes nothing, WATCH AD advances the level
	var lvl := _gm.level
	_gm.skip_show()
	await _wait(2)
	if not (_ui._ad_popup["root"] as Control).visible:
		f += 1
		printerr("[16] skip tap did not raise the ad confirm")
	(_ui._ad_popup["home"] as Button).pressed.emit()
	await _wait(2)
	if _gm.level != lvl or _gm.state != _gm.State.PLAYING:
		f += 1
		printerr("[16] skip NO still skipped the level")
	_gm.skip_show()
	await _wait(2)
	(_ui._ad_popup["stay"] as Button).pressed.emit()
	await _wait(80)
	if _gm.level != lvl + 1 or _gm.state == _gm.State.PLAYING:
		f += 1
		printerr("[16] skip WATCH AD did not advance: level=", _gm.level,
			" want ", lvl + 1, " state=", _gm.state)

	# game-over CONTINUE: the ad buys the exact tile back at full health
	if _gm.state == _gm.State.SHOWING:
		_gm.tap_to_start()
		await _wait(50)
	for _i in range(2):
		if _gm.state != _gm.State.PLAYING or _gm.current_path_index + 1 >= _gm.path.size():
			break
		var dir := Cfg.dir_between(_gm.path[_gm.current_path_index],
			_gm.path[_gm.current_path_index + 1])
		_gm.handle_move(dir)
		for _j in range(90):
			await process_frame
			if not _gm.player.is_moving:
				break
	if not _gm.is_playing():
		printerr("[16] continue test could not start level ", _gm.level)
		return f
	idx = _gm.current_path_index
	_gm.health = 0
	_gm.game_over()
	await _wait(40)
	if _gm.state != _gm.State.GAMEOVER:
		printerr("[16] game_over did not open for CONTINUE")
		return f
	if _gm._resume_index != idx:
		f += 1
		printerr("[16] death index not captured: ", _gm._resume_index, " want ", idx)
	var top: Control = _ui._over_popup["top"]
	if not (top as Control).visible:
		f += 1
		printerr("[16] game-over card has no CONTINUE on top")
	(top.get_child(0) as Button).pressed.emit()
	await _wait(4)
	if _gm.state != _gm.State.PLAYING:
		f += 1
		printerr("[16] CONTINUE did not return to play, state=", _gm.state)
	if _gm.current_path_index != idx:
		f += 1
		printerr("[16] CONTINUE did not land on the death tile: ", _gm.current_path_index,
			" want ", idx)
	if _gm.health != Cfg.MAX_HEARTS:
		f += 1
		printerr("[16] CONTINUE did not restore full hearts: ", _gm.health)
	if (_ui._over_popup["root"] as Control).visible:
		f += 1
		printerr("[16] CONTINUE left the game-over popup up")
	print("[16] ad confirm + continue: ", "OK" if f == 0 else "FAIL")
	return f


func _check_tap(label: String, start: Callable) -> int:
	start.call()
	await _wait(2)
	var t := 0.0
	while t < 15.0 and not _ui._tap_overlay.visible:
		await _sleep(0.05)
		t += 0.05
	if not _ui._tap_overlay.visible:
		printerr("[", label, "] tap overlay never appeared, state=", _gm.state)
		return 1
	var i0 := _gm.show_start_index
	var first := _gm.cube_grid._path_cubes[i0]
	var last := _gm.cube_grid._path_cubes[_gm.cube_grid._path_cubes.size() - 1]
	var y_before := _gm.cube_grid._path_cubes[i0 + 1].mesh.position.y if _gm.cube_grid._path_cubes.size() > i0 + 1 else 0.5
	var ev := InputEventScreenTouch.new()
	ev.pressed = true
	ev.position = Vector2(10, 10)
	_ui._tap_overlay.gui_input.emit(ev)
	t = 0.0
	while t < 15.0 and not _gm.is_playing():
		await _sleep(0.05)
		t += 0.05
	if not _gm.is_playing():
		printerr("[", label, "] tap did not start play, state=", _gm.state)
		return 1
	# first/last are the start/end tiles, which stay up by design, so check a
	# middle cube and require the whole middle band to be down
	var total := _gm.cube_grid._path_cubes.size()
	var ups := 0
	for j in range(i0 + 1, total - 1):
		if _gm.cube_grid._path_cubes[j].mesh.position.y >= 0.0:
			ups += 1
	var hid := total < 3 or ups == 0
	print("[", label, "] tap started play=", _gm.is_playing(),
		" cubes=", total, " still_up=", ups,
		" start/end kept=", first.mesh.position.y, "/", last.mesh.position.y,
		" first_mid_before=", y_before, " hidden=", hid)
	if not hid:
		printerr("[", label, "] blocks did not hide after tap")
		return 1
	return 0


func _wait(frames: int) -> void:
	for _i in range(frames):
		await process_frame


func _sleep(s: float) -> void:
	await create_timer(s).timeout

## The tutorial banner owns a SKIP button. Grab it off the banner row and press
## it: the tutorial must end, which is what a stuck skip looks like.
func _check_tutorial_skip() -> int:
	_gm.launch_tutorial()
	await _wait(4)
	if not _ui._tut_banner.visible:
		printerr("[6] tutorial banner never showed")
		return 1
	var skip: Button = null
	for b in find_skip(_ui._tut_banner):
		skip = b
	if skip == null:
		printerr("[6] tutorial banner has no skip button")
		return 1
	if skip.size.x < 36.0 or skip.icon == null:
		printerr("[6] skip button is ", skip.size, " icon=", skip.icon != null)
		return 1
	skip.pressed.emit()
	await _wait(4)
	if _gm.is_tutorial:
		printerr("[6] skip did not end the tutorial")
		return 1
	print("[6] tutorial SKIP: ", skip.size, " pressed, tutorial ended: OK")
	return 0


func find_skip(node: Node) -> Array:
	var out: Array = []
	for c in node.get_children():
		if c is Button and c.icon != null:
			out.append(c)
		out.append_array(find_skip(c))
	return out


## Every icon must rasterise to something, not a blank texture. A glyph that
## silently came out empty is the failure mode a screenshot would hide. The
## names are the index.html <svg> icons, so a missing one is a real regression.
## Regression guard: the home buttons size themselves from the shipped PNGs, so
## a wrong aspect pushed the whole stack off screen and the home screen rendered
## as bare background with no buttons at all.
func _check_menu_buttons_fit() -> int:
	var vp: Vector2 = _ui._vp()
	# headless ignores --resolution and hands back a square window, so judge the
	# home layout against the 16:9 base it is authored for, not the test window
	vp.y = minf(vp.y, vp.x * 720.0 / 1280.0)
	var stack: VBoxContainer = null
	for c in _ui._menu_screen.get_children():
		if c is VBoxContainer and c.size.x > 0 and c.size.x < vp.x:
			stack = c
	var bad := 0
	if stack == null or stack.get_child_count() != 4:
		bad += 1
		printerr("[8] home button stack not found or wrong child count")
		return bad
	var bottom := 0.0
	for b in stack.get_children():
		var btn: Button = b
		var t := btn.icon
		if t == null:
			bad += 1
			printerr("[8] home button has no icon texture")
			continue
		if absf(btn.size.y - btn.size.x * t.get_size().y / t.get_size().x) > 2.0:
			bad += 1
			printerr("[8] button height ignores art aspect: ", btn.size, " icon ", t.get_size())
		if btn.size.x <= 0 or btn.size.y <= 0:
			bad += 1
			printerr("[8] button collapsed to zero size: ", btn.size)
		bottom = maxf(bottom, btn.global_position.y + btn.size.y)
	if bottom > vp.y:
		bad += 1
		printerr("[8] home stack overflows viewport: bottom ", bottom, " > ", vp.y)
	print("[8] home buttons keep art aspect and fit (bottom ", snappedf(bottom, 1.0),
		" of ", vp.y, "): ", "OK" if bad == 0 else "FAIL")

	# Every home element has to land inside the viewport. Anchor offsets are the
	# easy thing to get backwards, and a button parked just past the right edge
	# looks exactly like a missing button on screen.
	# compare against the layout root itself: headless hands back a square window
	# while these are inset anchors on whatever the real screen size turns out to be
	var box: Vector2 = _ui._menu_screen.size
	for c in _ui._menu_screen.get_children():
		if not (c is Control) or not c.visible:
			continue
		var r := (c as Control).get_global_rect()
		if r.size.x <= 0.0 or r.size.y <= 0.0:
			bad += 1
			printerr("[8] home element has no area, nothing can draw: ", c.name, " ", r)
		if r.position.x >= box.x - 1.0 or r.position.x + r.size.x <= 0.0:
			bad += 1
			printerr("[8] home element off screen horizontally: ", c.name, " ", r)
		if r.position.y >= box.y - 1.0 or r.position.y + r.size.y <= 0.0:
			bad += 1
			printerr("[8] home element off screen vertically: ", c.name, " ", r)
	return bad


## Curved phone screens have a dead zone in the corners, and the HUD used to
## pin its buttons 15px off the edge, where taps only landed sometimes. Every
## edge-anchored button has to clear UI.EDGE_PAD, and the TNT "go back" overlay
## has to ride its own D-pad key instead of sitting at the origin on top of the
## pause button, where it swallowed those taps.
func _check_edge_clearance() -> int:
	var bad := 0
	var vp: Vector2 = _ui._vp()
	var pad := UI.EDGE_PAD - 0.5
	var left_side := {"pause": _ui._pause_btn}
	var right_side := {"skip": _ui._skip_btn, "hint": _ui._hint_btn,
		"rotate": _ui._rotate_btn}
	for label in left_side:
		var r := (left_side[label] as Button).get_global_rect()
		if r.position.x < pad or r.position.y < pad:
			bad += 1
			printerr("[11] ", label, " sits in the corner dead zone: ", r)
	for label in right_side:
		var r := (right_side[label] as Button).get_global_rect()
		if vp.x - r.end.x < pad or r.position.y < pad:
			bad += 1
			printerr("[11] ", label, " sits in the corner dead zone: ", r)
	for dir in _ui._dpad:
		var r := (_ui._dpad[dir] as Button).get_global_rect()
		if minf(r.position.x, vp.x - r.end.x) < pad:
			bad += 1
			printerr("[11] d-pad ", dir, " too close to the side edge: ", r)
	for dir in _ui._tnt_btn:
		var over := _ui._tnt_btn[dir] as Button
		var key := _ui._dpad[dir] as Button
		if over.get_global_rect() != key.get_global_rect():
			bad += 1
			printerr("[12] tnt overlay ", dir, " is not on its pad key: ",
				over.get_global_rect(), " vs ", key.get_global_rect())
		if over.mouse_filter != Control.MOUSE_FILTER_IGNORE:
			bad += 1
			printerr("[12] tnt overlay ", dir, " steals taps from the d-pad")
	if bad == 0:
		print("[11] edge buttons clear the corner dead zone and the tnt overlay",
			" rides its pad key: OK")
	return bad


func _check_icons_render() -> int:
	var names := ["up", "down", "left", "right", "back", "pause", "skip", "rotate",
		"camera", "hint", "lock", "pause_circle"]
	var bad := 0
	for n in names:
		var tex := Art.icon(n, 48)
		if tex == null:
			bad += 1
			printerr("[7] icon ", n, " did not rasterise")
			continue
		var img := tex.get_image()
		var painted := 0
		for y in range(0, img.get_height(), 4):
			for x in range(0, img.get_width(), 4):
				if img.get_pixel(x, y).a > 0.5:
					painted += 1
		if painted < 8:
			bad += 1
			printerr("[7] icon ", n, " is nearly blank (", painted, " px)")
	# the JS menu buttons are PNGs, so they must load as textures too
	for n in ["btn-start.png", "btn-endless.png", "btn-daily.png", "btn-settings.png",
			"logo.png", "island.png", "sky.png"]:
		var t := Art.tex("res://assets/menu/" + n)
		if t == null or t.get_width() < 32:
			bad += 1
			printerr("[7] menu art ", n, " missing or tiny")
	print("[7] ", names.size() + 7 - bad, "/", names.size() + 7,
		" icons + menu art render: ", "OK" if bad == 0 else "FAIL")
	return bad
