extends SceneTree

func _init() -> void:
	for n in ["AudioEffectLimiter", "AudioEffectHardLimiter", "AudioEffectCompressor"]:
		print(n, " -> ", ClassDB.class_exists(n))
	var lim := AudioEffectHardLimiter.new() if ClassDB.class_exists("AudioEffectHardLimiter") else null
	if lim != null:
		print("hardlimiter props: ", lim.get_property_list().map(func(p): return p.name).filter(func(s): return "db" in s or "ceiling" in s))
	quit()
