class_name IslandBuilder
extends Node3D

## Port of IslandBuilder.js - floating start island (tree + sign + flowers) and
## end island (stone platform, rune, broken pillars) plus tapered rock bodies.
## All placement is seeded by hash2 so a given path always builds the same way.

var islands: Array[Vector2i] = []
var start_center := Vector2i.ZERO
var end_center := Vector2i.ZERO

var _group: Node3D
var _mats := {}
var _t := 0.0
var _idle_phase := 0.0


static func hex(c: int) -> Color:
	return Color(float((c >> 16) & 0xff) / 255.0, float((c >> 8) & 0xff) / 255.0, float(c & 0xff) / 255.0)


func _process(delta: float) -> void:
	if _group == null:
		return
	_t += delta
	_group.position.y = sin(_t * 0.6 + _idle_phase) * 0.015


## IslandBuilder.js mat(): flat MeshPhong colour, shininess 12, no texture.
func _mat(c: int) -> StandardMaterial3D:
	if not _mats.has(c):
		var m := StandardMaterial3D.new()
		m.albedo_color = hex(c)
		m.roughness = 0.9
		_mats[c] = m
	return _mats[c]


## buildIsland() passes cubeGrid.getTypeMaterial(GRASS), so the island top face
## is the real grass texture rather than a flat green.
var _grass_mats: Array[StandardMaterial3D] = []


func _grass_mat() -> Array[StandardMaterial3D]:
	if not _grass_mats.is_empty():
		return _grass_mats
	var t := Art.tex("res://assets/texture/grass_top.jpg")
	var s := Art.tex("res://assets/texture/grass_side.jpg")
	var top := StandardMaterial3D.new()
	var side := StandardMaterial3D.new()
	# JS builds these from getTypeMaterial(GRASS), which is map-only white
	top.albedo_color = Color.WHITE
	side.albedo_color = Color.WHITE
	top.roughness = 0.53
	side.roughness = 0.53
	if t != null:
		top.albedo_texture = t
	if s != null:
		side.albedo_texture = s
	_grass_mats = [top, side]
	return _grass_mats


func _box(parent: Node3D, mat: Material, x: float, y: float, z: float,
		sx: float, sy: float, sz: float, cast := false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = BoxMesh.new()
	mi.material_override = mat
	mi.position = Vector3(x, y, z)
	mi.scale = Vector3(sx, sy, sz)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if cast else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


## IcosahedronGeometry stand-in: low-segment sphere keeps the faceted look.
func _blob(parent: Node3D, mat: Material, x: float, y: float, z: float,
		r: float, cast := false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var s := SphereMesh.new()
	s.radius = 1.0
	s.height = 2.0
	s.radial_segments = 6
	s.rings = 3
	mi.mesh = s
	mi.material_override = mat
	mi.position = Vector3(x, y, z)
	mi.scale = Vector3(r, r, r)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON if cast else GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


# --- build -------------------------------------------------------------------

func build(path: Array[Vector2i]) -> void:
	clear()
	if path.size() < 2:
		return
	_group = Node3D.new()
	add_child(_group)

	var grass := _grass_mat()
	var lip := _mat(0xa8ddb8)
	var dirt := _mat(0xb08968)
	var rock_a := _mat(0x9aa8b5)
	var rock_b := _mat(0x8b98a6)
	var crack := _mat(0x6d7783)
	var moss := _mat(0x6fae7a)
	var trunk := _mat(0x8a6248)
	var leaf := _mat(0x7cc576)
	var leaf2 := _mat(0x8fd98a)
	var flower_a := _mat(0xf28fbd)
	var flower_b := _mat(0xffd27a)
	var stone := _mat(0xcfd3dc)
	var pillar := _mat(0x98a0b0)
	var rune := _mat(0xe8dcb0)

	var first := path[0]
	var last := path[path.size() - 1]
	var d_start := path[1] - first
	var d_end := last - path[path.size() - 2]
	start_center = first - d_start
	end_center = last + d_end
	islands = [start_center, end_center]

	var s_b := start_center - first
	var s_p := Vector2i(-s_b.y, s_b.x)
	var e_b := end_center - last
	var e_p := Vector2i(-e_b.y, e_b.x)

	var path_set := {}
	for p in path:
		path_set[PathGenerator.key(p)] = true

	_build_island(start_center, path_set, grass, lip, dirt, rock_a, rock_b, crack, moss, null)
	_build_start_decor(start_center, s_b, s_p, path_set, trunk, leaf, leaf2, flower_a, flower_b, stone, moss)

	var e_notch := {
		PathGenerator.key(last + e_p): true,
		PathGenerator.key(last - e_p): true,
	}
	_build_island(end_center, path_set, grass, lip, dirt, rock_a, rock_b, crack, moss, e_notch)
	_build_end_ruins(end_center, e_b, e_p, stone, pillar, rune, moss, dirt)

	_idle_phase = float(Rng.hash2(start_center.x, start_center.y)) * 0.001


func _build_island(c: Vector2i, path_set: Dictionary, grass: Array, lip: Material,
		dirt: Material, rock_a: Material, rock_b: Material, crack: Material, moss: Material, skip_set) -> void:
	var rng := Rng.mulberry(Rng.hash2(c.x, c.y))
	var cells: Array = []
	for dx in range(-1, 2):
		for dz in range(-1, 2):
			var p := Vector2i(c.x + dx, c.y + dz)
			if path_set.has(PathGenerator.key(p)):
				continue
			if skip_set != null and skip_set.has(PathGenerator.key(p)):
				continue
			cells.append({"p": p, "dx": dx, "dz": dz})

	for cell in cells:
		var p: Vector2i = cell["p"]
		# JS reuses one material instance for every cell, so share the pair
		var gm := grass
		var mi := MeshInstance3D.new()
		mi.mesh = Art.unit_cube()
		mi.position = Vector3(p.x, 0.45, p.y)
		mi.scale = Vector3.ONE
		for s in mi.mesh.get_surface_count():
			mi.set_surface_override_material(s, gm[0] if s == 2 else gm[1])
		_group.add_child(mi)
		_box(_group, lip, p.x, 0.22, p.y, 1.26, 0.18, 1.26)
		_box(_group, dirt, p.x, -0.62, p.y, 1.42, 0.42, 1.42, true)

	# tapered rock body, each slab jittered for a unique silhouette
	var half := [1.1, 0.9, 0.72, 0.52, 0.34]
	var thk := [0.95, 0.8, 0.68, 0.56, 0.46]
	for k in range(5):
		var w: float = (half[k] * 2.0) * (1.0 + (rng.next() - 0.5) * 0.06)
		var t: float = thk[k] * (1.0 + (rng.next() - 0.5) * 0.12)
		var dx: float = (rng.next() - 0.5) * half[k] * 0.12
		var dz: float = (rng.next() - 0.5) * half[k] * 0.12
		var rock: Material = rock_a if k % 2 == 0 else rock_b
		_box(_group, rock, c.x + dx, -1.45 - k * 0.82, c.y + dz, w, t, w)
	_blob(_group, rock_a, c.x, -4.7, c.y, 0.3)

	for _k in range(4):
		var a := rng.next() * TAU
		var r := 0.35 + rng.next() * 0.55
		_blob(_group, rock_a, c.x + cos(a) * r, -2.1 - rng.next() * 1.5, c.y + sin(a) * r,
			0.14 + rng.next() * 0.16)

	for k in range(4):
		var a := rng.next() * TAU
		var r: float = half[1 + (k % 4)] * 0.85
		var ck := _box(_group, crack, c.x + cos(a) * r, -1.6 - k * 1.1, c.y + sin(a) * r, 0.12, 0.5, 0.12)
		ck.rotation.y = a

	for _k in range(3):
		var a := rng.next() * TAU
		var r: float = half[1 + _k] * 0.9
		_blob(_group, moss, c.x + cos(a) * r, -1.7 - rng.next() * 2.2, c.y + sin(a) * r,
			0.2 + rng.next() * 0.18)

	for _k in range(3):
		var a := rng.next() * TAU
		var r := (0.25 + rng.next() * 0.5) * 1.2
		var rt := _box(_group, dirt, c.x + cos(a) * r, -1.1 - rng.next() * 0.6, c.y + sin(a) * r,
			0.07, 0.7 + rng.next() * 0.9, 0.07)
		rt.rotation.z = (rng.next() - 0.5) * 0.4
		rt.rotation.x = (rng.next() - 0.5) * 0.4

	for cell in cells:
		if absi(int(cell["dx"])) != 1 and absi(int(cell["dz"])) != 1:
			continue
		var p: Vector2i = cell["p"]
		var roll := rng.next()
		if roll < 0.4:
			_blob(_group, _mat(0xcfd3dc), p.x, 1.0, p.y, 0.13 + rng.next() * 0.12)
			_blob(_group, moss, p.x, 0.95, p.y, 0.1 + rng.next() * 0.08)
		elif roll < 0.62:
			_blob(_group, moss, p.x, 0.7, p.y, 0.14)


func _build_start_decor(c: Vector2i, s_b: Vector2i, s_p: Vector2i, path_set: Dictionary,
		trunk: Material, leaf: Material, leaf2: Material, flower_a: Material, flower_b: Material,
		stone: Material, moss: Material) -> void:
	# one low-poly tree on the back edge, never on a path cell
	var tx := c.x + s_b.x
	var tz := c.y + s_b.y
	if not path_set.has(str(tx) + "," + str(tz)):
		_box(_group, trunk, tx, 1.4, tz, 0.5, 1.1, 0.5)
		_blob(_group, leaf, tx, 2.05, tz, 0.78)
		_blob(_group, leaf2, tx + 0.35, 2.65, tz + 0.2, 0.52)
		_blob(_group, leaf2, tx - 0.3, 2.55, tz - 0.3, 0.48)

	var sx := c.x + s_p.x
	var sz := c.y + s_p.y
	var ang := atan2(float(s_b.x), float(s_b.y))
	if not path_set.has(str(sx) + "," + str(sz)):
		var post := _box(_group, trunk, sx, 0.95, sz, 0.12, 0.9, 0.12)
		post.rotation.y = ang
		var board := _box(_group, trunk, sx, 1.45, sz, 0.62, 0.42, 0.1)
		board.rotation.y = ang

	for i in range(-1, 2):
		for j in range(-1, 2):
			if i == 0 and j == 0:
				continue
			var px := c.x + s_b.x * i + s_p.x * j
			var pz := c.y + s_b.y * i + s_p.y * j
			if path_set.has(str(px) + "," + str(pz)):
				continue
			var rng := Rng.mulberry(Rng.hash2(px, pz))
			var roll := rng.next()
			if roll < 0.28:
				_box(_group, flower_a if roll < 0.13 else flower_b, px, 1.1, pz, 0.2, 0.4, 0.2)
				_blob(_group, moss, px, 1.03, pz, 0.1)
			elif roll < 0.4:
				_blob(_group, stone, px, 1.0, pz, 0.16 + rng.next() * 0.12)
			elif roll < 0.48:
				_box(_group, flower_a, px, 1.15, pz, 0.16, 0.45, 0.16)


func _build_end_ruins(c: Vector2i, e_b: Vector2i, e_p: Vector2i, stone: Material,
		pillar: Material, rune: Material, moss: Material, dirt: Material) -> void:
	var rng := Rng.mulberry(Rng.hash2(c.x, c.y))
	var cx := c.x + e_b.x * 0.35
	var cz := c.y + e_b.y * 0.35

	for k in range(7):
		var a := (k / 7.0) * TAU + rng.next() * 0.3
		var px := cx + cos(a) * 0.8
		var pz := cz + sin(a) * 0.8
		_blob(_group, stone, px, 0.92, pz, 0.2 + rng.next() * 0.06)
		_blob(_group, moss, px + (rng.next() - 0.5) * 0.2, 0.9, pz + (rng.next() - 0.5) * 0.2, 0.08)

	var rune_tile := _box(_group, rune, cx, 0.85, cz, 0.42, 0.08, 0.42)
	rune_tile.rotation.y = rng.next() * PI

	for k in range(2):
		var side := 1 if k == 0 else -1
		var ph := 0.7 + rng.next() * 0.8
		var px := cx + e_p.x * side * 0.9 + (rng.next() - 0.5) * 0.2
		var pz := cz + e_p.y * side * 0.9 + (rng.next() - 0.5) * 0.2
		var pil := _box(_group, pillar, px, ph / 2.0 + 0.55, pz, 0.34, ph, 0.34)
		pil.rotation.x = (rng.next() - 0.5) * 0.25
		pil.rotation.z = (rng.next() - 0.5) * 0.25
		_blob(_group, stone, px, ph / 2.0 + 0.65, pz, 0.16)

	for k in range(3):
		_blob(_group, stone,
			c.x + e_b.x * 0.85 + e_p.x * 0.4 + (rng.next() - 0.5) * 0.4,
			0.85 + k * 0.18,
			c.y + e_b.y * 0.85 + e_p.y * 0.4 + (rng.next() - 0.5) * 0.4,
			0.16 + k * 0.05)


## Endless mode appends only the new island each segment; the old islands stay.
func build_end_only(path: Array[Vector2i]) -> void:
	if path.size() < 2:
		return
	if _group == null:
		_group = Node3D.new()
		add_child(_group)
	start_center = end_center
	var last := path[path.size() - 1]
	var d_end: Vector2i = last - path[path.size() - 2]
	end_center = last + d_end
	var e_b := end_center - last
	var e_p := Vector2i(-e_b.y, e_b.x)
	var path_set := {}
	for p in path:
		path_set[PathGenerator.key(p)] = true

	var grass := _grass_mat()
	var lip := _mat(0xa8ddb8)
	var dirt := _mat(0xb08968)
	var rock_a := _mat(0x9aa8b5)
	var rock_b := _mat(0x8b98a6)
	var crack := _mat(0x6d7783)
	var moss := _mat(0x6fae7a)
	var stone := _mat(0xcfd3dc)
	var pillar := _mat(0x98a0b0)
	var rune := _mat(0xe8dcb0)

	var e_notch := {
		PathGenerator.key(last + e_p): true,
		PathGenerator.key(last - e_p): true,
	}
	_build_island(end_center, path_set, grass, lip, dirt, rock_a, rock_b, crack, moss, e_notch)
	_build_end_ruins(end_center, e_b, e_p, stone, pillar, rune, moss, dirt)
	islands.append(end_center)


## JS isOnIsland: within 1.5 cells of any island centre, in x and z.
func is_on_island(x: float, z: float) -> bool:
	for ic in islands:
		if absf(x - ic.x) <= 1.5 and absf(z - ic.y) <= 1.5:
			return true
	return false


func clear() -> void:
	if _group != null and is_instance_valid(_group):
		_group.queue_free()
	_group = null
	start_center = Vector2i.ZERO
	end_center = Vector2i.ZERO
	islands.clear()