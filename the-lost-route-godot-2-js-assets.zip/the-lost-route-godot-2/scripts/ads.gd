class_name Ads
extends RefCounted

## Test ads through the Poing Studios AdMob plugin (v5.1.0, Google test unit
## IDs). Every entry point degrades to a no-op or an immediate grant when the
## native plugin is missing, so desktop export and the headless suites keep
## working untouched.

const BANNER_ID := "ca-app-pub-3940256099942544/6300978111"
const REWARDED_ID := "ca-app-pub-3940256099942544/5224354917"

static var _started := false
static var _init_done := false
static var _rewarded: RewardedAd
static var _loading := false
static var _busy := false
static var _granted := false
static var _cb: Callable
static var _banner: AdView
static var _banner_desired := false


static func available() -> bool:
	return Engine.has_singleton("PoingGodotAdMob")


## Call once at boot. SDK init is async; loads queue behind it because the
## Next-Gen SDK throws if an ad is requested before initialize() completes.
static func init() -> void:
	if _started or not available():
		return
	_started = true
	var listener := OnInitializationCompleteListener.new()
	listener.on_initialization_complete = func(_status: InitializationStatus) -> void:
		_init_done = true
		_load()  # keep one rewarded ad warm for the first hint/skip tap
		if _banner_desired:
			_banner_show()
	MobileAds.initialize(listener)


static func show_rewarded(cb: Callable) -> void:
	if not available():
		cb.call(true)  # desktop / missing natives: grant, the game must not break
		return
	if _busy:
		cb.call(false)
		return
	_busy = true
	_cb = cb
	_granted = false
	if not _init_done:
		return  # init listener flushes via _load()'s callback
	_show_or_load()


static func set_banner_visible(v: bool) -> void:
	_banner_desired = v
	if not available() or not _init_done:
		return
	if v:
		_banner_show()
	elif _banner:
		_banner.hide()


static func _banner_show() -> void:
	if not _banner_desired:
		return
	if _banner == null:
		var size := AdSize.get_current_orientation_anchored_adaptive_banner_ad_size(
			AdSize.FULL_WIDTH
		)
		_banner = AdView.new(BANNER_ID, size, AdPosition.BOTTOM_RIGHT)
		var listener := AdListener.new()
		listener.on_ad_failed_to_load = func(error: LoadAdError) -> void:
			print("AdMob: banner failed to load: ", error.message)
		_banner.ad_listener = listener
		_banner.load_ad(AdRequest.new())
	else:
		_banner.show()


static func _show_or_load() -> void:
	if _rewarded:
		_show()
	elif not _loading:
		_load()


static func _load() -> void:
	if _loading or _rewarded:
		return
	_loading = true
	var callback := RewardedAdLoadCallback.new()
	callback.on_ad_loaded = func(ad: RewardedAd) -> void:
		_loading = false
		_rewarded = ad
		_setup_content()
		if _busy:
			_show()
	callback.on_ad_failed_to_load = func(error: LoadAdError) -> void:
		_loading = false
		print("AdMob: rewarded failed to load: ", error.message)
		if _busy:
			_finish(false)
	RewardedAdLoader.new().load(REWARDED_ID, AdRequest.new(), callback)


static func _setup_content() -> void:
	var content := _rewarded.full_screen_content_callback
	content.on_ad_dismissed_full_screen_content = func() -> void:
		var ok := _granted
		_rewarded.destroy()
		_rewarded = null
		_load()  # preload the next one while nobody is waiting
		_finish(ok)
	content.on_ad_failed_to_show_full_screen_content = func(error: AdError) -> void:
		print("AdMob: rewarded failed to show: ", error.message)
		_rewarded.destroy()
		_rewarded = null
		_finish(false)


static func _show() -> void:
	var reward := OnUserEarnedRewardListener.new()
	reward.on_user_earned_reward = func(_item: RewardedItem) -> void:
		_granted = true
	_rewarded.show(reward)


static func _finish(ok: bool) -> void:
	_busy = false
	var cb := _cb
	_cb = Callable()
	cb.call(ok)
