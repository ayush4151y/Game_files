class_name Player
extends Node3D

## Port of Player.js - 200ms eased hop with a sine bounce, faces the direction
## of travel, idles with a scale pulse, blinks red while standing on fire.

var current_index := 0
var is_moving := false

var _base_scale := 1.0
var _pulse_t := 0.0

var _moving := false
var _move_t := 0.0
var _move_from := Vector3.ZERO
var _move_to := Vector3.ZERO
var _move_index := 0
var _move_cb := Callable()

var _body_mat: StandardMaterial3D
var _orig_color := Color(0.608, 0.890, 0.937)
var _fire := false
var _fire_t := 0.0

var _face: Node3D


func _process(delta: float) -> void:
	_pulse_t += delta
	if _base_scale > 0.0:
		var s := _base_scale + 0.08 * sin(fmod(_pulse_t, Cfg.PLAYER_IDLE_PULSE_MS / 1000.0) / (Cfg.PLAYER_IDLE_PULSE_MS / 1000.0) * TAU)
		scale = Vector3(s, s, s)

	if _fire and _body_mat != null:
		_fire_t += delta
		if int(_fire_t / 0.14) % 2 == 0:
			_body_mat.albedo_color = Color(1.0, 0.267, 0.267)
			_body_mat.emission_enabled = true
			_body_mat.emission = Color(1.0, 0.133, 0.133)
			_body_mat.emission_energy_multiplier = 0.8
		else:
			_body_mat.albedo_color = _orig_color
			_body_mat.emission_enabled = false

	if not _moving:
		return
	_move_t += delta
	var dur := Cfg.PLAYER_MOVE_MS / 1000.0
	var t := minf(_move_t / dur, 1.0)
	var ease := 1.0 - pow(1.0 - t, 3.0)
	position = _move_from.lerp(_move_to, ease)
	position.y = Cfg.PLAYER_Y + sin(t * PI) * Cfg.PLAYER_MOVE_BOUNCE
	if t < 1.0:
		return
	position = _move_to
	current_index = _move_index
	_moving = false
	is_moving = false
	if _move_cb.is_valid():
		_move_cb.call()


# --- construction ------------------------------------------------------------

func create(start: Vector2i, scale_amount := 1.0) -> void:
	destroy()
	is_moving = false
	_moving = false
	current_index = 0
	_base_scale = scale_amount

	_body_mat = StandardMaterial3D.new()
	_body_mat.albedo_color = _orig_color
	_body_mat.emission_enabled = true
	_body_mat.emission = Color(0.184, 0.714, 0.812)
	_body_mat.emission_energy_multiplier = 0.22
	_body_mat.roughness = 0.35

	var body := MeshInstance3D.new()
	body.mesh = _rounded_cube(0.28)
	body.material_override = _body_mat
	add_child(body)

	_face = _make_face()
	_face.position = Vector3(0.0, 0.0, 0.28 + 0.035)
	add_child(_face)

	position = Vector3(start.x, Cfg.PLAYER_Y, start.y)


## A cube with its 12 edges and 8 corners rounded off, so the player reads as a
## soft toy block instead of a hard-edged box. Built as a superellipsoid: an
## exponent E < 1 pulls the corners in toward a sphere while the flat faces stay
## put. Lower E = boxier, higher E = rounder (E ~ 1 is a sphere).
const ROUND_E := 0.2

func _rounded_cube(half: float) -> ArrayMesh:
	var st := SurfaceTool.new()
	st.begin(Mesh.PRIMITIVE_TRIANGLES)
	var u_seg := 24
	var v_seg := 12
	var grid: Array = []
	for j in range(v_seg + 1):
		var v := -PI * 0.5 + PI * float(j) / float(v_seg)
		var r: Array = []
		for i in range(u_seg + 1):
			var u := TAU * float(i) / float(u_seg)
			r.append(_super_point(u, v) * half)
		grid.append(r)
	for j in range(v_seg):
		for i in range(u_seg):
			var a: Vector3 = grid[j][i]
			var b: Vector3 = grid[j][i + 1]
			var c: Vector3 = grid[j + 1][i]
			var d: Vector3 = grid[j + 1][i + 1]
			for p in [a, b, c, b, d, c]:
				st.add_vertex(p)
	st.index()
	st.generate_normals()
	return st.commit()


func _super_point(u: float, v: float) -> Vector3:
	var cv := _sp(cos(v))
	var sv := _sp(sin(v))
	return Vector3(cv * _sp(cos(u)), cv * _sp(sin(u)), sv)


func _sp(x: float) -> float:
	return signf(x) * pow(absf(x), ROUND_E)


func _make_face() -> Node3D:
	var g := Node3D.new()
	var eye_mat := _flat(Color(0.106, 0.169, 0.212), 0.30)
	var glint_mat := _flat(Color(1, 1, 1), 0.8)
	var cheek_mat := _flat(Color(1.0, 0.561, 0.647), 0.35)
	var blush_mat := _flat(Color(1.0, 0.824, 0.863), 0.3)

	_sphere(g, 0.085, eye_mat, Vector3(-0.105, 0.14, 0.0))
	_sphere(g, 0.085, eye_mat, Vector3(0.105, 0.14, 0.0))
	_sphere(g, 0.028, glint_mat, Vector3(-0.115, 0.165, 0.065))
	_sphere(g, 0.028, glint_mat, Vector3(0.095, 0.165, 0.065))
	_sphere(g, 0.045, cheek_mat, Vector3(-0.2, 0.04, 0.02))
	_sphere(g, 0.045, cheek_mat, Vector3(0.2, 0.04, 0.02))
	_sphere(g, 0.02, blush_mat, Vector3(-0.13, 0.1, 0.06))
	_sphere(g, 0.02, blush_mat, Vector3(0.13, 0.1, 0.06))
	return g


func _flat(color: Color, emissive_energy: float) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.emission_enabled = emissive_energy > 0.0
	m.emission = color
	m.emission_energy_multiplier = emissive_energy
	m.roughness = 0.3
	return m


func _sphere(parent: Node3D, radius: float, mat: Material, pos: Vector3) -> void:
	var mi := MeshInstance3D.new()
	var s := SphereMesh.new()
	s.radius = radius
	s.height = radius * 2.0
	s.radial_segments = 12
	s.rings = 6
	mi.mesh = s
	mi.material_override = mat
	mi.position = pos
	parent.add_child(mi)


# --- behaviour ---------------------------------------------------------------

func set_face_direction(dx: float, dz: float) -> void:
	if _face != null:
		_face.rotation.y = 0.0
	rotation.y = atan2(dx, dz)


func set_fire(on: bool) -> void:
	_fire = on
	if not on and _body_mat != null:
		_body_mat.albedo_color = _orig_color
		_body_mat.emission_enabled = false


func move_to(pos: Vector2i, path_index: int, cb := Callable()) -> void:
	if is_moving:
		return
	is_moving = true
	_moving = true
	_move_t = 0.0
	_move_from = position
	_move_to = Vector3(pos.x, Cfg.PLAYER_Y, pos.y)
	_move_index = path_index
	_move_cb = cb
	set_face_direction(float(pos.x) - position.x, float(pos.y) - position.z)


func destroy() -> void:
	_moving = false
	_fire = false
	_body_mat = null
	_face = null
	_base_scale = 0.0
	for c in get_children():
		remove_child(c)
		c.queue_free()