class_name Snd
extends RefCounted

## Port of GameAudio.js. Same 16 sounds, same three buses (ui / sfx /
## ambience), same per-sound cooldown, same two looping ambience tracks.
## Registered as an autoload so call sites read `Snd.play("ui-click", "ui")`.

## GameAudio.js SOUNDS, in order. step-hop.mp3 also ships in assets/ but the JS
## build never registers or plays it, so it stays unwired here too.
const SOUNDS := {
	"ambience": "res://assets/audio/ambience/ambience-melody-loop.mp3",
	"ambience-island": "res://assets/audio/ambience/ambience-island-loop.mp3",
	"ui-click": "res://assets/audio/ui/ui-click.mp3",
	"ui-back": "res://assets/audio/ui/ui-back.mp3",
	"ui-pause": "res://assets/audio/ui/ui-pause.mp3",
	"ui-toggle": "res://assets/audio/ui/ui-toggle.mp3",
	"cube-rise": "res://assets/audio/sfx/cube-rise.mp3",
	"heart-pickup": "res://assets/audio/sfx/heart-pickup.mp3",
	"hint": "res://assets/audio/sfx/hint.mp3",
	"win": "res://assets/audio/sfx/win.mp3",
	"gameover": "res://assets/audio/sfx/gameover.mp3",
	"camera-rotate": "res://assets/audio/sfx/camera-rotate.mp3",
	"ice-slide": "res://assets/audio/sfx/ice-slide.mp3",
	"fire-warn": "res://assets/audio/sfx/fire-warn.mp3",
	"tnt-fuse": "res://assets/audio/sfx/tnt-fuse.mp3",
	"tnt-boom": "res://assets/audio/sfx/tnt-boom.mp3",
}

const LOOPS := ["ambience", "ambience-island"]

## Static on purpose: an autoload singleton does not exist under `--script`,
## which is how the headless test harness runs, and these calls must work there.

static var muted := false
static var music_volume := 1.0
static var sfx_volume := 1.0

static var _streams := {}
static var _cooling := {}
static var _pool: Array[AudioStreamPlayer] = []
static var _pool_i := 0
static var _loops := {}
static var _buses := {}


## GameAudio.js builds ui / sfx / ambience gain nodes under a master.
static func _buses_ready() -> void:
	if not _buses.is_empty():
		return
	for name in ["ui", "sfx", "ambience"]:
		var idx := AudioServer.get_bus_index(name)
		if idx == -1:
			AudioServer.add_bus()
			idx = AudioServer.bus_count - 1
			AudioServer.set_bus_name(idx, name)
			AudioServer.set_bus_send(idx, "Master")
		_buses[name] = idx


## Headless runs have no output device; allocating playbacks there just leaks
## them at shutdown and makes the tests slow, so sound is a no-op.
static func _can_play() -> bool:
	return not AudioServer.get_output_device_list().is_empty()


static func _voice() -> AudioStreamPlayer:
	var loop := Engine.get_main_loop() as SceneTree
	if _pool.is_empty() or not is_instance_valid(_pool[_pool_i]):
		_pool.clear()
		for _i in range(8):
			var p := AudioStreamPlayer.new()
			loop.root.add_child.call_deferred(p)
			_pool.append(p)
	var v := _pool[_pool_i]
	_pool_i = (_pool_i + 1) % _pool.size()
	return v


## The pool is created during the first play(), which can be while root is still
## wiring up its children, so both the add and the start have to be deferred.
static func _start(p: AudioStreamPlayer) -> void:
	if p.is_inside_tree():
		p.play()
	else:
		p.play.call_deferred()


static func _apply_volumes() -> void:
	_buses_ready()
	var sfx_db := -80.0 if muted else linear_to_db(maxf(sfx_volume, 0.0001))
	var mus_db := -80.0 if muted else linear_to_db(maxf(music_volume, 0.0001))
	if _buses.has("ui"):
		AudioServer.set_bus_volume_db(_buses["ui"], sfx_db)
	if _buses.has("sfx"):
		AudioServer.set_bus_volume_db(_buses["sfx"], sfx_db)
	if _buses.has("ambience"):
		AudioServer.set_bus_volume_db(_buses["ambience"], mus_db)


static func set_muted(v: bool) -> void:
	muted = v
	_apply_volumes()


static func set_music_volume(v: float) -> void:
	music_volume = clampf(v, 0.0, 1.0)
	_apply_volumes()


static func set_sfx_volume(v: float) -> void:
	sfx_volume = clampf(v, 0.0, 1.0)
	_apply_volumes()


static func stream(id: String) -> AudioStream:
	if _streams.has(id):
		return _streams[id]
	var path: String = SOUNDS.get(id, "")
	var s: AudioStream = null
	if path != "":
		var f := FileAccess.open(path, FileAccess.READ)
		if f != null:
			var m := AudioStreamMP3.new()
			m.data = f.get_buffer(f.get_length())
			if m.data.size() > 0:
				s = m
		if s == null and ResourceLoader.exists(path):
			s = ResourceLoader.load(path) as AudioStream
	_streams[id] = s
	return s


## GameAudio.js play(id, group, volume, cooldown_ms).
static func play(id: String, group := "sfx", volume := 1.0, cooldown := 0) -> void:
	if muted or not SOUNDS.has(id) or not _can_play():
		return
	if cooldown > 0:
		var now := Time.get_ticks_msec()
		if now - int(_cooling.get(id, 0)) < cooldown:
			return
		_cooling[id] = now
	_buses_ready()
	var s := stream(id)
	if s == null:
		return
	var p := _voice()
	p.stream = s
	p.bus = group if _buses.has(group) else "Master"
	p.volume_db = linear_to_db(clampf(volume, 0.0001, 1.0))
	_start(p)


## GameAudio.js startLoop / stopLoop. Volume defaults to 0.45 there.
static func start_loop(id: String, volume := 0.45) -> void:
	if muted or not LOOPS.has(id) or _loops.has(id) or not _can_play():
		return
	_buses_ready()
	var s := stream(id)
	if s == null:
		return
	var p := AudioStreamPlayer.new()
	var tree := Engine.get_main_loop() as SceneTree
	tree.root.add_child.call_deferred(p)
	# a loop still holding its stream at exit leaks the MP3 and its playback, and
	# the static dict would outlive the node, so drop the reference here too
	tree.root.tree_exiting.connect(func() -> void:
		if is_instance_valid(p):
			p.stop()
			p.stream = null
		_loops.erase(id))
	p.stream = s
	p.bus = "ambience"
	p.volume_db = linear_to_db(clampf(volume, 0.0001, 1.0))
	# raw mp3 needs a frame count for loop_end, so just restart on finished
	p.finished.connect(func() -> void:
		if is_instance_valid(p) and _loops.get(id) == p:
			_start(p))
	_start(p)
	_loops[id] = p


static func stop_loop(id: String) -> void:
	if not _loops.has(id):
		return
	var p: AudioStreamPlayer = _loops[id]
	if is_instance_valid(p):
		p.stop()
		p.queue_free()
	_loops.erase(id)


static func stop_all_loops() -> void:
	for id in _loops.keys():
		stop_loop(id)
