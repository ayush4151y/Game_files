class_name Art
extends RefCounted

## Loads the art that actually ships with the JS build (assets/) so the Godot
## port looks identical instead of approximating it with generated noise.
## The rules below are transcribed from CubeGrid.js TEXTURE_FILES /
## CUBE_MATERIALS and from the inline <svg> icons in index.html.

const FA_SOLID := "res://fonts/fa-solid-900.ttf"

## CubeGrid.js TEXTURE_FILES: the top face (mesh surface 2) takes `top`, the
## other five faces take `side`. A missing key falls back to `all`.
const BLOCK_TEXTURES := {
	Cfg.T_GRASS: {"top": "res://assets/texture/grass_top.jpg", "side": "res://assets/texture/grass_side.jpg"},
	Cfg.T_ICE: {"all": "res://assets/texture/ice.jpeg"},
	Cfg.T_FIRE: {"all": "res://assets/texture/fire.png"},
	Cfg.T_TNT: {"top": "res://assets/texture/tnt_top.jpg", "side": "res://assets/texture/tnt_face.jpg"},
	Cfg.T_START: {"top": "res://assets/texture/start_top.jpg", "side": "res://assets/texture/side_face.jpg"},
	Cfg.T_END: {"top": "res://assets/texture/end_top.jpg", "side": "res://assets/texture/end_face.jpg"},
}

## CubeGrid.js CUBE_MATERIALS shininess. Godot wants roughness, so convert.
const BLOCK_SHININESS := {
	Cfg.T_GRASS: 60.0,
	Cfg.T_ICE: 120.0,
	Cfg.T_FIRE: 60.0,
	Cfg.T_TNT: 30.0,
	Cfg.T_HEART: 90.0,
}

## index.html icon paths, copied verbatim.
const ICON_SVG := {
	"back": '<path d="M19 12H5M12 19l-7-7 7-7"/>',
	"pause": '<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>',
	"rotate": '<path d="M21 12a9 9 0 1 1-2.64-6.36"/><path d="M21 3v6h-6"/><rect x="8.5" y="8.5" width="7" height="7" rx="1.5"/>',
	"hint": '<path d="M9 18h6M10 21h4M12 2a7 7 0 0 0-7 7c0 2.38 1.19 4.47 3 5.74V17h8v-2.26c1.81-1.27 3-3.36 3-5.74a7 7 0 0 0-7-7z"/><path d="M9 15v-2a4 4 0 0 1-4-4 5 5 0 0 1 5-5 7 7 0 0 1 7 7 4 4 0 0 1-4 4v2"/>',
	"skip": '<path d="M5 4l10 8-10 8V4zM19 5v14"/>',
	"up": '<path d="M12 19V5M5 12l7-7 7 7"/>',
	"down": '<path d="M12 5v14M5 12l7 7 7-7"/>',
	"left": '<path d="M19 12H5M12 19l-7-7 7-7"/>',
	"right": '<path d="M5 12h14M12 5l7 7-7 7"/>',
	"lock": '<path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1s3.1 1.39 3.1 3.1v2z" fill="currentColor" stroke="none"/>',
	"pause_circle": '<circle cx="12" cy="12" r="10"/><path d="M10 8v8M14 8v8"/>',
}

## FontAwesome codepoints for the <i class="fa-solid ..."> glyphs in index.html.
const FA_GLYPH := {
	"heart": 0xf004,
	"fa-arrow-up": 0xf062,
	"fa-arrow-down": 0xf063,
	"fa-hand-pointer": 0xf25a,
}

static var _tex: Dictionary = {}
static var _icon: Dictionary = {}
static var _fa: FontFile = null
static var _unit_cube: ArrayMesh = null


## Read the shipped file straight off disk first: on a fresh clone the editor
## has not imported anything yet, and ResourceLoader only knows about imports.
## In an exported build the raw file is gone, so fall back to the import.
## Image.load() trusts the extension, and the JS build ships sky.png / fire.png
## as JPEG data under a .png name, so sniff the magic bytes instead.
static func tex(path: String) -> Texture2D:
	if _tex.has(path):
		return _tex[path]
	var t: Texture2D
	var f := FileAccess.open(path, FileAccess.READ)
	if f != null:
		var bytes := f.get_buffer(f.get_length())
		var img := Image.new()
		var err := ERR_FILE_CORRUPT
		if bytes.size() > 3 and bytes[0] == 0xFF and bytes[1] == 0xD8:
			err = img.load_jpg_from_buffer(bytes)
		elif bytes.size() > 8 and bytes[0] == 0x89 and bytes[1] == 0x50:
			err = img.load_png_from_buffer(bytes)
		elif bytes.size() > 3 and bytes[0] == 0x47 and bytes[1] == 0x49:
			err = img.load_webp_from_buffer(bytes)
		if err == OK:
			img.generate_mipmaps()
			t = ImageTexture.create_from_image(img)
	if t == null:
		t = ResourceLoader.load(path) as Texture2D
	_tex[path] = t
	return t


## Returns the block's [top, side] materials, or null when the type has no
## texture (heart) and should keep its flat colour.
static func block_mats(type: String) -> Array:
	if not BLOCK_TEXTURES.has(type):
		return []
	var files: Dictionary = BLOCK_TEXTURES[type]
	var rough: float = 1.0 - float(BLOCK_SHININESS.get(type, 60.0)) / 128.0
	var out: Array = []
	for face in ["top", "side"]:
		var m := StandardMaterial3D.new()
		# getTypeMaterial() passes only `map`, so three.js keeps its default white
		# diffuse. Tinting with def.color here double-tints the shipped texture.
		m.albedo_color = Color.WHITE
		m.roughness = clampf(rough, 0.06, 1.0)
		var src: String = files.get(face, files.get("all", ""))
		if src != "":
			var t := tex(src)
			if t != null:
				m.albedo_texture = t
		out.append(m)
	return out


## Unit cube with one surface per face in three.js BoxGeometry order, so
## surface 2 is the top and can take its own texture. BoxMesh is a single
## surface and cannot express that.
static func unit_cube() -> ArrayMesh:
	if _unit_cube != null:
		return _unit_cube
	# Corners run bottom-left, bottom-right, top-right, top-left as seen from
	# OUTSIDE the face, so the shared UV quad below lands upright on all six.
	# Running them along the face's own horizontal axis is what keeps the grass
	# side texture from coming out rotated 90 degrees on the X faces.
	var faces := [
		[Vector3(1, 0, 0), [Vector3(0.5, -0.5, 0.5), Vector3(0.5, -0.5, -0.5), Vector3(0.5, 0.5, -0.5), Vector3(0.5, 0.5, 0.5)]],
		[Vector3(-1, 0, 0), [Vector3(-0.5, -0.5, -0.5), Vector3(-0.5, -0.5, 0.5), Vector3(-0.5, 0.5, 0.5), Vector3(-0.5, 0.5, -0.5)]],
		[Vector3(0, 1, 0), [Vector3(-0.5, 0.5, 0.5), Vector3(0.5, 0.5, 0.5), Vector3(0.5, 0.5, -0.5), Vector3(-0.5, 0.5, -0.5)]],
		[Vector3(0, -1, 0), [Vector3(-0.5, -0.5, 0.5), Vector3(0.5, -0.5, 0.5), Vector3(0.5, -0.5, -0.5), Vector3(-0.5, -0.5, -0.5)]],
		[Vector3(0, 0, 1), [Vector3(-0.5, -0.5, 0.5), Vector3(0.5, -0.5, 0.5), Vector3(0.5, 0.5, 0.5), Vector3(-0.5, 0.5, 0.5)]],
		[Vector3(0, 0, -1), [Vector3(0.5, -0.5, -0.5), Vector3(-0.5, -0.5, -0.5), Vector3(-0.5, 0.5, -0.5), Vector3(0.5, 0.5, -0.5)]],
	]
	var am := ArrayMesh.new()
	for f in faces:
		var n: Vector3 = f[0]
		var v: Array = f[1]
		var verts := PackedVector3Array()
		var norms := PackedVector3Array()
		var uvs := PackedVector2Array()
		var uvs_of := [Vector2(0, 1), Vector2(1, 1), Vector2(1, 0), Vector2(0, 0)]
		for i in range(4):
			verts.append(v[i])
			norms.append(n)
			uvs.append(uvs_of[i])
		var arrays := []
		arrays.resize(Mesh.ARRAY_MAX)
		arrays[Mesh.ARRAY_VERTEX] = verts
		arrays[Mesh.ARRAY_NORMAL] = norms
		arrays[Mesh.ARRAY_TEX_UV] = uvs
		# Godot's front faces wind clockwise seen from outside, so the right-hand
		# rule normal points inward (verified against BoxMesh). Four of the six
		# quads were wound the other way and got back-face culled, which is why
		# nothing drew on top of a cube and grass only ever showed its side.
		# Reversing the index order flips the winding but keeps every corner on
		# its own UV, so nothing is mirrored.
		var order := PackedInt32Array([0, 1, 2, 0, 2, 3])
		if (v[1] - v[0]).cross(v[2] - v[0]).dot(n) > 0.0:
			order = PackedInt32Array([0, 2, 1, 0, 3, 2])
		arrays[Mesh.ARRAY_INDEX] = order
		am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	_unit_cube = am
	return am


## Rasterises an index.html icon at `px`, tinted `col`.
static func icon(name: String, px: int, col := Color.WHITE) -> ImageTexture:
	var key := "%s@%d@%s" % [name, px, col.to_html(false)]
	if _icon.has(key):
		return _icon[key]
	var body: String = ICON_SVG.get(name, "")
	# to_html() has no leading '#', and SVG will not parse a bare hex colour
	var svg := '<svg viewBox="0 0 24 24" width="%d" height="%d" fill="none" stroke="#%s" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">%s</svg>' % [px, px, col.to_html(false), body]
	var img := Image.new()
	if img.load_svg_from_string(svg, 1.0) != OK:
		_icon[key] = null
		return null
	_icon[key] = ImageTexture.create_from_image(img)
	return _icon[key]


## The real FontAwesome 6 solid face that ships with the JS build. Hand this to
## a Label's `theme_override_fonts/font` and set the text to FA.char("heart") —
## TextServer rasterises the PUA glyph, so no manual glyph plumbing is needed.
## Read the ttf straight off disk rather than through ResourceLoader: a fresh
## checkout has no .import yet, and the editor cannot import it under --headless,
## so the hearts and settings glyphs came out empty until the project was opened
## in the editor once.
static func fa_font() -> FontFile:
	if _fa == null:
		var f := FileAccess.open(FA_SOLID, FileAccess.READ)
		if f != null:
			var ff := FontFile.new()
			if ff.load_dynamic_font(FA_SOLID) == OK:
				_fa = ff
		if _fa == null and ResourceLoader.exists(FA_SOLID):
			_fa = ResourceLoader.load(FA_SOLID) as FontFile
	return _fa


static func fa_text(name: String) -> String:
	return char(FA_GLYPH[name]) if FA_GLYPH.has(name) else ""

