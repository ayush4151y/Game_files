class_name Save
extends RefCounted

## Progress + settings, mirroring the JS localStorage keys in GameManager.js.
## Backed by a plain ConfigFile under user:// so nothing is lost between runs.
## ponytail: no audio settings, this port ships no audio at all.

const FILE := "user://lost_route.cfg"

const K_COMPLETED := "rak_completed"
const K_LEVEL := "rak_level"
const K_SKIPPED := "rak_skipped"
const K_BEST_ENDLESS := "rak_best_endless"
const K_DAILY_LAST := "rak_daily_last"
const K_DAILY_STREAK := "rak_daily_streak"
const K_TUTORIAL := "rak_tutorial"
const K_INPUT := "rak_input"

static var _cfg: ConfigFile


static func _f() -> ConfigFile:
	if _cfg == null:
		_cfg = ConfigFile.new()
		_cfg.load(FILE)
	return _cfg


static func flush() -> void:
	_f().save(FILE)


static func _ints(key: String) -> Array[int]:
	var out: Array[int] = []
	var raw: Variant = _f().get_value("progress", key, [])
	if raw is Array or raw is PackedInt32Array:
		for v in raw:
			out.append(int(v))
	return out


static func _set_ints(key: String, values: Array[int]) -> void:
	_f().set_value("progress", key, values)
	flush()


static func completed() -> Array[int]:
	return _ints(K_COMPLETED)


static func mark_completed(level: int) -> void:
	var c := completed()
	if not c.has(level):
		c.append(level)
		c.sort()
		_set_ints(K_COMPLETED, c)


static func skipped() -> Array[int]:
	return _ints(K_SKIPPED)


static func mark_skipped(level: int) -> void:
	var s := skipped()
	if not s.has(level):
		s.append(level)
		s.sort()
		_set_ints(K_SKIPPED, s)


static func current_level() -> int:
	return int(_f().get_value("progress", K_LEVEL, 1))


static func set_current_level(level: int) -> void:
	_f().set_value("progress", K_LEVEL, level)
	flush()


static func best_endless() -> int:
	return int(_f().get_value("progress", K_BEST_ENDLESS, 0))


static func set_best_endless(v: int) -> void:
	_f().set_value("progress", K_BEST_ENDLESS, v)
	flush()


## YYYYMMDD in local time, same as JS todayKey().
static func today_key() -> int:
	var d := Time.get_date_dict_from_system()
	return int(d["year"]) * 10000 + int(d["month"]) * 100 + int(d["day"])


static func daily_last() -> int:
	return int(_f().get_value("progress", K_DAILY_LAST, 0))


static func daily_streak() -> int:
	return int(_f().get_value("progress", K_DAILY_STREAK, 0))


static func is_daily_done() -> bool:
	return daily_last() == today_key()


## JS markDailyComplete. A gap of more than one day restarts the streak at 1.
static func mark_daily_complete() -> void:
	var today := today_key()
	if daily_last() == today:
		return
	var streak := daily_streak() + 1 if daily_last() == today - 1 else 1
	_f().set_value("progress", K_DAILY_STREAK, streak)
	_f().set_value("progress", K_DAILY_LAST, today)
	flush()


## JS dateLabel: "5 Oct".
static func date_label() -> String:
	var d := Time.get_date_dict_from_system()
	const MONTHS := ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
	return str(int(d["day"])) + " " + MONTHS[int(d["month"]) - 1]


static func tutorial_seen() -> bool:
	return int(_f().get_value("settings", K_TUTORIAL, 0)) == 1


static func set_tutorial_seen() -> void:
	_f().set_value("settings", K_TUTORIAL, 1)
	flush()


static func input_mode() -> String:
	# default is D-pad only (JS default). "both" made swipe and the pad live at
	# once on a fresh save, which is the "both inputs work" bug.
	return str(_f().get_value("settings", K_INPUT, "dpad"))


static func set_input_mode(mode: String) -> void:
	_f().set_value("settings", K_INPUT, mode)
	flush()


## JS resetProgress: clears progress, keeps input mode and the tutorial flag.
static func reset_progress() -> void:
	for key in [K_COMPLETED, K_SKIPPED, K_LEVEL, K_BEST_ENDLESS, K_DAILY_LAST, K_DAILY_STREAK]:
		_f().set_value("progress", key, null)
	flush()