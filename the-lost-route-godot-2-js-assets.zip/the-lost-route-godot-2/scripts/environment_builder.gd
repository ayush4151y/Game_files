class_name EnvironmentBuilder
extends Node3D

## Port of Environment.js - gradient sky, drifting cloud layers, distant
## islands, falling leaves, butterflies and circling birds. Everything is
## procedural geometry; no assets.

var _env: Environment
var _clouds: Array = []
var _drift: Array = []
var _leaves: Array = []
var _butterflies: Array = []
var _birds: Array = []
var _rng := Rng.mulberry(123456789)
var _t := 0.0


func build() -> void:
	_build_sky()
	_build_cloud_layers()
	_build_distant_islands()
	_build_leaves()
	_build_butterflies()
	_build_birds()


func _process(delta: float) -> void:
	_t += delta
	for c in _clouds:
		c["node"].position.x += c["speed"] * c["dir"] * delta
		if absf(c["node"].position.x) > c["wrap"]:
			c["dir"] = -c["dir"]
	for d in _drift:
		d["node"].position.x += d["speed"] * d["dir"] * delta
		if absf(d["node"].position.x) > d["wrap"]:
			d["dir"] = -d["dir"]
	for leaf in _leaves:
		var n: Node3D = leaf["node"]
		n.position.y -= leaf["vy"] * delta
		n.position.x += sin(_t * leaf["sway"] + leaf["phase"]) * delta * 0.6
		n.position.z += cos(_t * leaf["sway"] * 0.8 + leaf["phase"]) * delta * 0.4
		n.rotation.z += leaf["rot"] * delta
		if n.position.y < -1.5:
			n.position.y = 20.0
			n.position.x = (_rng.next() - 0.5) * 46.0
			n.position.z = (_rng.next() - 0.5) * 46.0
	for b in _butterflies:
		var n: Node3D = b["node"]
		n.position.x = b["cx"] + sin(_t * 0.7 + b["phase"]) * 1.2
		n.position.y = 5.0 + sin(_t * 1.4 + b["phase"] * 2.0) * 0.6
		n.position.z = b["cz"] + cos(_t * 0.7 + b["phase"]) * 1.2
		var flap := sin(_t * 12.0 + b["phase"]) * 0.6
		n.get_child(0).rotation.z = flap
		n.get_child(1).rotation.z = -flap
	for i in range(_birds.size()):
		var b: Dictionary = _birds[i]
		b["angle"] += b["speed"] * delta
		var n: Node3D = b["node"]
		n.position.x = cos(b["angle"]) * b["radius"]
		n.position.z = sin(b["angle"]) * b["radius"]
		n.position.y = b["y_base"] + sin(_t * 2.0 + i) * 1.2


# --- sky / fog ---------------------------------------------------------------

func _build_sky() -> void:
	_env = Environment.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.42, 0.71, 0.86)
	sky_mat.sky_horizon_color = Color(1.0, 0.874, 0.659)
	sky_mat.sky_curve = 0.15
	sky_mat.ground_bottom_color = Color(0.863, 0.933, 0.957)
	sky_mat.ground_horizon_color = Color(1.0, 0.874, 0.659)
	sky_mat.sun_angle_max = 30.0
	sky_mat.energy_multiplier = 1.0

	var sky := Sky.new()
	sky.sky_material = sky_mat

	_env.background_mode = Environment.BG_SKY
	_env.sky = sky
	_env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	_env.ambient_light_color = Color(0.624, 0.784, 0.910)
	_env.ambient_light_energy = 0.55
	_env.tonemap_mode = Environment.TONE_MAPPER_ACES
	_env.tonemap_exposure = 1.05
	# ponytail: three.js Fog(near, far) is linear, so this must be
	# FOG_MODE_DEPTH. Godot defaults to FOG_MODE_EXPONENTIAL, where
	# fog_density 1.0 whites out the whole scene.
	_env.fog_mode = Environment.FOG_MODE_DEPTH
	_env.fog_enabled = false
	_env.fog_light_color = Color(0.737, 0.827, 0.878)
	_env.fog_depth_begin = 42.0
	_env.fog_depth_end = 120.0
	_env.fog_density = 0.0

	var we := WorldEnvironment.new()
	we.environment = _env
	add_child(we)


func set_fog(on: bool) -> void:
	if _env != null:
		_env.fog_enabled = on


func _unshaded(color: Color, opacity := 1.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(color.r, color.g, color.b, opacity)
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	if opacity < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	return m


func _box(size: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var b := BoxMesh.new()
	b.size = size
	b.material = mat
	mi.mesh = b
	return mi


func _ball(radius: float, mat: Material, seg := 6) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var s := SphereMesh.new()
	s.radius = radius
	s.height = radius * 2.0
	s.radial_segments = seg
	s.rings = 3
	s.material = mat
	mi.mesh = s
	return mi


func _quad(size: Vector2, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var q := QuadMesh.new()
	q.size = size
	q.material = mat
	mi.mesh = q
	return mi


# --- scenery -----------------------------------------------------------------

func _build_cloud_layers() -> void:
	var layers := [
		{"count": 7, "y": 52.0, "speed": 0.05, "opacity": 0.4, "scale_min": 2.4, "width": 3.4, "wrap": 145.0},
		{"count": 5, "y": 64.0, "speed": 0.14, "opacity": 0.6, "scale_min": 1.7, "width": 2.4, "wrap": 125.0},
		{"count": 3, "y": 78.0, "speed": 0.3, "opacity": 0.85, "scale_min": 1.2, "width": 1.8, "wrap": 105.0},
	]
	for layer in layers:
		var mat := _unshaded(Color(1, 1, 1), layer["opacity"])
		for _i in range(int(layer["count"])):
			var g := Node3D.new()
			var n := 2 + int(_rng.next() * 3.0)
			for j in range(n):
				if j % 2 == 1:
					var w: float = layer["width"] * (0.8 + _rng.next() * 0.9)
					var b := _box(Vector3(w, layer["scale_min"] / 2.0, layer["width"] * (0.7 + _rng.next() * 0.6)), mat)
					b.position = Vector3((j - n / 2.0) * w * 0.7, (_rng.next() - 0.5) * 0.5, (_rng.next() - 0.5) * 1.4)
					g.add_child(b)
				else:
					var s: float = layer["scale_min"] * (1.0 + _rng.next() * 1.2)
					var b := _ball(s, mat)
					b.scale = Vector3(s, s * 0.5, s * 0.6)
					b.position = Vector3((j - n / 2.0) * s * 1.4, (_rng.next() - 0.5) * 0.5, (_rng.next() - 0.5) * 1.2)
					g.add_child(b)
			var a := _rng.next() * TAU
			var r := 30.0 + _rng.next() * (float(layer["wrap"]) - 30.0)
			g.position = Vector3(cos(a) * r, float(layer["y"]) + (_rng.next() - 0.5) * 7.0, sin(a) * r)
			add_child(g)
			_clouds.append({"node": g, "speed": layer["speed"], "wrap": layer["wrap"], "dir": 1.0 if _rng.next() < 0.5 else -1.0})


func _build_distant_islands() -> void:
	var colors := [Color(0.78, 0.90, 0.886), Color(0.839, 0.851, 0.937),
		Color(0.953, 0.863, 0.784), Color(0.784, 0.843, 0.918)]
	for i in range(9):
		var mat := _unshaded(colors[i % 4], 0.12)
		var g := Node3D.new()
		var s := 2.5 + _rng.next() * 5.0
		var layers := 2 + int(_rng.next() * 3.0)
		for j in range(layers):
			var w: float = s * (1.0 - j * 0.22)
			var b := _box(Vector3(w, 0.5 + (layers - j) * 0.4, w), mat)
			b.position = Vector3((_rng.next() - 0.5) * w, 0.4 + j, (_rng.next() - 0.5) * w)
			g.add_child(b)
		var cone := MeshInstance3D.new()
		var cyl := CylinderMesh.new()
		cyl.top_radius = 0.0
		cyl.bottom_radius = s * 0.4
		cyl.height = s * 0.8
		cyl.radial_segments = 5
		cyl.material = mat
		cone.mesh = cyl
		cone.position.y = layers
		g.add_child(cone)
		var a := _rng.next() * TAU
		var r := 90.0 + _rng.next() * 50.0
		g.position = Vector3(cos(a) * r, 3.0 + _rng.next() * 6.0, sin(a) * r)
		add_child(g)
		_drift.append({"node": g, "speed": 0.02 + _rng.next() * 0.04, "wrap": 160.0,
			"dir": 1.0 if _rng.next() < 0.5 else -1.0})


func _build_leaves() -> void:
	var colors := [Color(0.659, 0.847, 0.510), Color(0.788, 0.902, 0.690), Color(0.561, 0.761, 0.478)]
	for i in range(16):
		var mat := _unshaded(colors[i % 3], 0.85)
		var m := _box(Vector3(0.09, 0.02, 0.11), mat)
		m.position = Vector3((_rng.next() - 0.5) * 46.0, 6.0 + _rng.next() * 14.0, (_rng.next() - 0.5) * 46.0)
		add_child(m)
		_leaves.append({"node": m, "vy": 0.35 + _rng.next() * 0.5,
			"sway": 0.4 + _rng.next() * 0.8, "phase": _rng.next() * 6.0, "rot": _rng.next() * 6.0})


func _build_butterflies() -> void:
	var mat := _unshaded(Color(0.941, 0.655, 0.784), 0.9)
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	for _i in range(4):
		var g := Node3D.new()
		var w1 := _quad(Vector2(0.16, 0.2), mat)
		var w2 := _quad(Vector2(0.16, 0.2), mat)
		w2.rotation.y = PI
		g.add_child(w1)
		g.add_child(w2)
		g.position = Vector3((_rng.next() - 0.5) * 30.0, 4.0 + _rng.next() * 3.0, (_rng.next() - 0.5) * 30.0)
		add_child(g)
		_butterflies.append({"node": g, "phase": _rng.next() * 6.0,
			"cx": g.position.x, "cz": g.position.z})


func _build_birds() -> void:
	var mat := _unshaded(Color(0.227, 0.290, 0.353), 1.0)
	mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	for _i in range(3):
		var g := Node3D.new()
		var w1 := _quad(Vector2(0.6, 0.35), mat)
		var w2 := _quad(Vector2(0.6, 0.35), mat)
		w2.rotation.y = PI
		g.add_child(w1)
		g.add_child(w2)
		var a := _rng.next() * TAU
		g.position = Vector3(cos(a) * 15.0, 8.0 + _rng.next() * 4.0, sin(a) * 15.0)
		add_child(g)
		_birds.append({"angle": a, "node": g, "radius": 12.0 + _rng.next() * 10.0,
			"speed": 0.15 + _rng.next() * 0.15, "y_base": g.position.y})