class_name UI
extends CanvasLayer

## Port of the index.html / UIController.js UI, laid out from the real CSS
## numbers. The project stretches the canvas (canvas_items + expand, 1280x720
## base) so one unit is one CSS pixel here, exactly as the JS layout assumes,
## and the `--ui-ctrl` media tiers map onto the viewport height.

enum Screen { NONE, MENU, LEVELS, SETTINGS }

const TOTAL_LEVELS := 200
## levels stacked into each column of the level-select strip, and how many
## columns are on screen at once (the strip scrolls sideways past that)
const LEVELS_PER_LINE := 8
const LEVEL_COLUMNS := 3
const ACTION_BTN := 56.0
const CTRL_TIER_A := 84.0
const CTRL_TIER_B := 60.0
const CTRL_TIER_C := 56.0
const CONTROLS_BOTTOM_A := 80.0
const CONTROLS_BOTTOM_B := 8.0
const CONTROLS_BOTTOM_C := 4.0
const CARD_W := 380.0
const CARD_H := 360.0
## settings is a card now, not a screen: input toggle, two sliders, sound,
## tutorial, reset and a DONE, all inside a box a phone can still fit
const SETTINGS_W := 540.0
const SETTINGS_H := 610.0
## CSS parks the top-bar and control buttons 15-24px off the edge, which was
## fine for a letterboxed web layout but lands them inside the curved corner
## dead zone of a phone, where taps only land sometimes. Same clearance for
## every edge-anchored button, measured from both edges so nothing sits in a
## corner.
const EDGE_PAD := 48.0
const INFO_TOP_A := EDGE_PAD
const INFO_TOP_B := 6.0
const TAP_PAD_A := 200.0
const TAP_PAD_B := 110.0
const TAP_PAD_C := 80.0
# cap for an 8-per-row grid: (1280 - 2*16 pad - 7*12 gap) / 8 = ~145px cells
const GRID_MIN_A := 150.0
const GRID_MIN_B := 76.0
const GRID_MIN_C := 64.0
const GRID_GAP_A := 12.0
const GRID_GAP_B := 6.0
const GRID_GAP_C := 4.0

## style.css light theme: .ctrl-btn / .icon-btn ink - dark enough to read on a
## white tile without the dead weight of pure black
const COL_INK := Color(0.169, 0.227, 0.275)
const COL_INK_DEEP := Color(0.059, 0.165, 0.239)
const COL_MUTED := Color(0.490, 0.545, 0.588)
const COL_TEAL := Color(0.055, 0.604, 0.650)
const COL_BG_TOP := Color(0.812, 0.914, 0.973)
const COL_BG_BOTTOM := Color(0.984, 0.933, 0.796)
const COL_CARD := Color(1, 1, 1)
const COL_DANGER := Color(0.839, 0.271, 0.271)
const COL_SUCCESS := Color(0.122, 0.616, 0.388)

## The JS CSS was authored against a 2400px-wide phone screen; this project's
## base viewport is 1280, so art offsets get scaled down to match.
# menu art is authored in the JS 1920x1080 stage, so scale into our 1280 base.
# (2400 was the .rays width, not the stage - using it made the whole home ~20% small)
const CSS_SCALE := 1280.0 / 1920.0

## #hearts colour, and the CSS empty-heart tint.
const HEART_COL := Color(1.0, 0.322, 0.322)
const HEART_EMPTY := Color(1, 1, 1, 0.18)

var gm

var screen := Screen.NONE

var _root: Control

var _level_pill: Label
var _phase_label: Label
var _hearts: Array[Label] = []
var _heart_box: HBoxContainer

var _pause_btn: Button
var _skip_btn: Button
var _hint_btn: Button
var _hint_badge: Label
var _rotate_btn: Button
var _dpad := {}
var _tnt_btn := {}

var _tap_overlay: Control
var _tap_label: Label

var _pause_popup: Dictionary
var _win_popup: Dictionary
var _over_popup: Dictionary
var _exit_popup: Dictionary
var _ad_popup: Dictionary
var _ad_yes: Callable
var _ad_no: Callable

var _menu_screen: Control
var _levels_screen: Control
var _settings_pop: Dictionary
## the screen the settings card was raised over, so closing it lands back there
var _settings_from := Screen.MENU
var _level_strip: VBoxContainer
var _level_scroll: ScrollContainer
var _dpad_option: Button
var _swipe_option: Button
var _sound_btn: Button
var _sound_on := true

var _tut_banner: PanelContainer
var _tut_label: Label

var _fire_bar: Control
var _fire_fill: ColorRect
var _swipe_start: Variant = null
var _move_lock_until := 0


func build(game_manager) -> void:
	gm = game_manager
	layer = 10
	_build_tap_overlay()
	_root = Control.new()
	_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)
	_build_transition()

	_build_hud()
	_build_action_buttons()
	_build_dpad()
	_build_fire_bar()
	_build_tutorial_banner()
	_build_popups()
	_build_menu()
	_build_levels()
	_build_settings()
	get_viewport().size_changed.connect(_relayout)
	_relayout()
	hide_all()


## Layout units, i.e. what the JS media queries measure. Under a canvas_items
## stretch, `viewport.size` is the raw device window (so a 2340x1080 phone would
## pick the wrong --ui-ctrl tier and misplace every offset); get_visible_rect()
## is the post-stretch space, where the base is 1280x720.
func _vp() -> Vector2:
	var vp := get_viewport()
	return Vector2(vp.get_visible_rect().size) if vp != null else Vector2(1280, 720)


## Mirrors the JS media tiers: short viewports get the smaller control set.
func _tier() -> int:
	var h := _vp().y
	if h <= 360.0:
		return 2
	if h <= 480.0:
		return 1
	return 0


func _ctrl_size() -> float:
	match _tier():
		0: return CTRL_TIER_A
		1: return CTRL_TIER_B
	return CTRL_TIER_C


func _controls_bottom() -> float:
	match _tier():
		0: return CONTROLS_BOTTOM_A
		1: return CONTROLS_BOTTOM_B
	return CONTROLS_BOTTOM_C


func _tap_pad() -> float:
	match _tier():
		0: return TAP_PAD_A
		1: return TAP_PAD_B
	return TAP_PAD_C


func _info_top() -> float:
	return INFO_TOP_A if _tier() == 0 else INFO_TOP_B


## The project already stretches the canvas, so scaling _root on top of that
## shrank every control twice and pinned the whole HUD into the top-left corner.
## All this has to do is re-run layout against the current viewport.
func _relayout() -> void:
	_layout_hud()
	_layout_controls()
	_layout_popups()
	_layout_screens()


# --- construction ------------------------------------------------------------

func _place(c: Control, ax: float, ay: float, w: float, h: float, ox := 0.0, oy := 0.0) -> void:
	c.anchor_left = ax
	c.anchor_top = ay
	c.anchor_right = ax
	c.anchor_bottom = ay
	# ox/oy are insets from the anchored edge, the same values the CSS carried
	# (`right: 24px`, `bottom: 105px`), and a 0.5 anchor centres the box. Adding
	# them as plain offsets pushed everything off screen, which is why the home
	# screen rendered as bare background with no buttons on it.
	var x := -w * 0.5 if ax == 0.5 else (-w - ox if ax > 0.5 else ox)
	var y := -h * 0.5 if ay == 0.5 else (-h - oy if ay > 0.5 else oy)
	c.offset_left = x
	c.offset_top = y
	c.offset_right = x + w
	c.offset_bottom = y + h


## CSS gave the menu art a width and let the image set the height. A zero height
## rect draws nothing at all, so the height has to come from the art.
func _art_h(w: float, tex: Texture2D) -> float:
	if tex == null:
		return 0.0
	var t := tex.get_size()
	return w * t.y / t.x


func _center(c: Control, w: float, h: float) -> void:
	c.anchor_left = 0.5
	c.anchor_top = 0.5
	c.anchor_right = 0.5
	c.anchor_bottom = 0.5
	c.offset_left = -w * 0.5
	c.offset_top = -h * 0.5
	c.offset_right = w * 0.5
	c.offset_bottom = h * 0.5


func _label(text: String, size: int, color: Color, center := true) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if center:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.autowrap_mode = TextServer.AUTOWRAP_OFF
	return l


func _button(text: String, w: float, h: float, font := 22) -> Button:
	var b := Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", font)
	# the background is a pale blue-to-cream gradient, so white type on a white
	# tile disappears. style.css paints the light-theme controls #2b3a46: dark
	# enough to read, not the dead weight of pure black
	b.add_theme_color_override("font_color", COL_INK)
	b.add_theme_color_override("font_hover_color", COL_INK)
	b.add_theme_color_override("font_pressed_color", COL_INK)
	b.custom_minimum_size = Vector2(w, h)
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(1, 1, 1, 0.72)
	# round the ends on anything wide enough to have ends; a square icon button
	# at h/2 would be a circle, so those keep a firm (but larger) radius
	sb.set_corner_radius_all(int(h * 0.5) if w >= h * 1.6 else int(maxf(8.0, h * 0.35)))
	sb.set_border_width_all(2)
	sb.border_color = Color(0.353, 0.549, 0.647, 0.4)
	sb.set_content_margin_all(4)
	b.add_theme_stylebox_override("normal", sb)
	var hover := sb.duplicate() as StyleBoxFlat
	hover.bg_color = Color(1, 1, 1, 0.85)
	b.add_theme_stylebox_override("hover", hover)
	var pressed := sb.duplicate() as StyleBoxFlat
	pressed.bg_color = Color(0.180, 0.769, 0.800, 0.6)
	b.add_theme_stylebox_override("pressed", pressed)
	return b


func _pill_button(text: String, w: float, h: float, font := 22, danger := false) -> Button:
	var b := _button(text, w, h, font)
	b.add_theme_stylebox_override("normal", _pill_box(danger, 1.0))
	b.add_theme_stylebox_override("hover", _pill_box(danger, 1.2))
	b.add_theme_stylebox_override("pressed", _pill_box(danger, 0.8))
	return b


func _pill_box(danger: bool, mul: float) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	if danger:
		sb.bg_color = Color(0.839, 0.271, 0.271, mul)
	else:
		sb.bg_color = Color(0.180, 0.769, 0.800, mul)
	sb.set_corner_radius_all(50)
	sb.set_content_margin_all(10)
	return sb


func _gradient_backdrop() -> Control:
	# a TextureRect, not a ColorRect: ColorRect has no texture property
	var bg := TextureRect.new()
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_SCALE
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var grad := Gradient.new()
	grad.set_color(0, COL_BG_TOP)
	grad.set_color(1, COL_BG_BOTTOM)
	var gt := GradientTexture2D.new()
	gt.gradient = grad
	gt.fill_from = Vector2(0, 0)
	gt.fill_to = Vector2(0, 1)
	gt.width = 8
	gt.height = 256
	bg.texture = gt
	return bg


func _build_hud() -> void:
	# #info-bar: level pill is centred during play, phase text is hidden then
	_level_pill = _label("Level 1", 26, COL_TEAL, false)
	_level_pill.add_theme_stylebox_override("normal", _pill_box(false, 0.0))
	_level_pill.add_theme_constant_override("outline_size", 2)
	_level_pill.add_theme_color_override("font_outline_color", COL_TEAL)
	_root.add_child(_level_pill)

	_phase_label = _label("", 19, COL_TEAL)
	_root.add_child(_phase_label)

	# #hearts is three <i class="fa-solid fa-heart"> at 20px, #ff5252, and a spent
	# heart goes to rgba(255,255,255,0.18) - not the red squares this used to draw
	_heart_box = HBoxContainer.new()
	_heart_box.add_theme_constant_override("separation", 6)
	_heart_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_heart_box)
	var fa := Art.fa_font()
	for _i in range(Cfg.MAX_HEARTS):
		var h := Label.new()
		h.text = Art.fa_text("heart")
		h.mouse_filter = Control.MOUSE_FILTER_IGNORE
		h.add_theme_font_size_override("font_size", 30)
		h.add_theme_color_override("font_color", HEART_COL)
		if fa != null:
			h.add_theme_font_override("font", fa)
		_heart_box.add_child(h)
		_hearts.append(h)


func _build_action_buttons() -> void:
	# JS: pause top-left 15px/40px; skip right 15px, hint right 65px,
	# rotate right 121px. 40px is a desktop hit target and far too small to tap
	# on a phone, so the top row is 48px and keeps the same 15/65/121 offsets.
	_pause_btn = _button("", ACTION_BTN, ACTION_BTN)
	_pause_btn.pressed.connect(func() -> void:
		Snd.play("ui-pause", "ui", 1.0)
		gm.toggle_pause())
	_dress_icon(_pause_btn, "pause")
	_root.add_child(_pause_btn)

	_hint_btn = _button("", ACTION_BTN, ACTION_BTN)
	_hint_btn.pressed.connect(func() -> void: gm.hint_move())
	_dress_icon(_hint_btn, "hint", Color(1.0, 0.78, 0.20))
	# free-hint counter: "3..1" while free hints last, then "AD" (rewarded)
	_hint_badge = Label.new()
	_hint_badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hint_badge.anchor_left = 1
	_hint_badge.anchor_right = 1
	_hint_badge.offset_left = -22
	_hint_badge.offset_right = 4
	_hint_badge.offset_top = -9
	_hint_badge.offset_bottom = 12
	_hint_badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hint_badge.add_theme_font_size_override("font_size", 15)
	_hint_badge.add_theme_color_override("font_outline_color", Color.BLACK)
	_hint_badge.add_theme_constant_override("outline_size", 5)
	_hint_btn.add_child(_hint_badge)
	refresh_hint_badge()
	_root.add_child(_hint_btn)

	_rotate_btn = _button("", ACTION_BTN, ACTION_BTN)
	_rotate_btn.pressed.connect(func() -> void: gm.rotate_view())
	_dress_icon(_rotate_btn, "camera")
	_root.add_child(_rotate_btn)

	_skip_btn = _button("", ACTION_BTN, ACTION_BTN)
	_skip_btn.pressed.connect(func() -> void: gm.skip_show())
	_dress_icon(_skip_btn, "skip")
	_root.add_child(_skip_btn)

	for dir in ["up", "down", "left", "right"]:
		var b := _button("", ACTION_BTN, ACTION_BTN)
		b.visible = false
		# JS marks the existing .ctrl-btn with a .tnt-back class rather than
		# spawning a second button, so this is only a red overlay drawn on the
		# D-pad: never a tap target of its own.
		b.mouse_filter = Control.MOUSE_FILTER_IGNORE
		b.add_theme_stylebox_override("normal", _tnt_box())
		_dress_icon(b, dir)
		_root.add_child(b)
		_tnt_btn[dir] = b


## Settings picks use FontAwesome glyphs, exactly like index.html
## <i class="fa-solid fa-arrow-up">, so they need the real face, not a drawn icon.
func _dress_fa(b: Button, glyph: String) -> void:
	var f := Art.fa_font()
	if f == null:
		return
	b.add_theme_font_override("font", f)
	b.text = glyph


## Buttons draw the same inline <svg> the JS build ships, rasterised at the
## button's pixel size so they stay crisp.
func _dress_icon(b: Button, name: String, col := COL_INK) -> void:
	var px := int(maxf(b.custom_minimum_size.x, 24.0))
	b.icon = Art.icon(name, px, col)
	b.expand_icon = true


func _tnt_box() -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.878, 0.322, 0.322, 0.4)
	sb.set_corner_radius_all(12)
	sb.set_border_width_all(2)
	sb.border_color = Color(0.878, 0.322, 0.322, 0.7)
	return sb




func _build_dpad() -> void:
	# JS: two clusters. Left is a column (up over down), right is a row
	# (left, right). Both bottom-aligned, 24px side padding, 14px inner gap.
	for dir in ["up", "down", "left", "right"]:
		var b := _button("", _ctrl_size(), _ctrl_size())
		b.button_down.connect(_on_dpad.bind(dir))
		_dress_icon(b, dir)
		_root.add_child(b)
		_dpad[dir] = b


func _build_fire_bar() -> void:
	# JS #fire-bar: 56x5, rounded, orange fill, centred on the player's head.
	_fire_bar = Control.new()
	_fire_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_fire_bar.custom_minimum_size = Vector2(56, 5)
	_root.add_child(_fire_bar)

	var bg := ColorRect.new()
	bg.color = Color(1, 1, 1, 0.5)
	bg.size = Vector2(56, 5)
	_fire_bar.add_child(bg)

	_fire_fill = ColorRect.new()
	_fire_fill.color = Color(1.0, 0.341, 0.133)
	_fire_fill.position = Vector2.ZERO
	_fire_fill.size = Vector2(56, 5)
	_fire_bar.add_child(_fire_fill)
	_fire_bar.visible = false


func _build_tap_overlay() -> void:
	# Built first so it sits under the HUD: it swallows swipes while the path is
	# shown, but SKIP/HINT/PAUSE must stay tappable.
	_tap_overlay = Control.new()
	_tap_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_tap_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	# no tint: the old 25% white wash read as a blur and washed the label out
	_tap_label = _label("TAP ANYWHERE TO START", 26, Color(0.02, 0.34, 0.40))
	_tap_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	_tap_label.add_theme_constant_override("outline_size", 3)
	_tap_label.add_theme_color_override("font_outline_color", Color(1, 1, 1, 0.85))
	_tap_label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_tap_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_tap_overlay.add_child(_tap_label)
	_tap_overlay.gui_input.connect(func(e: InputEvent) -> void:
		if (e is InputEventScreenTouch and e.pressed) or (e is InputEventMouseButton and e.pressed):
			gm.tap_to_start())
	add_child(_tap_overlay)
	_tap_overlay.visible = false


func _build_tutorial_banner() -> void:
	_tut_banner = PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.051, 0.078, 0.141, 0.88)
	sb.set_corner_radius_all(12)
	sb.set_border_width_all(1)
	sb.border_color = Color(1.0, 0.835, 0.31, 0.5)
	sb.set_content_margin_all(10)
	_tut_banner.add_theme_stylebox_override("panel", sb)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	_tut_label = _label("", 15, Color(1.0, 0.835, 0.31), false)
	row.add_child(_tut_label)
	var skip := _button("", 40, 40)
	skip.pressed.connect(func() -> void: gm.stop_tutorial(true))
	skip.tooltip_text = "Skip tutorial"
	_dress_icon(skip, "skip", Color(1.0, 0.835, 0.31))
	row.add_child(skip)
	_tut_banner.add_child(row)
	_tut_banner.visible = false
	_root.add_child(_tut_banner)


func _screen_root(tinted := false) -> Control:
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(_gradient_backdrop())
	if tinted:
		# style.css #level-select-screen, #settings-screen: a teal bloom top
		# right and an amber one bottom left over the same linear gradient
		root.add_child(_radial_tint(Vector2(0.85, -0.05), 0.70,
			Color(0.180, 0.769, 0.800, 0.3)))
		root.add_child(_radial_tint(Vector2(0.10, 1.05), 0.60,
			Color(1.0, 0.757, 0.027, 0.2)))
	return root


func _radial_tint(center: Vector2, radius: float, col: Color) -> TextureRect:
	var grad := Gradient.new()
	grad.offsets = PackedFloat32Array([0.0, 1.0])
	grad.colors = PackedColorArray([
		Color(col.r, col.g, col.b, col.a), Color(col.r, col.g, col.b, 0.0)])
	var gt := GradientTexture2D.new()
	gt.gradient = grad
	gt.fill = GradientTexture2D.FILL_RADIAL
	gt.fill_from = center
	gt.fill_to = center + Vector2(radius, 0)
	gt.width = 256
	gt.height = 256
	var tr := TextureRect.new()
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	tr.texture = gt
	return tr


func _header(back_call: Callable, title: String) -> Array:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	# 52px tap target (was 44): the corner tile sat where Android's status-bar /
	# edge-gesture zone swallows touches, so it has to be a bit bigger too
	var back := _button("", 52, 52)
	# .icon-btn on the light theme: white tile, navy rule, fully round
	var bsb := back.get_theme_stylebox("normal") as StyleBoxFlat
	bsb.set_border_width_all(2)
	bsb.border_color = Color(COL_INK_DEEP.r, COL_INK_DEEP.g, COL_INK_DEEP.b, 0.35)
	bsb.set_corner_radius_all(26)
	back.pressed.connect(func() -> void:
		# one sound for back and pause alike; ui-back is unmapped
		Snd.play("ui-pause", "ui", 1.0)
		back_call.call())
	_dress_icon(back, "back")
	row.add_child(back)
	var t := _label(title, 20, COL_INK_DEEP)
	# .ls-title is bold with 3px of tracking; a matching outline is the weight
	t.add_theme_constant_override("outline_size", 2)
	t.add_theme_color_override("font_outline_color", COL_INK_DEEP)
	t.add_theme_constant_override("letter_spacing", 3)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	t.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	row.add_child(t)
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(52, 0)
	row.add_child(spacer)
	return [row, t]


## .ls-header { border-bottom: 2px solid rgba(15,42,61,0.25) }
func _header_rule() -> ColorRect:
	var r := ColorRect.new()
	r.color = Color(COL_INK_DEEP.r, COL_INK_DEEP.g, COL_INK_DEEP.b, 0.25)
	r.custom_minimum_size = Vector2(0, 2)
	r.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return r


## The menu is one baked painting (home.png, 2048x1152): title, island, tagline,
## studio credit and the four pills are pixels, not controls. The art fills the
## screen edge to edge (COVER: uniform scale, never distorted, cropped equally
## on both sides when the aspect differs), and four invisible hitboxes are laid
## out with the exact same transform - scale + crop offset - so each tracks
## its painted pill on every screen.
const MENU_ART_W := 2048.0
const MENU_ART_H := 1152.0
## Painted-pill rects in art pixels: right = x + w, bottom = y + h.
const MENU_HITS := [
	["start_game", 1260, 677, 385, 63],
	["start_endless", 1260, 758, 385, 61],
	["start_daily", 1260, 831, 385, 62],
	["show_settings", 1260, 918, 385, 62],
]
var _menu_hits: Array[Button] = []
func _build_menu() -> void:
	_menu_screen = _screen_root()
	var art := TextureRect.new()
	art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	art.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	art.mouse_filter = Control.MOUSE_FILTER_IGNORE
	art.texture = Art.tex("res://assets/menu/home.png")
	_menu_screen.add_child(art)

	# invisible hitboxes: StyleBoxEmpty everywhere (no fill, no border, no
	# hover). Positioned by _layout_menu_hits, never by raw art pixels.
	var empty := StyleBoxEmpty.new()
	for spec in MENU_HITS:
		var b := Button.new()
		b.focus_mode = Control.FOCUS_NONE
		b.add_theme_stylebox_override("normal", empty)
		b.add_theme_stylebox_override("hover", empty)
		b.add_theme_stylebox_override("pressed", empty)
		b.add_theme_stylebox_override("focus", empty)
		b.add_theme_stylebox_override("disabled", empty)
		var fn := str(spec[0])
		b.pressed.connect(func() -> void:
			Snd.play("ui-click", "ui", 1.0)
			gm.call(fn))
		_menu_screen.add_child(b)
		_menu_hits.append(b)
	_menu_screen.resized.connect(_layout_menu_hits)
	_layout_menu_hits.call_deferred()

	add_child(_menu_screen)
	_menu_screen.visible = false


## Same transform as the COVER background: uniform scale to fill, then the
## centred crop offset. screen = image * scale + offset, so a hitbox at art
## rect (x, y, w, h) always sits on its painted pill - 16:9, wider or narrower.
func _layout_menu_hits() -> void:
	if _menu_screen == null or _menu_hits.is_empty():
		return
	var vs := _menu_screen.size
	if vs.x <= 0.0 or vs.y <= 0.0:
		return
	var s := maxf(vs.x / MENU_ART_W, vs.y / MENU_ART_H)
	var ox := (vs.x - MENU_ART_W * s) * 0.5
	var oy := (vs.y - MENU_ART_H * s) * 0.5
	for i in _menu_hits.size():
		var h: Array = MENU_HITS[i]
		var b := _menu_hits[i]
		b.position = Vector2(ox + float(h[1]) * s, oy + float(h[2]) * s)
		b.size = Vector2(float(h[3]) * s, float(h[4]) * s)


func _build_levels() -> void:
	_levels_screen = _screen_root(true)
	# painted sky sits over the gradient, under the content
	var bg := TextureRect.new()
	bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bg.texture = Art.tex("res://assets/levels/levels_bg.png")
	_levels_screen.add_child(bg)
	var col := VBoxContainer.new()
	col.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	col.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_levels_screen.add_child(col)

	var head: Array = _header(func() -> void: gm.hide_level_select(), "SELECT LEVEL")
	var row: HBoxContainer = head[0]
	# the wooden sign carries SELECT LEVEL + CAMPAIGN baked, so the text title
	# hides and the art centres between back and spacer
	(head[1] as Label).visible = false
	var center := CenterContainer.new()
	center.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(center)
	row.move_child(center, 1)
	var sign := TextureRect.new()
	sign.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	sign.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	sign.mouse_filter = Control.MOUSE_FILTER_IGNORE
	sign.texture = Art.tex("res://assets/levels/select_level_asset.png")
	var sign_h := 110.0
	sign.custom_minimum_size = Vector2(sign_h * 720.0 / 174.0, sign_h)
	center.add_child(sign)
	var vpad := MarginContainer.new()
	# left/top keep the back button clear of the edge/gesture zone + status bar
	vpad.add_theme_constant_override("margin_left", 40)
	vpad.add_theme_constant_override("margin_right", 16)
	vpad.add_theme_constant_override("margin_top", 32)
	vpad.add_theme_constant_override("margin_bottom", 8)
	vpad.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	vpad.add_child(row)
	col.add_child(vpad)
	col.add_child(_header_rule())

	# The grid scrolls down: five cards per row, one row after another. The
	# scroll must fill the leftover height, and so must every wrapper between it
	# and the VBox, otherwise it collapses and reads blank.
	var scroll_pad := MarginContainer.new()
	scroll_pad.add_theme_constant_override("margin_bottom", 10)
	scroll_pad.size_flags_vertical = Control.SIZE_EXPAND_FILL
	col.add_child(scroll_pad)
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_SHOW_NEVER
	scroll.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_AUTO
	scroll_pad.add_child(scroll)
	_level_scroll = scroll
	_level_strip = VBoxContainer.new()
	_level_strip.add_theme_constant_override("separation", int(_grid_gap()))
	_level_strip.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	# wrappers take no clicks: every drag goes straight to the scroller,
	# which is what makes flings start instantly instead of sticking
	_level_strip.mouse_filter = Control.MOUSE_FILTER_IGNORE
	scroll.add_child(_level_strip)

	add_child(_levels_screen)
	_levels_screen.visible = false


func _grid_min() -> float:
	var want: float
	match _tier():
		0: want = GRID_MIN_A
		1: want = GRID_MIN_B
		_: want = GRID_MIN_C
	# five cards share a row, so a narrow viewport shrinks them instead of
	# pushing the fifth one past the edge
	var avail := _vp().x - 32.0 - float(LEVELS_PER_LINE - 1) * _grid_gap()
	return minf(want, avail / float(LEVELS_PER_LINE))


func _grid_gap() -> float:
	match _tier():
		0: return GRID_GAP_A
		1: return GRID_GAP_B
	return GRID_GAP_C


func _build_settings() -> void:
	_settings_pop = _card_popup("SETTINGS", SETTINGS_W, SETTINGS_H, false)
	var col: VBoxContainer = _settings_pop["card"]
	# a card has to fit a 720-tall landscape viewport with room to spare, so the
	# rows pack tighter than a full screen would (and the INPUT caption is one
	# row the KEYS/SWIPE buttons do not need - they say what they are)
	col.add_theme_constant_override("separation", 10)

	var opts := HBoxContainer.new()
	opts.add_theme_constant_override("separation", 16)
	col.add_child(opts)
	_dpad_option = _button("KEYS", 152, 74, 18)
	_dpad_option.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		gm.set_input_mode("dpad"))
	_dress_fa(_dpad_option, Art.fa_text("fa-arrow-up") + "\n" + Art.fa_text("fa-arrow-down"))
	_dpad_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	opts.add_child(_dpad_option)
	_swipe_option = _button("SWIPE", 152, 74, 18)
	_swipe_option.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		gm.set_input_mode("swipe"))
	_dress_fa(_swipe_option, Art.fa_text("fa-hand-pointer"))
	_swipe_option.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	opts.add_child(_swipe_option)

	_sound_btn = _pill_button("SOUND: ON", 320, 56, 22)
	_sound_btn.pressed.connect(func() -> void:
		# the click has to sit on the unmuted side of the flip, or one half of
		# the toggle gives no feedback at all
		if _sound_on:
			Snd.play("ui-click", "ui", 1.0)
		_sound_on = not _sound_on
		Snd.set_muted(not _sound_on)
		if _sound_on:
			Snd.play("ui-click", "ui", 1.0)
		_sound_btn.text = "SOUND: ON" if _sound_on else "SOUND: OFF")
	_sound_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_child(_sound_btn)

	for spec in [["MUSIC VOLUME", "music"], ["EFFECTS VOLUME", "sfx"]]:
		var cap := _label(str(spec[0]), 14, COL_MUTED)
		cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
		cap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.add_child(cap)
		var sl := HSlider.new()
		sl.min_value = 0.0
		sl.max_value = 100.0
		sl.step = 1.0
		sl.custom_minimum_size = Vector2(0, 28)
		sl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		sl.value = 100.0
		if str(spec[1]) == "music":
			sl.value_changed.connect(func(v: float) -> void: Snd.set_music_volume(v / 100.0))
		else:
			sl.value_changed.connect(func(v: float) -> void: Snd.set_sfx_volume(v / 100.0))
		col.add_child(sl)

	var tut := _pill_button("TUTORIAL", 320, 56, 22)
	tut.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		gm.launch_tutorial())
	tut.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_child(tut)

	var reset := _pill_button("RESET PROGRESS", 320, 56, 22, true)
	reset.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		gm.reset_progress())
	reset.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_child(reset)

	# the card has no header back button: DONE is the tap path, Android back
	# still routes through _handle_back()
	var done := _pill_button("DONE", 320, 56, 22)
	done.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		gm.hide_settings())
	done.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_child(done)

	add_child(_settings_pop["root"])
	_settings_pop["root"].visible = false


func _build_popups() -> void:
	# every card button clicks: the HUD's own controls (pause/back/camera/hint)
	# keep their sounds, the cards are plain choices
	_pause_popup = _card_popup("GAME PAUSED")
	var pause_home: Button = _pause_popup["home"]
	var pause_stay: Button = _pause_popup["stay"]
	pause_stay.text = "RESUME"
	pause_stay.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		gm.resume_from_pause())
	pause_home.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		gm.back_to_menu())
	_pause_popup["root"].visible = false
	add_child(_pause_popup["root"])

	_win_popup = _card_popup("LEVEL COMPLETE!")
	var win_stay: Button = _win_popup["stay"]
	var win_home: Button = _win_popup["home"]
	win_stay.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		gm.win_choice(gm.win_action))
	win_home.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		gm.win_choice(gm.back_to_menu))
	_win_popup["root"].visible = false
	add_child(_win_popup["root"])

	_over_popup = _card_popup("GAME OVER")
	var over_stay: Button = _over_popup["stay"]
	var over_home: Button = _over_popup["home"]
	over_stay.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		gm.restart())
	over_home.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		gm.back_to_menu())
	# CONTINUE (AD) above TRY AGAIN: buy the spot you died on back with a
	# rewarded ad, every mode. The AD chip keeps it reading as an ad.
	var top := HBoxContainer.new()
	top.alignment = BoxContainer.ALIGNMENT_CENTER
	top.add_theme_constant_override("separation", 10)
	var cont := _pill_button("CONTINUE", 300, 64, 20)
	cont.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		gm.continue_from_game_over())
	top.add_child(cont)
	var chip := _label("AD", 12, Color.WHITE)
	chip.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	var chipbox := StyleBoxFlat.new()
	chipbox.bg_color = Color(0.98, 0.58, 0.10)
	chipbox.set_corner_radius_all(7)
	chipbox.set_content_margin_all(4)
	chip.add_theme_stylebox_override("normal", chipbox)
	top.add_child(chip)
	(_over_popup["card"] as VBoxContainer).add_child(top)
	(_over_popup["card"] as VBoxContainer).move_child(top, 3)
	_over_popup["top"] = top
	_over_popup["root"].visible = false
	add_child(_over_popup["root"])

	# shared confirm for hint/skip ads: a single click never launches an ad, the
	# player confirms with WATCH AD first (game-over has its own CONTINUE above)
	_ad_popup = _card_popup("WATCH AN AD?")
	_ad_popup["title"].add_theme_color_override("font_color", COL_TEAL)
	_ad_popup["title"].add_theme_color_override("font_outline_color", COL_TEAL)
	var ad_stay: Button = _ad_popup["stay"]
	ad_stay.text = "WATCH AD"
	var ad_home: Button = _ad_popup["home"]
	ad_home.text = "NO"
	ad_stay.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		_ad_popup["root"].visible = false
		var yes := _ad_yes
		_ad_yes = Callable()
		if yes.is_valid():
			yes.call())
	ad_home.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		_ad_popup["root"].visible = false
		var no := _ad_no
		_ad_no = Callable()
		if no.is_valid():
			no.call())
	_ad_popup["root"].visible = false
	add_child(_ad_popup["root"])

	# home-screen back button: confirm before leaving the app (JS has no such
	# popup, Android back would otherwise quit silently)
	_exit_popup = _card_popup("EXIT GAME?")
	var exit_go: Button = _exit_popup["stay"]
	exit_go.text = "EXIT"
	exit_go.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		get_tree().quit())
	var exit_stay: Button = _exit_popup["home"]
	exit_stay.text = "STAY"
	exit_stay.pressed.connect(func() -> void:
		Snd.play("ui-click", "ui", 1.0)
		hide_exit())
	_exit_popup["root"].visible = false
	add_child(_exit_popup["root"])


## The card shares the pale background's temperature so it belongs to the screen,
## but a teal rule and a drop shadow keep it from dissolving into the gradient.
func _card_box() -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	# frosted card, shared by every popup so they read as one family: the dim
	# behind does the diffusing, the card only has to be see-through, catch the
	# light on its edge and sit off the page. ponytail: real backdrop blur /
	# sheen would need a screen-texture shader and a backbuffer copy per card -
	# skip it until the flat glass reads as plastic on device.
	sb.bg_color = Color(1, 1, 1, 0.62)
	sb.set_corner_radius_all(26)
	sb.set_border_width_all(1)
	sb.border_color = Color(1, 1, 1, 0.85)
	sb.shadow_color = Color(0.07, 0.16, 0.30, 0.45)
	sb.shadow_size = 34
	sb.shadow_offset = Vector2(0, 16)
	sb.set_content_margin_all(36)
	sb.content_margin_left = 40
	sb.content_margin_right = 40
	return sb


## Popup shell shared by every card: title, optional subtitle/detail, a pill
## action and a ghost pill. Pass `actions := false` for a card that carries its
## own body instead (settings). Returns {"root", "panel", "size", "title",
## "sub", "detail", "card", "stay", "home"}.
func _card_popup(title: String, w := CARD_W, h := CARD_H, actions := true) -> Dictionary:
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_STOP
	var dim := ColorRect.new()
	dim.color = Color(0.745, 0.882, 0.953, 0.5)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(dim)

	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", _card_box())
	_center(panel, w, h)
	root.add_child(panel)

	var card := VBoxContainer.new()
	card.add_theme_constant_override("separation", 14)
	panel.add_child(card)

	var t := _label(title, 34, COL_DANGER)
	t.add_theme_constant_override("outline_size", 5)
	t.add_theme_color_override("font_outline_color", COL_DANGER)
	card.add_child(t)
	# hidden until a caller fills them in - an empty label still eats a row
	var sub := _label("", 20, COL_MUTED)
	sub.visible = false
	card.add_child(sub)
	# #final-level: the score line under the subtitle
	var detail := _label("", 26, COL_TEAL)
	detail.visible = false
	card.add_child(detail)

	var stay: Button = null
	var home: Button = null
	if actions:
		stay = _pill_button("TRY AGAIN", 300, 64, 20)
		card.add_child(stay)
		home = _button("HOME", 300, 56, 18)
		_make_ghost_pill(home)
		card.add_child(home)
	return {"root": root, "panel": panel, "size": Vector2(w, h), "title": t,
		"sub": sub, "detail": detail, "card": card, "stay": stay, "home": home}


## The ghost action wears the same pill shape as the filled one, so a card never
## shows a fat teal capsule next to a nearly-square outline button.
func _make_ghost_pill(b: Button) -> void:
	var h := b.custom_minimum_size.y
	var make := func(mul: float) -> StyleBoxFlat:
		var sb := StyleBoxFlat.new()
		sb.bg_color = Color(1, 1, 1, 0.42 * mul)
		sb.set_corner_radius_all(int(h * 0.5))
		sb.set_border_width_all(2)
		sb.border_color = Color(0.353, 0.549, 0.647, 0.55)
		sb.set_content_margin_all(10)
		return sb
	b.add_theme_stylebox_override("normal", make.call(1.0) as StyleBoxFlat)
	b.add_theme_stylebox_override("hover", make.call(1.25) as StyleBoxFlat)
	var pressed := make.call(0.8) as StyleBoxFlat
	pressed.bg_color = Color(0.180, 0.769, 0.800, 0.55)
	b.add_theme_stylebox_override("pressed", pressed)


## Every card arrives the same way: back off to 70%, snap in over 0.24s.
func _pop_in(pop: Dictionary) -> void:
	var panel: Control = pop["panel"]
	panel.pivot_offset = (pop["size"] as Vector2) * 0.5
	panel.scale = Vector2(0.7, 0.7)
	panel.modulate = Color(1, 1, 1, 0)
	var t := panel.create_tween()
	t.set_parallel(true)
	t.tween_property(panel, "scale", Vector2.ONE, 0.24) \
		.set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	t.tween_property(panel, "modulate", Color.WHITE, 0.16)


# --- layout ------------------------------------------------------------------

func _layout_hud() -> void:
	var top := _info_top()
	var w := _vp().x
	var bs := ACTION_BTN
	var off := EDGE_PAD
	var step := bs + 10.0

	# Phase text sits on the right of the info bar when a level is not active.
	_phase_label.offset_left = w - 240
	_phase_label.offset_right = w - 20
	_phase_label.offset_top = top + 2
	_phase_label.offset_bottom = top + 30
	_phase_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT

	# Level number sits directly above the hearts, and both clear the pause
	# button on the left (JS .game-active #hearts { left: 64px } for a 40px
	# pause; this pause is wider, so the stack starts past its right edge).
	var hsize := 30.0 if _tier() == 0 else 24.0
	var gap := 8.0 if _tier() == 0 else 6.0
	var lvl_h := 34.0 if _tier() == 0 else 28.0
	var hud_left := off + bs + 12.0

	_level_pill.anchor_left = 0
	_level_pill.anchor_right = 0
	_level_pill.anchor_top = 0
	_level_pill.anchor_bottom = 0
	_level_pill.offset_left = hud_left
	_level_pill.offset_right = hud_left + 240
	_level_pill.offset_top = top
	_level_pill.offset_bottom = top + lvl_h
	_level_pill.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT

	_heart_box.add_theme_constant_override("separation", int(gap))
	_heart_box.offset_left = hud_left
	_heart_box.offset_right = hud_left + Cfg.MAX_HEARTS * (hsize + gap)
	_heart_box.offset_top = top + lvl_h + 14
	_heart_box.offset_bottom = _heart_box.offset_top + hsize
	for p in _hearts:
		p.add_theme_font_size_override("font_size", int(hsize))
		p.custom_minimum_size = Vector2(hsize, hsize)
		var sb: StyleBoxFlat = p.get_theme_stylebox("panel")
		sb.set_corner_radius_all(int(hsize * 0.5))

	# JS top bar: pause left 15px; skip right 15, hint right 65, rotate right
	# 121. Those offsets are sized for a 40px button, so they are stepped off
	# this build's own ACTION_BTN to keep a gap instead of overlapping.
	for b in [_pause_btn, _skip_btn, _hint_btn, _rotate_btn]:
		b.custom_minimum_size = Vector2(bs, bs)
	_pause_btn.offset_left = off
	_pause_btn.offset_top = top
	_pause_btn.offset_right = off + bs
	_pause_btn.offset_bottom = top + bs
	# JS gives .top-btn and .skip-btn the same `top: 15px` the pause button has;
	# only the horizontal insets were ever carried over, which pinned these
	# three flush against y=0 instead of up here with the pause button
	for b in [_skip_btn, _hint_btn, _rotate_btn]:
		b.anchor_top = 0
		b.anchor_bottom = 0
		b.offset_top = top
		b.offset_bottom = top + bs
	_skip_btn.anchor_left = 1
	_skip_btn.anchor_right = 1
	_skip_btn.offset_left = -off - bs
	_skip_btn.offset_right = -off
	_hint_btn.anchor_left = 1
	_hint_btn.anchor_right = 1
	_hint_btn.offset_left = -(off + step) - bs
	_hint_btn.offset_right = -(off + step)
	_rotate_btn.anchor_left = 1
	_rotate_btn.anchor_right = 1
	_rotate_btn.offset_left = -(off + step * 2.0) - bs
	_rotate_btn.offset_right = -(off + step * 2.0)
	for dir in _tnt_btn.values():
		var b: Button = dir
		b.custom_minimum_size = Vector2(bs, bs)

	_tap_label.offset_top = _vp().y - _tap_pad() - 30
	_tap_label.offset_bottom = _vp().y - _tap_pad()


func _layout_controls() -> void:
	var s := _ctrl_size()
	var pad := EDGE_PAD
	var gap := 14.0 if _tier() == 0 else 8.0
	var w := _vp().x

	# JS #controls sits `bottom: 80px` off the floor of the screen, so that
	# number has to be measured down from the viewport, not used as a top
	# offset - reading it as one parked the whole pad at the top of the window
	# with the down arrow above the up arrow.
	var bottom := _vp().y - _controls_bottom() - s

	# left cluster: a column, up over down, 24px from the left
	var up: Button = _dpad["up"]
	var down: Button = _dpad["down"]
	up.anchor_left = 0
	up.anchor_right = 0
	up.offset_left = pad
	up.offset_right = pad + s
	up.offset_top = bottom - s - gap
	up.offset_bottom = bottom - gap
	down.anchor_left = 0
	down.anchor_right = 0
	down.offset_left = pad
	down.offset_right = pad + s
	down.offset_top = bottom
	down.offset_bottom = bottom + s

	# right cluster: a row, left then right, 24px from the right
	var left: Button = _dpad["left"]
	var right: Button = _dpad["right"]
	left.anchor_left = 1
	left.anchor_right = 1
	left.offset_left = -(pad + s * 2 + gap)
	left.offset_right = -(pad + s + gap)
	left.offset_top = bottom
	left.offset_bottom = bottom + s
	right.anchor_left = 1
	right.anchor_right = 1
	right.offset_left = -pad - s
	right.offset_right = -pad
	right.offset_top = bottom
	right.offset_bottom = bottom + s

	for b in _dpad.values():
		(b as Button).custom_minimum_size = Vector2(s, s)
	# the TNT "go back" overlay is the D-pad button restyled, so it sits exactly
	# on top of the matching pad key instead of being parked at the origin
	for dir in _tnt_btn:
		var over := _tnt_btn[dir] as Button
		var key := _dpad[dir] as Button
		over.anchor_left = key.anchor_left
		over.anchor_right = key.anchor_right
		over.anchor_top = key.anchor_top
		over.anchor_bottom = key.anchor_bottom
		over.offset_left = key.offset_left
		over.offset_right = key.offset_right
		over.offset_top = key.offset_top
		over.offset_bottom = key.offset_bottom
		over.custom_minimum_size = Vector2(s, s)
	_tut_banner.anchor_left = 0.5
	_tut_banner.anchor_right = 0.5
	_tut_banner.offset_left = -minf(w * 0.46, 460)
	_tut_banner.offset_right = minf(w * 0.46, 460)
	# the top bar moved down by EDGE_PAD - INFO_TOP_A, so the banner follows it
	# to keep the same gap it had over the hearts
	_tut_banner.offset_top = 105.0
	_tut_banner.offset_bottom = 105.0 + 58


func _layout_popups() -> void:
	for pop: Dictionary in [_pause_popup, _win_popup, _over_popup, _exit_popup]:
		_center(pop["panel"], CARD_W, CARD_H)


func _layout_screens() -> void:
	if _level_strip == null:
		return
	_level_strip.add_theme_constant_override("separation", int(_grid_gap()))


# --- public api --------------------------------------------------------------

func set_level(text: String) -> void:
	_level_pill.text = text


func set_phase(text: String) -> void:
	_phase_label.text = text


func set_hearts(h: int) -> void:
	for i in _hearts.size():
		_hearts[i].add_theme_color_override("font_color", HEART_COL if i < h else HEART_EMPTY)


func show_info(v: bool) -> void:
	_level_pill.visible = v
	_heart_box.visible = v
	_pause_btn.visible = v
	# JS .game-active #phase-text { display: none } - the pill replaces it
	_phase_label.visible = not v


func show_hearts(v: bool) -> void:
	_heart_box.visible = v


func show_action_buttons(v: bool) -> void:
	if v:
		refresh_hint_badge()
	_hint_btn.visible = v
	_rotate_btn.visible = v


func refresh_hint_badge() -> void:
	var n := Save.free_hints()
	_hint_badge.text = str(n) if n > 0 else "AD"
	_hint_badge.add_theme_color_override(
		"font_color", Color.WHITE if n > 0 else Color(1.0, 0.45, 0.45)
	)


func show_dpad(v: bool) -> void:
	for b in _dpad.values():
		(b as Button).visible = v


func set_skip_visible(v: bool) -> void:
	_skip_btn.visible = v


func set_hint_glow(on: bool) -> void:
	_hint_btn.modulate = Color(1.0, 0.835, 0.31) if on else Color(1, 1, 1)


func highlight_tnt_back(dir: String) -> void:
	clear_tnt_back()
	if _tnt_btn.has(dir):
		_tnt_btn[dir].visible = true


func clear_tnt_back() -> void:
	for b in _tnt_btn.values():
		(b as Button).visible = false


func show_tap_overlay(v: bool) -> void:
	_tap_overlay.visible = v


func hide_tap_overlay() -> void:
	_tap_overlay.visible = false


func show_pause() -> void:
	_pause_popup["root"].move_to_front()
	_pause_popup["root"].visible = true
	_pop_in(_pause_popup)


func hide_pause() -> void:
	_pause_popup["root"].visible = false


## Home-screen exit confirmation (Android hardware back)
func show_exit() -> void:
	# the menu/level/settings screens are added after the popups, so without
	# this the exit card would sit behind the opaque menu and never be seen
	_exit_popup["root"].move_to_front()
	_exit_popup["root"].visible = true
	_pop_in(_exit_popup)


func hide_exit() -> void:
	if not _exit_popup.is_empty():
		_exit_popup["root"].visible = false


func exit_visible() -> bool:
	return not _exit_popup.is_empty() and _exit_popup["root"].visible


func show_win(title: String, sub: String, action: String) -> void:
	var t: Label = _win_popup["title"]
	var s: Label = _win_popup["sub"]
	var b: Button = _win_popup["stay"]
	t.text = title
	t.add_theme_color_override("font_color", COL_SUCCESS)
	s.text = sub
	s.visible = sub != ""
	b.text = action
	# a second HOME next to a MENU action would be the same tap twice
	_win_popup["home"].visible = action != "MENU"
	_win_popup["root"].move_to_front()
	_win_popup["root"].visible = true
	_pop_in(_win_popup)


func show_game_over(title: String, sub: String, detail: String, action: String) -> void:
	var t: Label = _over_popup["title"]
	var s: Label = _over_popup["sub"]
	var d: Label = _over_popup["detail"]
	var b: Button = _over_popup["stay"]
	t.text = title
	t.add_theme_color_override("font_color", COL_DANGER)
	s.text = sub
	s.visible = sub != ""
	d.text = detail
	d.visible = detail != ""
	b.text = action
	_over_popup["home"].visible = action != "MENU"
	# the daily-done card has no level to buy back, so no CONTINUE there
	_over_popup["top"].visible = action != "MENU"
	_over_popup["root"].move_to_front()
	_over_popup["root"].visible = true
	_pop_in(_over_popup)


## Confirm-before-ad for hint and skip: single tap on the hint/skip button must
## never launch an ad, the player opts in here. on_no fires on CANCEL so callers
## can unpause what they paused for the question.
func ask_ad(sub: String, on_yes: Callable, on_no: Callable = Callable()) -> void:
	_ad_yes = on_yes
	_ad_no = on_no
	_ad_popup["sub"].text = sub
	_ad_popup["sub"].visible = sub != ""
	_ad_popup["root"].move_to_front()
	_ad_popup["root"].visible = true
	_pop_in(_ad_popup)


## Screen swaps used to hard-cut: one frame of the old screen, a flash of the
## background, then the new one. hide_all() is the one choke point every swap
## runs through (menu, level select, settings, level entry, back to menu), so it
## drops an opaque cover on the frame the swap happens and fades it back out
## over the new screen - the raw cut never reaches the player's eyes.
const TRANSITION_OUT := 0.30
const TRANSITION_COL := Color(0.678, 0.808, 0.902)

var _fade: ColorRect
var _tw: Tween


func _build_transition() -> void:
	var layer := CanvasLayer.new()
	# above our own layer (10), so a popup's move_to_front() cannot outrank it
	layer.layer = 100
	add_child(layer)
	_fade = ColorRect.new()
	_fade.color = TRANSITION_COL
	_fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(_fade)


## Cover up this frame, clear over TRANSITION_OUT. A second hide_all() in the
## same frame (start_endless -> cleanup) just re-raises the cover and restarts
## the fade - stacked hides are the normal path, not a race.
func _cover() -> void:
	if _fade == null:
		return
	_fade.mouse_filter = Control.MOUSE_FILTER_STOP
	_fade.modulate.a = 1.0
	if _tw != null and _tw.is_running():
		_tw.kill()
	_tw = create_tween()
	_tw.tween_property(_fade, "modulate:a", 0.0, TRANSITION_OUT) \
		.set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_CUBIC)
	_tw.tween_callback(_end_cover)


func _end_cover() -> void:
	_fade.modulate.a = 0.0
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE


func hide_all() -> void:
	show_info(false)
	show_action_buttons(false)
	show_dpad(false)
	set_skip_visible(false)
	hide_tap_overlay()
	hide_pause()
	hide_exit()
	_win_popup["root"].visible = false
	_over_popup["root"].visible = false
	if not _ad_popup.is_empty():
		_ad_popup["root"].visible = false
	_fire_bar.visible = false
	clear_tnt_back()
	_tut_banner.visible = false
	_menu_screen.visible = false
	_levels_screen.visible = false
	if not _settings_pop.is_empty():
		_settings_pop["root"].visible = false
	screen = Screen.NONE
	Ads.set_banner_visible(false)
	_cover()


func show_menu() -> void:
	Snd.start_loop("ambience", 1.0)
	Snd.start_loop("ambience-island", 0.45)
	hide_all()
	screen = Screen.MENU
	_menu_screen.visible = true
	_layout_menu_hits()
	_warmup_level_art()
	# no banner on the home screen: the baked painting stays whole
	Ads.set_banner_visible(false)


## First level entry uploads a dozen block textures + builds the unit mesh on
## the spot, which is the hitch behind "UI takes time to appear" on game start.
## Do it here while the player reads the menu; afterwards it is all cached.
func _warmup_level_art() -> void:
	for files in Art.BLOCK_TEXTURES.values():
		for face in ["top", "side"]:
			var src: String = files.get(face, files.get("all", ""))
			if src != "":
				Art.tex(src)
	Art.unit_cube()


func show_levels(current_level: int) -> void:
	hide_all()
	screen = Screen.LEVELS
	_levels_screen.visible = true
	_build_grid(current_level)


## One row of eight cards, top to bottom, so the list scrolls down instead of
## dragging sideways.
func _build_grid(current_level: int) -> void:
	for c in _level_strip.get_children():
		c.queue_free()
	var completed := Save.completed()
	var skipped := Save.skipped()
	var gap := int(_grid_gap())
	var row_count := int(ceil(float(TOTAL_LEVELS) / float(LEVELS_PER_LINE)))
	for r in range(row_count):
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", gap)
		row.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		row.mouse_filter = Control.MOUSE_FILTER_IGNORE
		for k in range(LEVELS_PER_LINE):
			var n := r * LEVELS_PER_LINE + k + 1
			if n > TOTAL_LEVELS:
				break
			row.add_child(_level_cell(n, current_level, completed, skipped))
		_level_strip.add_child(row)


## Level tiles are baked art, not styleboxes: 200 shadowed StyleBoxFlat tiles
## redrew their drop shadows every scroll frame, which is what made the list
## crawl on phones. One shared texture per state costs nothing while scrolling.
## "available" is the unreachable fallback (every level below the frontier is
## completed or skipped) and wears gold like current: tappable, never grey.
const LEVEL_ART := {
	"complete": "res://assets/levels/completed_asset.png",
	"skipped": "res://assets/levels/skipped_asset.png",
	"current": "res://assets/levels/current_asset.png",
	"available": "res://assets/levels/current_asset.png",
	"locked": "res://assets/levels/locked_asset.png",
}
func _level_cell(n: int, current_level: int, completed: Array[int], skipped: Array[int]) -> Control:
	var state := "locked"
	if completed.has(n):
		state = "complete"
	elif skipped.has(n):
		state = "skipped"
	elif n == current_level:
		state = "current"
	elif n < current_level:
		state = "available"

	var tex := Art.tex(str(LEVEL_ART[state]))
	var w := _grid_min()
	var h := w * tex.get_size().y / tex.get_size().x
	var btn := Button.new()
	btn.custom_minimum_size = Vector2(w, h)
	btn.focus_mode = Control.FOCUS_NONE
	# PASS, not STOP: taps still land on the tile, but a drag starting on a
	# card propagates to the scroller instead of dying on the button
	btn.mouse_filter = Control.MOUSE_FILTER_PASS
	btn.icon = tex
	btn.expand_icon = true
	# the art IS the tile face: empty styles, no per-frame shadow to repaint
	var empty := StyleBoxEmpty.new()
	btn.add_theme_stylebox_override("normal", empty)
	btn.add_theme_stylebox_override("hover", empty)
	btn.add_theme_stylebox_override("pressed", empty)
	btn.add_theme_stylebox_override("focus", empty)
	if state == "locked":
		# JS keeps locked cells at opacity 0.5 with no click handler
		btn.modulate = Color(1, 1, 1, 0.5)
	else:
		btn.pressed.connect(func() -> void:
			Snd.play("ui-click", "ui", 1.0)
			gm.start_level(n))

	# the number rides the stone centre, above the baked status strip
	var num := _label(str(n), int(clampf(w * 0.22, 18.0, 34.0)), COL_INK)
	num.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	num.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	num.offset_top = -h * 0.12
	num.offset_bottom = -h * 0.12
	num.mouse_filter = Control.MOUSE_FILTER_IGNORE
	num.add_theme_constant_override("outline_size", 2)
	num.add_theme_color_override("font_outline_color", COL_INK)
	btn.add_child(num)
	return btn


func show_settings() -> void:
	# a KEYS/SWIPE tap re-shows the same card: re-highlight only
	if screen == Screen.SETTINGS:
		_highlight_settings()
		return
	# the menu stays up behind the card - this is an overlay, not a screen
	# change, so no hide_all()/cover. `screen` still flips so Android back
	# routes to closing the card.
	_settings_from = screen
	screen = Screen.SETTINGS
	_settings_pop["root"].move_to_front()
	_settings_pop["root"].visible = true
	_pop_in(_settings_pop)
	_highlight_settings()


func _highlight_settings() -> void:
	var mode := Save.input_mode()
	_dpad_option.modulate = Color(1.0, 0.835, 0.31) if mode == "dpad" else Color(1, 1, 1)
	_swipe_option.modulate = Color(1.0, 0.835, 0.31) if mode == "swipe" else Color(1, 1, 1)


func hide_settings() -> void:
	if screen != Screen.SETTINGS or _settings_pop.is_empty():
		return
	_settings_pop["root"].visible = false
	# the screen the card was raised over is still up behind it
	screen = _settings_from


func show_tutorial(text: String, keys: Array) -> void:
	_tut_label.text = text
	_tut_banner.visible = true
	for b in _dpad.values():
		(b as Button).modulate = Color(1, 1, 1)
	for key in keys:
		if _dpad.has(key):
			(_dpad[key] as Button).modulate = Color(1.0, 0.835, 0.31)
		elif key == "hint-btn":
			_hint_btn.modulate = Color(1.0, 0.835, 0.31)
		elif key == "rotate-right-btn":
			_rotate_btn.modulate = Color(1.0, 0.835, 0.31)


func hide_tutorial() -> void:
	_tut_banner.visible = false
	for b in _dpad.values():
		(b as Button).modulate = Color(1, 1, 1)


func set_fire_bar(v: bool, percent: float) -> void:
	if not v or gm == null or gm.camera_rig == null or gm.camera_rig.camera == null:
		_fire_bar.visible = false
		return
	var cam: Camera3D = gm.camera_rig.camera
	var world: Vector3 = gm.player.global_position + Vector3(0.0, 1.6, 0.0)
	if cam.is_position_behind(world):
		_fire_bar.visible = false
		return
	_fire_bar.visible = true
	_fire_bar.position = cam.unproject_position(world) - _fire_bar.size * 0.5
	_fire_fill.size.x = 56.0 * clampf(percent, 0.0, 1.0)


# --- input -------------------------------------------------------------------

func _on_dpad(dir: String) -> void:
	if gm == null:
		return
	var now := Time.get_ticks_msec()
	if now < _move_lock_until:
		return
	_move_lock_until = now + int(Cfg.MOVE_LOCK_S * 1000.0)
	gm.handle_move(dir)


func _unhandled_input(event: InputEvent) -> void:
	var is_press: bool = (event is InputEventScreenTouch) \
		or (event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT)
	if is_press:
		if event.is_pressed():
			_swipe_start = event.position
		elif _swipe_start != null:
			var from: Vector2 = _swipe_start
			_swipe_start = null
			_swipe(_end_position(event) - from)
		return

	if event is InputEventKey and event.pressed and not event.echo and gm != null:
		match event.keycode:
			KEY_UP:
				gm.handle_move("up")
			KEY_DOWN:
				gm.handle_move("down")
			KEY_LEFT:
				gm.handle_move("left")
			KEY_RIGHT:
				gm.handle_move("right")
			KEY_S:
				gm.skip_show()
			KEY_SPACE, KEY_ENTER:
				gm.confirm()
			KEY_H:
				gm.hint_move()
			KEY_R:
				gm.rotate_view()
			KEY_P, KEY_ESCAPE:
				gm.toggle_pause()


func _end_position(event: InputEvent) -> Vector2:
	if event is InputEventScreenTouch:
		return event.position
	if event is InputEventMouseButton:
		return event.position
	return Vector2.ZERO


func _swipe(d: Vector2) -> void:
	if gm == null or not gm.is_playing() or gm.paused or gm.player.is_moving:
		return
	if Save.input_mode() == "dpad":
		return
	if maxf(absf(d.x), absf(d.y)) < Cfg.SWIPE_MIN_PX:
		return
	if absf(d.x) > absf(d.y):
		gm.handle_move("right" if d.x > 0.0 else "left")
	else:
		gm.handle_move("down" if d.y > 0.0 else "up")