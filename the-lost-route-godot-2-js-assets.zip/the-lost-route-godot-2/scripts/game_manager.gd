class_name GameManager
extends Node3D

## Port of GameManager.js. Owns the state machine, the per-level setup/teardown
## and every rule that reacts to a move. Campaign, endless and daily share the
## same move/win/lose code and differ only in setup_level() and win routing.

enum State { SHOWING, PLAYING, WON, GAMEOVER, MENU }
enum Mode { CAMPAIGN, ENDLESS, DAILY }

var path: Array[Vector2i] = []
var current_path_index := 0
var level := 1
var health := Cfg.MAX_HEARTS
var state: State = State.SHOWING
var paused := false
var mode: Mode = Mode.CAMPAIGN
var is_tutorial := false

# endless
var run_streak := 0
var run_seed := 1
var segment_start_index := 0
var show_start_index := 0
# held back until the path has been shown and hidden again
var _can_skip := false

var path_gen := PathGenerator.new()
var blocks := BlockManager.new()
var cube_grid: CubeGrid
var island_builder: IslandBuilder
var environment: EnvironmentBuilder
var player: Player
var camera_rig: CameraRig
var ui

var _midpoint_rewarded := false
var _sequence_id := 0
var _tnt_back_direction := ""
var _active_tnt := Vector2i.ZERO
var _has_active_tnt := false
var _slide_falling := false
var _stuck_token := 0
var _skip_busy := false
var _tutorial_step := -1
# some Android devices deliver the back request twice per press; ignore a
# second one inside this window so the pause popup does not open-then-close
var _last_back_ms := 0


func _process(delta: float) -> void:
	if paused:
		return
	if _slide_falling:
		player.position.y -= delta * 5.0
		if player.position.y < -1.2:
			_slide_falling = false
		ui.set_fire_bar(false, 0.0)
		return
	if state != State.PLAYING:
		ui.set_fire_bar(false, 0.0)
		return
	if _tutorial_step != -1:
		_tutorial_step = current_path_index

	blocks.update(delta, self)
	if blocks.slide_expired:
		blocks.slide_expired = false
		_slide_falling = true
	if blocks.is_slide_active():
		var p := blocks.slide_progress()
		var pos := path[current_path_index]
		var d := Cfg.dir_vec(blocks.slide_dir)
		player.position = Vector3(pos.x + d.x * 0.45 * p, Cfg.PLAYER_Y, pos.y + d.y * 0.45 * p)
	ui.set_fire_bar(blocks.fire_active(), blocks.fire_percent())


# --- level setup -------------------------------------------------------------

func start_game() -> void:
	mode = Mode.CAMPAIGN
	is_tutorial = false
	level = Save.current_level()
	ui.show_levels(level)


func start_level(l: int) -> void:
	mode = Mode.CAMPAIGN
	is_tutorial = false
	level = l
	_setup({
		"level": l,
	})


func start_endless() -> void:
	mode = Mode.ENDLESS
	is_tutorial = false
	ui.hide_all()
	cleanup()
	run_streak = 0
	run_seed = int(Time.get_ticks_usec()) & 0x7fffffff
	if run_seed == 0:
		run_seed = 1
	_start_endless_segment()


func start_daily() -> void:
	mode = Mode.DAILY
	is_tutorial = false
	ui.hide_all()
	cleanup()
	if Save.is_daily_done():
		_show_daily_done()
		return
	_start_daily_level()


func _show_daily_done() -> void:
	state = State.MENU
	ui.show_game_over("DAILY COMPLETE!", "Come back tomorrow for a new challenge!",
		"Streak: " + str(Save.daily_streak()) + " days", "MENU")


func _start_daily_level() -> void:
	# JS startDailyLevel: fixed 25-cell path, level 200 block tier, no hearts
	var path_len := 25
	_setup({
		"level": 200,
		"seed": Save.today_key() * 7919 + 7,
		"path_length": path_len,
		"turn_bias": 0.8,
		"min_turns": maxi(1, int(floor(path_len / 3.0))),
		"no_hearts": true,
		"can_skip": false,
		"phase_text": "Daily Challenge!",
	})


func launch_tutorial() -> void:
	is_tutorial = true
	_setup({
		"tutorial": true,
		"level": 0,
		"seed": 1,
		"no_hearts": true,
		"can_skip": false,
		"phase_text": "Tutorial",
	})
	_start_tutorial()


func _setup(opts: Dictionary) -> void:
	cleanup()
	# a new level must never inherit a stuck pause (e.g. settings opened from the
	# menu set paused=true); show_path_wave blocks forever on `while paused`
	paused = false
	cube_grid.paused = false
	_sequence_id += 1
	is_tutorial = bool(opts.get("tutorial", false))
	var l := int(opts.get("level", 1))
	var path_len := int(opts.get("path_length", get_path_length(l)))
	var seed := int(opts.get("seed", l * 9973 + 42))
	var turn_bias := float(opts.get("turn_bias", get_turn_bias(l)))
	var min_turns := int(opts.get("min_turns", maxi(1, int(floor(path_len / 3.0)))))
	var no_hearts := bool(opts.get("no_hearts", false))
	var can_skip := bool(opts.get("can_skip", true))
	var phase := str(opts.get("phase_text", "Watch!"))

	path = Tutorial.fixed_path() if is_tutorial else path_gen.generate(path_len, seed, turn_bias, min_turns)
	_offset_path_to_center()
	blocks.assign(path, seed, l, 0, no_hearts)
	island_builder.build(path)
	cube_grid.build_from_path(path, blocks)
	camera_rig.adjust_camera_to_path(path)
	segment_start_index = 0
	show_start_index = 0

	player.create(path[0])
	player.is_moving = false
	current_path_index = 0
	health = Cfg.MAX_HEARTS
	_midpoint_rewarded = false
	slide_falling_off()

	state = State.SHOWING
	update_phase_text(phase)
	ui.show_info(true)
	_can_skip = can_skip
	ui.show_action_buttons(false)
	ui.show_tap_overlay(false)
	# skip is live during the reveal (skips the animation, not the level)
	ui.set_skip_visible(can_skip)
	if no_hearts:
		ui.show_hearts(false)
	else:
		ui.show_hearts(true)
		ui.set_hearts(health)
	update_hud()

	_show_sequence()


func get_path_length(l: int) -> int:
	var r: Dictionary = Cfg.PATH_RANGES[Cfg.PATH_RANGES.size() - 1]
	for x in Cfg.PATH_RANGES:
		if l <= int(x["max"]):
			r = x
			break
	var t := minf((float(l) - float(r["min"])) / (float(r["max"]) - float(r["min"])), 1.0)
	return int(round(float(r["len_min"]) + (float(r["len_max"]) - float(r["len_min"])) * t))


func get_turn_bias(l: int) -> float:
	return 0.4 + minf((float(l) - 1.0) / 199.0, 1.0) * 0.4


func _offset_path_to_center() -> void:
	var min_x := INF
	var max_x := -INF
	var min_z := INF
	var max_z := -INF
	for p in path:
		min_x = minf(min_x, float(p.x))
		max_x = maxf(max_x, float(p.x))
		min_z = minf(min_z, float(p.y))
		max_z = maxf(max_z, float(p.y))
	var center := Vector2i(int(round((min_x + max_x) * 0.5)), int(round((min_z + max_z) * 0.5)))
	# ponytail: JS subtracts the float centre, which shifts every cell by half a
	# unit. Rounding the centre instead keeps grid coords integral (decoy lookups
	# and dir_between stay exact) and only translates the level by half a cell.
	for i in path.size():
		path[i] -= center


func cleanup() -> void:
	_clear_stuck_timer()
	_tnt_back_direction = ""
	_active_tnt = Vector2i.ZERO
	_has_active_tnt = false
	_slide_falling = false
	_sequence_id += 1
	ui.hide_all()
	blocks.reset()
	cube_grid.cancel = true
	cube_grid.clear()
	player.destroy()


func slide_falling_off() -> void:
	_slide_falling = false


# --- show sequence -----------------------------------------------------------

func _show_sequence() -> void:
	var seq := _sequence_id
	cube_grid.cancel = false
	await cube_grid.show_path_wave(show_start_index)
	if _sequence_id != seq or state != State.SHOWING:
		return
	cube_grid.draw_path_line(path, segment_start_index)
	ui.show_tap_overlay(true)
	ui.set_skip_visible(false)


func tap_to_start() -> void:
	if state != State.SHOWING:
		return
	var seq := _sequence_id
	ui.show_tap_overlay(false)
	cube_grid.remove_path_line()
	cube_grid.cancel = false
	await cube_grid.hide_path_wave(true, show_start_index)
	if _sequence_id != seq or state != State.SHOWING or paused:
		return
	cube_grid.start_idle_animations()
	begin_playing()


func begin_playing() -> void:
	state = State.PLAYING
	environment.set_fog(true)
	update_phase_text("Go!")
	ui.set_skip_visible(_can_skip)
	ui.show_action_buttons(true)
	ui.show_dpad(Save.input_mode() != "swipe")
	_start_stuck_timer()


# --- moves -------------------------------------------------------------------

func handle_move(direction: String) -> void:
	if state != State.PLAYING or paused or player.is_moving:
		return
	direction = camera_rig.screen_to_world(direction)
	if blocks.fuse_active():
		if direction == _tnt_back_direction:
			_back_to_previous()
		return

	var next_index := current_path_index + 1
	if next_index >= path.size():
		return
	var current := path[current_path_index]
	var nxt := path[next_index]

	if Cfg.dir_between(current, nxt) == direction:
		blocks.cancel_slide()
		_clear_stuck_timer()
		current_path_index = next_index
		var from_pos := current
		player.move_to(nxt, next_index, func() -> void: _on_stepped(next_index, from_pos))
		return

	var np := current + Cfg.dir_vec(direction)
	if blocks.is_decoy(np.x, np.y):
		_clear_stuck_timer()
		_tnt_back_direction = Cfg.opposite(Cfg.dir_between(current, np))
		_active_tnt = np
		_has_active_tnt = true
		player.move_to(np, -1, func() -> void:
			cube_grid.rise_decoy_at(np.x, np.y)
			blocks.activate_tnt(self))
	else:
		game_over()


func _on_stepped(index: int, from_pos: Vector2i) -> void:
	cube_grid.rise_cube_at(index)
	if index == path.size() - 1:
		win_level()
		return
	blocks.on_entered(index, self, from_pos)
	if not _midpoint_rewarded and index >= int(floor(path.size() / 2.0)):
		_midpoint_rewarded = true
		add_health(1)
		update_phase_text("Midway! +1 Heart")
	_start_stuck_timer()


func hint_move() -> void:
	Snd.play("hint", "sfx", 0.9)
	if state != State.PLAYING or paused or player.is_moving:
		return
	if blocks.fuse_active() or blocks.is_slide_active():
		return
	var next_index := current_path_index + 1
	if next_index >= path.size():
		return
	_clear_stuck_timer()
	current_path_index = next_index
	player.current_index = next_index
	var nxt := path[next_index]
	var prev := path[next_index - 1]
	player.position = Vector3(nxt.x, Cfg.PLAYER_Y, nxt.y)
	player.set_face_direction(float(nxt.x - prev.x), float(nxt.y - prev.y))
	cube_grid.hint_rise_at(next_index)
	if next_index == path.size() - 1:
		win_level()
		return
	_start_stuck_timer()


func _back_to_previous() -> void:
	if state != State.PLAYING or paused or player.is_moving:
		return
	if not blocks.fuse_active():
		return
	var target := current_path_index - 1
	if target < 0:
		return
	blocks.defuse_tnt(self)
	current_path_index = target
	var t := target
	player.move_to(path[t], t, func() -> void:
		cube_grid.rise_cube_at(t)
		blocks.on_entered(t, self, path[t - 1])
		_start_stuck_timer())


# --- TNT ---------------------------------------------------------------------

func on_tnt_activated() -> void:
	Snd.play("tnt-fuse", "sfx", 0.8)
	update_phase_text("TNT! Go back!")
	ui.highlight_tnt_back(_tnt_back_direction)


func on_tnt_defused() -> void:
	update_phase_text("Go!")
	ui.clear_tnt_back()
	_tnt_back_direction = ""
	_active_tnt = Vector2i.ZERO
	_has_active_tnt = false


func on_tnt_exploded() -> void:
	# JS plays the boom 120ms after the fuse cuts out, so it lands with the blast
	var timer := get_tree().create_timer(0.12)
	timer.timeout.connect(func() -> void: Snd.play("tnt-boom", "sfx", 1.0))
	update_phase_text("BOOM!")
	ui.clear_tnt_back()
	_tnt_back_direction = ""
	var pos := _active_tnt
	var had_tnt := _has_active_tnt
	_active_tnt = Vector2i.ZERO
	_has_active_tnt = false
	if had_tnt:
		await get_tree().create_timer(0.12).timeout
		cube_grid.blast_at(pos.x, pos.y)
		await get_tree().create_timer(0.48).timeout
	game_over()


# --- health ------------------------------------------------------------------

func add_health(amount: int) -> void:
	Snd.play("heart-pickup", "sfx", 0.9)
	health = mini(health + amount, Cfg.MAX_HEARTS)
	ui.set_hearts(health)


func on_fire_burned() -> void:
	Snd.play("fire-warn", "sfx", 0.9, 800)
	health -= 1
	ui.set_hearts(health)
	update_phase_text("Burned! -1 Heart")
	if health <= 0:
		game_over()


# --- flow --------------------------------------------------------------------

func win_level() -> void:
	if state != State.PLAYING:
		return
	if mode == Mode.ENDLESS:
		_endless_complete()
		return
	state = State.WON
	Snd.play("win", "sfx", 1.0)
	var tut_win := is_tutorial
	if tut_win:
		stop_tutorial(false)
	update_phase_text("Daily Complete!" if mode == Mode.DAILY else "Level Complete!")
	ui.show_action_buttons(false)
	ui.set_skip_visible(false)
	ui.show_dpad(false)
	ui.hide_tap_overlay()

	if tut_win:
		Save.set_tutorial_seen()
	elif mode == Mode.DAILY:
		Save.mark_daily_complete()
	else:
		Save.mark_completed(level)
		Save.set_current_level(level + 1)

	await get_tree().create_timer(0.5).timeout
	if state != State.WON:
		return
	if mode == Mode.DAILY:
		ui.show_win("DAILY COMPLETE!", "Streak: " + str(Save.daily_streak()) + " days", "MENU")
	elif tut_win:
		ui.show_win("TUTORIAL COMPLETE!", "", "MENU")
	else:
		ui.show_win("LEVEL COMPLETE!", "", "NEXT LEVEL")


## JS nextLevel. The daily win popup and the tutorial both leave to the menu.
func win_action() -> void:
	if mode == Mode.DAILY or is_tutorial:
		back_to_menu()
		return
	next_level()


func next_level() -> void:
	level += 1
	Save.set_current_level(level)
	_setup({"level": level})


func game_over() -> void:
	if state == State.GAMEOVER or state == State.WON:
		return
	state = State.GAMEOVER
	Snd.play("gameover", "sfx", 1.0)
	update_phase_text("Game Over")
	ui.show_action_buttons(false)
	ui.set_skip_visible(false)
	ui.show_dpad(false)
	ui.hide_tap_overlay()
	if is_tutorial:
		stop_tutorial(false)

	var detail := "Level " + str(level)
	if mode == Mode.ENDLESS:
		detail = "Islands: " + str(run_streak) + " (Best: " + str(Save.best_endless()) + ")"
	elif mode == Mode.DAILY:
		detail = "Daily " + Save.date_label() + " — Streak: " + str(Save.daily_streak()) + " days"

	await get_tree().create_timer(0.3).timeout
	if state == State.GAMEOVER:
		ui.show_game_over("GAME OVER", "Wrong direction!", detail, "TRY AGAIN")


func restart() -> void:
	match mode:
		Mode.ENDLESS:
			cleanup()
			run_streak = 0
			run_seed = int(Time.get_ticks_usec()) & 0x7fffffff
			if run_seed == 0:
				run_seed = 1
			_start_endless_segment()
		Mode.DAILY:
			cleanup()
			if Save.is_daily_done():
				back_to_menu()
				return
			_start_daily_level()
		_:
			if is_tutorial:
				launch_tutorial()
			else:
				_setup({"level": level})
	update_hud()


func back_to_menu() -> void:
	cleanup()
	paused = false
	cube_grid.paused = false
	_sequence_id += 1
	state = State.MENU
	is_tutorial = false
	mode = Mode.CAMPAIGN
	stop_tutorial(false)
	update_phase_text("")
	update_hud()
	ui.show_menu()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_handle_back()


## Android hardware / gesture back. Mirrors the JS BackButton mapping
## (settings->menu, levels->menu, pause->resume, win/gameover->menu,
## gameplay->pause) and adds a confirm popup on the home screen, where the JS
## build simply exits the app.
func _handle_back() -> void:
	if ui == null:
		return
	var now := Time.get_ticks_msec()
	if now - _last_back_ms < 300:
		return
	_last_back_ms = now
	if ui.exit_visible():
		ui.hide_exit()
		return
	if ui.screen == UI.Screen.SETTINGS:
		hide_settings()
		return
	if ui.screen == UI.Screen.LEVELS:
		hide_level_select()
		return
	if state == State.WON or state == State.GAMEOVER:
		back_to_menu()
		return
	if state == State.SHOWING or state == State.PLAYING:
		if paused:
			resume_from_pause()
		else:
			toggle_pause()
		return
	ui.show_exit()


## JS skipShow. Campaign only: it burns the level and loads the next one.
func skip_show() -> void:
	if mode != Mode.CAMPAIGN:
		return
	# during the reveal the same button skips the ANIMATION, not the level
	if state == State.SHOWING:
		skip_reveal()
		return
	if state == State.MENU or state == State.GAMEOVER or state == State.WON or _skip_busy:
		return
	_skip_busy = true
	Save.mark_skipped(level)
	level += 1
	Save.set_current_level(level)
	_setup({"level": level})
	# JS holds skipBusy for 500ms so a double tap cannot skip two levels
	await get_tree().create_timer(0.5).timeout
	_skip_busy = false


## skip the reveal animation only: snap the whole path up at once, then hand
## over to the tap-to-start overlay (the level itself is not skipped)
func skip_reveal() -> void:
	if state != State.SHOWING:
		return
	_sequence_id += 1
	cube_grid.cancel = true
	cube_grid.reveal_all_now(show_start_index)
	cube_grid.draw_path_line(path, segment_start_index)
	ui.set_skip_visible(false)
	ui.show_tap_overlay(true)


func toggle_pause() -> void:
	if state != State.SHOWING and state != State.PLAYING:
		return
	if ui.screen != UI.Screen.NONE:
		return
	paused = not paused
	cube_grid.paused = paused
	if paused:
		ui.show_pause()
		ui.hide_tap_overlay()
	else:
		ui.hide_pause()
		if state == State.SHOWING:
			ui.show_tap_overlay(true)


func resume_from_pause() -> void:
	paused = false
	cube_grid.paused = false
	ui.hide_pause()
	if state == State.SHOWING:
		ui.show_tap_overlay(true)


func rotate_view() -> void:
	if path.is_empty():
		return
	camera_rig.rotate_view(90.0)
	# rotateView() reuses the distance it already computed, which was fitted for
	# the old yaw and can leave the path hanging off the side. Re-fit for the new
	# yaw; same island, same framing, just never clipped.
	camera_rig.adjust_camera_to_path(path, camera_rig.cam_segment_start,
		camera_rig.cam_segment_end)
	Snd.play("camera-rotate", "sfx", 0.8)


## JS startEndlessSegment. Segment 0 lays out a fresh island; later segments
## append after the previous goal and retry until the new island clears the old
## ones and the 3x3 base around it is free.
func _start_endless_segment() -> void:
	_sequence_id += 1
	var length := int(round(clampf(8.0 + run_streak * 0.75, 8.0, 25.0)))
	var pseudo_level := mini(run_streak * 5 + 1, 200)
	var turn_bias := minf(0.4 + run_streak * 0.05, 0.8)
	var min_turns := maxi(1, int(floor(length / 3.0)))
	var seg_seed := (run_seed + run_streak * 7919) & 0x7fffffff

	if run_streak == 0:
		# a fresh island must not cross any other island
		var attempt := 0
		while true:
			path = path_gen.generate(length, (seg_seed + attempt * 1013) & 0x7fffffff, turn_bias, min_turns)
			_offset_path_to_center()
			island_builder.build(path)
			var crosses := false
			for i in range(1, path.size() - 1):
				if island_builder.is_on_island(path[i].x, path[i].y):
					crosses = true
					break
			attempt += 1
			if not crosses:
				break
			if attempt > 40:
				break
		segment_start_index = 0
	else:
		var old_len := path.size()
		var last := path[old_len - 1]
		var blocked := {}
		for p in path:
			blocked[PathGenerator.key(p)] = true
		# every island cell except the goal blocks, so the new segment cannot
		# land on top of an island that is still on screen
		for c in island_builder.islands:
			for dx in range(-1, 2):
				for dz in range(-1, 2):
					var cell := c + Vector2i(dx, dz)
					if absi(cell.x - last.x) + absi(cell.y - last.y) <= 1 \
							and cell != last and (dx != 0 or dz != 0):
						continue
					blocked[PathGenerator.key(cell)] = true
		for d in blocks.decoys:
			blocked[PathGenerator.key(d)] = true

		var seg: Array[Vector2i] = []
		for attempt in range(40):
			var cand := path_gen.generate(length, (seg_seed + attempt * 1013) & 0x7fffffff,
				turn_bias, min_turns, PackedStringArray(blocked.keys()), last, path[0])
			if cand.is_empty():
				continue
			var new_keys := PackedStringArray()
			for i in range(1, cand.size()):
				new_keys.append(PathGenerator.key(cand[i]))
			var e := cand[cand.size() - 1]
			var prev: Vector2i = cand[cand.size() - 2]
			var e_base := Vector2i(e.x + (e.x - prev.x), e.y + (e.y - prev.y))
			var too_close := false
			for c in island_builder.islands:
				if absi(c.x - e_base.x) < 4 and absi(c.y - e_base.y) < 4:
					too_close = true
					break
			if too_close:
				continue
			var base_ok := true
			for bx in range(-1, 2):
				for bz in range(-1, 2):
					var k := PathGenerator.key(e_base + Vector2i(bx, bz))
					if blocked.has(k) or (k != PathGenerator.key(e) and new_keys.has(k)):
						base_ok = false
						break
				if not base_ok:
					break
			if not base_ok:
				continue
			seg = cand
			break
		if seg.is_empty():
			seg = path_gen.generate(length, seg_seed, turn_bias, min_turns)
		var merged: Array[Vector2i] = path.duplicate()
		for i in range(1, seg.size()):
			merged.append(seg[i])
		path = merged
		segment_start_index = old_len - 1

	blocks.assign(path, seg_seed, pseudo_level, segment_start_index, true)
	blocks.types[segment_start_index] = Cfg.T_GRASS
	if run_streak == 0:
		show_start_index = 0
	else:
		cube_grid.retype_cube(segment_start_index, Cfg.T_GRASS)
		island_builder.build_end_only(path)
		show_start_index = segment_start_index + 1
		current_path_index = segment_start_index
	cube_grid.build_from_path(path, blocks, show_start_index)
	camera_rig.adjust_camera_to_path(path, segment_start_index, path.size() - 1)
	if run_streak == 0:
		player.create(path[0])
		current_path_index = 0
	player.is_moving = false
	player.is_moving = false

	health = 1
	_midpoint_rewarded = true
	slide_falling_off()

	# endless has no skip button; clear the flag or begin_playing() re-shows the
	# stale value left over from the last campaign level
	_can_skip = false
	state = State.SHOWING
	update_phase_text("Island " + str(run_streak + 1) + "! Watch!")
	ui.show_info(true)
	ui.set_skip_visible(false)
	ui.show_action_buttons(false)
	ui.show_dpad(false)
	ui.show_tap_overlay(false)
	ui.show_hearts(false)
	update_hud()

	_show_sequence()


## JS endlessComplete: no popup, straight into the next island.
func _endless_complete() -> void:
	state = State.WON
	run_streak += 1
	update_phase_text("Island " + str(run_streak) + " Complete!")
	ui.show_action_buttons(false)
	ui.show_dpad(false)
	if run_streak > Save.best_endless():
		Save.set_best_endless(run_streak)
	update_hud()
	await cube_grid.sink_old_cubes(path.size() - 1)
	if state != State.WON:
		return
	_start_endless_segment()


# --- tutorial ----------------------------------------------------------------

func _start_tutorial() -> void:
	_tutorial_step = 0
	ui.show_tutorial(Tutorial.text_at(0), Tutorial.keys_at(0))


func _update_tutorial() -> void:
	if _tutorial_step < 0:
		return
	ui.show_tutorial(Tutorial.text_at(_tutorial_step), Tutorial.keys_at(_tutorial_step))


func stop_tutorial(skipped: bool) -> void:
	if _tutorial_step == -1 and not skipped:
		return
	_tutorial_step = -1
	ui.hide_tutorial()
	if skipped:
		Save.set_tutorial_seen()
		back_to_menu()


# --- meta screens ------------------------------------------------------------

func show_settings() -> void:
	paused = true
	cube_grid.paused = true
	ui.show_settings()


func hide_settings() -> void:
	# show_settings() sets these true; every exit path must clear them, or the
	# next level's show_path_wave() parks forever on `while paused:` and the
	# path never rises (until a pause tap flips the flag back).
	paused = false
	cube_grid.paused = false
	if state == State.MENU:
		ui.show_menu()
		return
	if state == State.SHOWING:
		ui.show_tap_overlay(true)


func hide_level_select() -> void:
	back_to_menu()


func set_input_mode(m: String) -> void:
	Save.set_input_mode(m)
	ui.show_settings()
	ui.show_dpad(state == State.PLAYING and m != "swipe")


func reset_progress() -> void:
	Save.reset_progress()
	level = Save.current_level()
	update_hud()
	ui.show_settings()


## Enter / Space on the win and game-over popups.
func confirm() -> void:
	if state == State.WON:
		win_action()
	elif state == State.GAMEOVER:
		restart()


func is_playing() -> bool:
	return state == State.PLAYING


func update_phase_text(text: String) -> void:
	ui.set_phase(text)


func update_hud() -> void:
	match mode:
		Mode.ENDLESS:
			ui.set_level("Island " + str(run_streak + 1))
		Mode.DAILY:
			ui.set_level("Daily " + Save.date_label())
		_:
			ui.set_level("Level " + str(level))


# --- stuck hint --------------------------------------------------------------

func _start_stuck_timer() -> void:
	_stuck_token += 1
	var token := _stuck_token
	ui.set_hint_glow(false)
	await get_tree().create_timer(Cfg.STUCK_HINT_MS / 1000.0).timeout
	if token == _stuck_token and state == State.PLAYING and not paused:
		ui.set_hint_glow(true)


func _clear_stuck_timer() -> void:
	_stuck_token += 1
	if ui != null:
		ui.set_hint_glow(false)