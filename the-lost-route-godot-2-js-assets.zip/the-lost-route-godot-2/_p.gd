extends SceneTree

## Prints the header back-button geometry on the levels + settings screens and
## lists anything drawn on top of its centre, to catch an input-eater overlay.


func _initialize() -> void:
	var main: Node = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	root.add_child(main)
	_go(main)


func _go(main: Node) -> void:
	for _i in 4:
		await process_frame
	var gm: GameManager = main.get_node("Game")
	var ui: UI = gm.ui

	gm.show_settings()
	for _i in 3:
		await process_frame
	_report("settings", ui._settings_screen)

	gm.start_game()
	for _i in 3:
		await process_frame
	_report("levels", ui._levels_screen)

	quit()


func _report(label: String, screen: Control) -> void:
	var btn := _first_icon_button(screen)
	print("--- ", label, " screen.vis=", screen.visible, " ---")
	if btn == null:
		print("  NO BACK BUTTON FOUND")
		return
	var r := btn.get_global_rect()
	print("  back btn rect=", r, " visible=", btn.visible, " filter=", btn.mouse_filter)
	var c := r.position + r.size * 0.5
	for ch in _controls_at(screen, c):
		print("    over centre: ", ch.get_class(), " rect=", (ch as Control).get_global_rect(),
			" filter=", (ch as Control).mouse_filter)


func _first_icon_button(n: Node) -> Button:
	for c in n.get_children():
		if c is Button and (c as Button).text == "":
			return c
		var f := _first_icon_button(c)
		if f != null:
			return f
	return null


func _controls_at(n: Node, p: Vector2) -> Array:
	var out := []
	for c in n.get_children():
		if c is Control and (c as Control).visible \
				and (c as Control).get_global_rect().has_point(p) \
				and (c as Control).mouse_filter != Control.MOUSE_FILTER_IGNORE:
			out.append(c)
		out.append_array(_controls_at(c, p))
	return out