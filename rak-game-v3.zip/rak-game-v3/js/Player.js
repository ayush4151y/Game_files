class Player {
  constructor(scene) {
    this.scene = scene;
    this.mesh = null;
    this.currentIndex = 0;
    this.isMoving = false;
  }

  create(pathStartPos, scale = 1) {
    this._pulseActive = false;
    this._pulseId = (this._pulseId || 0) + 1;
    if (this.mesh) {
      this.scene.remove(this.mesh);
      this.disposeParts();
    }

    this.isMoving = false;
    this.currentIndex = 0;
    this._parts = [];

    const group = new THREE.Group();

    const bodyGeo = this.makeRoundedBox(0.56, 0.56, 0.56, 0.17, 6);
    const bodyMat = new THREE.MeshPhongMaterial({
      color: 0x9be3ef,
      emissive: 0x2fb6cf,
      emissiveIntensity: 0.22,
      shininess: 60
    });
    applyToon(bodyMat);
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    body.castShadow = true;
    group.add(body);
    this._parts.push(body);

    const half = 0.28;
    const proud = 0.035;
    this.face = this.makeFace();
    this.face.position.set(0, 0, half + proud);
    group.add(this.face);
    this._parts.push(this.face);

    this.mesh = group;
    this.mesh.position.set(pathStartPos.x, 1.2, pathStartPos.z);
    this.mesh.scale.set(scale, scale, scale);
    this.scene.add(this.mesh);

    this.idlePulse();
  }

  setFaceDirection(dx, dz) {
    if (!this.mesh) return;
    if (this.face) this.face.rotation.y = 0;
    const angle = Math.atan2(dx, dz);
    this.mesh.rotation.y = angle;
  }

  setFire(on) {
    if (on === this._onFire) return;
    this._onFire = on;
    if (!this.mesh) return;
    const body = this._parts[0];
    if (!body || !body.material) return;

    if (on) {
      if (!this._origColor) {
        this._origColor = body.material.color.getHex();
        this._origEmissive = body.material.emissive.getHex();
        this._origIntensity = body.material.emissiveIntensity;
      }
      this._fireBlink = true;
      const blink = () => {
        if (!this._fireBlink || !body.material) return;
        const tick = Math.floor(performance.now() / 140) % 2 === 0;
        if (tick) {
          body.material.color.setHex(0xff4444);
          body.material.emissive.setHex(0xff2222);
          body.material.emissiveIntensity = 0.8;
        } else {
          body.material.color.setHex(this._origColor);
          body.material.emissive.setHex(this._origEmissive);
          body.material.emissiveIntensity = this._origIntensity;
        }
        requestAnimationFrame(blink);
      };
      blink();
    } else {
      this._fireBlink = false;
      if (this._origColor) {
        body.material.color.setHex(this._origColor);
        body.material.emissive.setHex(this._origEmissive);
        body.material.emissiveIntensity = this._origIntensity;
      }
    }
  }

  makeFace() {
    const g = new THREE.Group();
    const eyeGeo = new THREE.SphereGeometry(0.085, 14, 12);
    const eyeMat = new THREE.MeshPhongMaterial({ color: 0x1b2b36, emissive: 0x0e1a20, emissiveIntensity: 0.3, shininess: 90 });
    const eyeL = new THREE.Mesh(eyeGeo, eyeMat);
    eyeL.position.set(-0.105, 0.14, 0);
    const eyeR = new THREE.Mesh(eyeGeo, eyeMat);
    eyeR.position.set(0.105, 0.14, 0);

    const glintGeo = new THREE.SphereGeometry(0.028, 8, 8);
    const glintMat = new THREE.MeshPhongMaterial({ color: 0xffffff, emissive: 0xffffff, emissiveIntensity: 0.8, shininess: 100 });
    const glintL = new THREE.Mesh(glintGeo, glintMat);
    glintL.position.set(-0.115, 0.165, 0.065);
    const glintR = new THREE.Mesh(glintGeo, glintMat);
    glintR.position.set(0.095, 0.165, 0.065);

    const cheekGeo = new THREE.SphereGeometry(0.045, 10, 8);
    const cheekMat = new THREE.MeshPhongMaterial({ color: 0xff8fa5, emissive: 0xff6b83, emissiveIntensity: 0.35, shininess: 40 });
    const cheekL = new THREE.Mesh(cheekGeo, cheekMat);
    cheekL.position.set(-0.2, 0.04, 0.02);
    const cheekR = new THREE.Mesh(cheekGeo, cheekMat);
    cheekR.position.set(0.2, 0.04, 0.02);

    const blushGeo = new THREE.SphereGeometry(0.02, 8, 8);
    const blushMat = new THREE.MeshPhongMaterial({ color: 0xffd2dc, emissive: 0xffc2cf, emissiveIntensity: 0.3 });
    const blushL = new THREE.Mesh(blushGeo, blushMat);
    blushL.position.set(-0.13, 0.1, 0.06);
    const blushR = new THREE.Mesh(blushGeo, blushMat);
    blushR.position.set(0.13, 0.1, 0.06);

    g.add(eyeL, eyeR, glintL, glintR, cheekL, cheekR, blushL, blushR);
    this._parts.push(eyeL, eyeR, glintL, glintR, cheekL, cheekR, blushL, blushR);
    return g;
  }

  makeRoundedBox(width, height, depth, radius, segments) {
    const geo = new THREE.BoxGeometry(width, height, depth, segments, segments, segments);
    const pos = geo.attributes.position;
    const halfW = width / 2, halfH = height / 2, halfD = depth / 2;
    const r = Math.min(radius, halfW, halfH, halfD);
    const v = new THREE.Vector3();
    for (let i = 0; i < pos.count; i++) {
      v.fromBufferAttribute(pos, i);
      const ax = Math.max(Math.abs(v.x) - (halfW - r), 0);
      const ay = Math.max(Math.abs(v.y) - (halfH - r), 0);
      const az = Math.max(Math.abs(v.z) - (halfD - r), 0);
      const d = Math.sqrt(ax * ax + ay * ay + az * az);
      if (d > r) {
        const t = r / d;
        v.x = Math.sign(v.x) * ((halfW - r) + ax * t);
        v.y = Math.sign(v.y) * ((halfH - r) + ay * t);
        v.z = Math.sign(v.z) * ((halfD - r) + az * t);
      }
      pos.setXYZ(i, v.x, v.y, v.z);
    }
    pos.needsUpdate = true;
    geo.computeVertexNormals();
    return geo;
  }

  disposeParts() {
    if (this._parts) {
      this._parts.forEach(p => {
        if (p.geometry) p.geometry.dispose();
        if (p.material) p.material.dispose();
      });
      this._parts = [];
    }
  }

  idlePulse() {
    if (!this.mesh) return;
    this._pulseActive = true;
    const pulseId = this._pulseId;

    const startScale = this.mesh.scale.x || 1;
    const duration = 800;
    const start = performance.now();

    const pulse = () => {
      if (!this._pulseActive || !this.mesh || this._pulseId !== pulseId) return;
      const elapsed = (performance.now() - start) % duration;
      const t = elapsed / duration;
      const scale = startScale + 0.08 * Math.sin(t * Math.PI * 2);
      this.mesh.scale.set(scale, scale, scale);
      requestAnimationFrame(pulse);
    };
    pulse();
  }

  moveTo(pos, pathIndex, callback) {
    if (this.isMoving) return;
    this.isMoving = true;

    const startPos = this.mesh.position.clone();
    this.setFaceDirection(pos.x - startPos.x, pos.z - startPos.z);
    const endPos = new THREE.Vector3(pos.x, 1.2, pos.z);
    const duration = 200;
    const startTime = performance.now();

    const update = () => {
      const elapsed = performance.now() - startTime;
      const t = Math.min(elapsed / duration, 1);
      const ease = 1 - Math.pow(1 - t, 3);

      this.mesh.position.lerpVectors(startPos, endPos, ease);

      const bounceY = Math.sin(t * Math.PI) * 0.15;
      this.mesh.position.y = 1.2 + bounceY;

      if (t < 1) {
        requestAnimationFrame(update);
      } else {
        this.mesh.position.copy(endPos);
        this.currentIndex = pathIndex;
        this.isMoving = false;
        if (callback) callback();
      }
    };
    update();
  }

  destroy() {
    this._pulseActive = false;
    this._fireBlink = false;
    this._onFire = false;
    if (this.mesh) {
      this.scene.remove(this.mesh);
      this.disposeParts();
      this.mesh = null;
    }
  }
}
