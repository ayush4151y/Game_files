const scene = new THREE.Scene();

const camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 400);
camera.position.set(0, 10, 14);
camera.lookAt(0, 0, 0);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.outputEncoding = THREE.sRGBEncoding;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
const MAX_ANISO = renderer.capabilities.getMaxAnisotropy();

const container = document.getElementById('game-container');
container.insertBefore(renderer.domElement, container.firstChild);

const ambientLight = new THREE.AmbientLight(0x9fc8e8, 0.55);
scene.add(ambientLight);

const dirLight = new THREE.DirectionalLight(0xffe6b0, 1.05);
dirLight.position.set(12, 18, 6);
dirLight.castShadow = true;
dirLight.shadow.mapSize.width = 1024;
dirLight.shadow.mapSize.height = 1024;
dirLight.shadow.camera.left = -32;
dirLight.shadow.camera.right = 32;
dirLight.shadow.camera.top = 32;
dirLight.shadow.camera.bottom = -32;
dirLight.shadow.camera.near = 1;
dirLight.shadow.camera.far = 60;
dirLight.shadow.bias = -0.0004;
scene.add(dirLight);

const fillLight = new THREE.DirectionalLight(0x88b8e8, 0.35);
fillLight.position.set(-6, 6, -6);
scene.add(fillLight);

const rimLight = new THREE.DirectionalLight(0xffd9b0, 0.3);
rimLight.position.set(-10, 4, 12);
scene.add(rimLight);

window.gm = new GameManager(scene, camera);
const ui = new UIController(gm);
window.gameAudio = new GameAudio();
ui.initVolumeSliders();
const soundBtn = document.getElementById('sound-toggle-btn');
if (soundBtn) soundBtn.textContent = 'SOUND: ' + (window.gameAudio.isMuted() ? 'OFF' : 'ON');
const audioUnlock = (e) => {
  const ga = window.gameAudio;
  ga.unlock().then((ok) => {
    if (!ok) return;
    ga.startAmbience();
    ga.startIslandAmbience();
    ['pointerdown', 'touchstart', 'click', 'keydown'].forEach((evt) => {
      document.removeEventListener(evt, audioUnlock);
    });
  });
};
['pointerdown', 'touchstart', 'click', 'keydown'].forEach((evt) => {
  document.addEventListener(evt, audioUnlock, evt === 'touchstart' || evt === 'pointerdown' ? { passive: true } : false);
});

window.launchTutorial = () => {
  if (window.activeTutorial) window.activeTutorial.stop(false);
  window.gm.hideAllScreens();
  document.getElementById('info-bar').classList.add('hidden');
  window.gm.setupLevel({ tutorial: true, level: 0, seed: 1, noHearts: true, canSkip: false, phaseText: 'Tutorial' });
  new Tutorial().start();
};
const firstVisit = !localStorage.getItem('rak_tutorial');
if (firstVisit) {
  window.launchTutorial();
}

const onHidden = () => {
  if (window.gameAudio) window.gameAudio.pause();
};
const onVisible = () => {
  const gm = window.gm;
  if (window.gameAudio && gm && !gm.paused) window.gameAudio.resume();
};
document.addEventListener('visibilitychange', () => {
  if (document.hidden) onHidden(); else onVisible();
});
window.addEventListener('pagehide', onHidden);
gm.currentLevel = gm.getCurrentLevel();
gm.mode = gm.getMode();
if (!firstVisit) {
  gm.islandBuilder.buildMenuIsland();
  gm.player.create({ x: 0, z: 0 }, 3);
  gm.player.mesh.position.y = 3.1;
}
gm.updateHUD();

let cameraAngle = 0;
let lastTime = performance.now();
function animateCamera() {
  if (gm.state === 'menu') {
    cameraAngle += 0.003;
    const radius = 8;
    camera.position.x = Math.sin(cameraAngle) * radius;
    camera.position.z = Math.cos(cameraAngle) * radius;
    camera.position.y = 6.2;
    camera.lookAt(0, 0, 0);
    if (gm.player.mesh) {
      gm.player.mesh.rotation.y = Math.atan2(camera.position.x - gm.player.mesh.position.x, camera.position.z - gm.player.mesh.position.z);
    }
  }
}

(() => {
  const isCoarse = () => (navigator.maxTouchPoints || 0) > 0 || /Android|webOS|iPhone|iPad|iPod|Mobile|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  const overlay = document.getElementById('rotate-overlay');

  function isLandscape() {
    if (screen.orientation && screen.orientation.type) {
      return screen.orientation.type.indexOf('landscape') === 0;
    }
    if (window.orientation !== undefined) {
      return Math.abs(window.orientation) === 90;
    }
    return window.innerWidth > window.innerHeight;
  }

  function canFullscreen() {
    const doc = document.documentElement;
    return (
      (doc.requestFullscreen || doc.webkitRequestFullscreen || doc.msRequestFullscreen) &&
      !document.fullscreenElement &&
      !document.webkitFullscreenElement
    );
  }

  function enterFullscreen() {
    if (!canFullscreen()) return;
    const doc = document.documentElement;
    try {
      if (doc.requestFullscreen) doc.requestFullscreen();
      else if (doc.webkitRequestFullscreen) doc.webkitRequestFullscreen();
      else if (doc.msRequestFullscreen) doc.msRequestFullscreen();
    } catch (e) { /* fullscreen blocked */ }
  }

  let fullscreenGestureBound = false;
  function bindFullscreenGesture() {
    if (fullscreenGestureBound || !isCoarse()) return;
    fullscreenGestureBound = true;
    document.addEventListener(
      'pointerdown',
      () => {
        if (isLandscape() && canFullscreen()) enterFullscreen();
      },
      { once: false, passive: true }
    );
  }

  function applyOrientation() {
    const land = isLandscape();
    const ls = document.getElementById('loading-screen');
    document.documentElement.classList.toggle('landscape-locked', !land);
    if (land) {
      overlay.classList.add('hidden');
      if (ls) ls.style.display = '';
      bindFullscreenGesture();
    } else {
      overlay.classList.remove('hidden');
      if (ls && !ls.classList.contains('ls-done')) ls.style.display = 'none';
    }
  }

  function onRotate() {
    applyOrientation();
    renderer.setSize(window.innerWidth, window.innerHeight);
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    gm.handleResize();
  }

  window.addEventListener('resize', onRotate);
  document.addEventListener('fullscreenchange', () => {
    document.body.classList.toggle('is-fullscreen', !!(document.fullscreenElement || document.webkitFullscreenElement));
  });
  document.addEventListener('webkitfullscreenchange', () => {
    document.body.classList.toggle('is-fullscreen', !!document.webkitFullscreenElement);
  });

  function initOrientation() {
    if (!isCoarse() && (navigator.userAgent.indexOf('Mobi') === -1)) {
      overlay.classList.add('hidden');
      return;
    }
    applyOrientation();
    setTimeout(() => {
      if (!isLandscape()) {
        overlay.classList.remove('hidden');
      }
    }, 350);
  }

  if ('onorientationchange' in window) {
    window.addEventListener('orientationchange', onRotate);
  } else {
    let lastW = window.innerWidth;
    setInterval(() => {
      if (window.innerWidth !== lastW) {
        lastW = window.innerWidth;
        onRotate();
      }
    }, 250);
  }
  if (document.readyState === 'complete') initOrientation();
  else window.addEventListener('load', initOrientation);
})();

function animate() {
  requestAnimationFrame(animate);
  const menu = document.getElementById('menu-screen');
  if (menu && !menu.classList.contains('hidden')) return;
  const now = performance.now();
  const dt = Math.min((now - lastTime) / 1000, 0.1);
  lastTime = now;
  animateCamera();
  gm.update(dt);
  renderer.render(scene, camera);
}
animate();
