const RAK_TOON = {
  shadow: 0.35,
  mid: 0.75,
  soft: 0.10,
  saturationBoost: 0.45,
  specScale: 0.35,
  rimAmt: 0.55,
  rimPow: 3.0,
  rimColor: [0.85, 0.75, 1.0],
  shadowTint: [0.85, 0.87, 1.0],
  highlightTint: [1.25, 1.2, 1.0],
  lightDir: new THREE.Vector3(8, 15, 5).normalize()
};

function applyToon(material) {
  material.onBeforeCompile = (shader) => {
    const T = RAK_TOON;
    shader.uniforms.uRakLightDirW = { value: T.lightDir };
    shader.uniforms.uRakShadow = { value: T.shadow };
    shader.uniforms.uRakMid = { value: T.mid };
    shader.uniforms.uRakSoft = { value: T.soft };
    shader.uniforms.uRakSat = { value: T.saturationBoost };
    shader.uniforms.uRakSpecScale = { value: T.specScale };
    shader.uniforms.uRakRimAmt = { value: T.rimAmt };
    shader.uniforms.uRakRimPow = { value: T.rimPow };
    shader.uniforms.uRakRimColor = { value: new THREE.Color().setRGB(...T.rimColor) };
    shader.uniforms.uRakShadowTint = { value: new THREE.Color().setRGB(...T.shadowTint) };
    shader.uniforms.uRakHighTint = { value: new THREE.Color().setRGB(...T.highlightTint) };

    shader.vertexShader =
      'varying vec3 vRakLightDirV;\nvarying vec3 vRakViewDirV;\nuniform vec3 uRakLightDirW;\n' +
      shader.vertexShader.replace(
        '#include <project_vertex>',
        '#include <project_vertex>\n\tvRakLightDirV = normalize( mat3( viewMatrix ) * uRakLightDirW );\n\tvRakViewDirV = - mvPosition.xyz;'
      );

    shader.fragmentShader =
      'varying vec3 vRakLightDirV;\nvarying vec3 vRakViewDirV;\n' +
      'uniform float uRakShadow;\nuniform float uRakMid;\nuniform float uRakSoft;\n' +
      'uniform float uRakSat;\nuniform float uRakSpecScale;\n' +
      'uniform float uRakRimAmt;\nuniform float uRakRimPow;\nuniform vec3 uRakRimColor;\n' +
      'uniform vec3 uRakShadowTint;\nuniform vec3 uRakHighTint;\n' +
      'float rak_ramp( float x ) {\n' +
      '  float bandA = smoothstep( uRakShadow - uRakSoft, uRakShadow + uRakSoft, x );\n' +
      '  float bandB = smoothstep( uRakMid - uRakSoft, uRakMid + uRakSoft, x );\n' +
      '  return mix( 0.65, 0.95, bandA ) + 0.10 * bandB;\n' +
      '}\n' +
      'float rak_lum( vec3 c ) { return dot( c, vec3( 0.299, 0.587, 0.114 ) ); }\n' +
      'vec3 rak_saturate_col( vec3 c, float amt ) {\n' +
      '  float l = rak_lum( c );\n' +
      '  return mix( vec3( l ), c, 1.0 + amt );\n' +
      '}\n' +
      shader.fragmentShader.replace(
        'vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;',
        'vec3 rak_col = rak_saturate_col( diffuseColor.rgb, uRakSat );\n' +
        'float rak_ndl = max( dot( normal, normalize( vRakLightDirV ) ), 0.0 );\n' +
        'float rak_r = rak_ramp( rak_ndl );\n' +
        'vec3 rak_tint = mix( uRakShadowTint, uRakHighTint, rak_r );\n' +
        'vec3 rak_toonBase = rak_col * rak_tint;\n' +
        'float rak_rim = pow( 1.0 - max( dot( normal, normalize( vRakViewDirV ) ), 0.0 ), uRakRimPow );\n' +
        'vec3 rak_diffuseAmt = vec3( rak_lum( reflectedLight.directDiffuse ) * rak_r\n' +
        '  + rak_lum( reflectedLight.indirectDiffuse ) * mix( 1.0, 1.4, rak_r ) );\n' +
        'vec3 rak_light = rak_toonBase * max( rak_diffuseAmt, vec3( 0.55 ) )\n' +
        '  + reflectedLight.directSpecular * uRakSpecScale\n' +
        '  + reflectedLight.indirectSpecular * 0.5;\n' +
        'vec3 outgoingLight = ( rak_light * 1.2 )\n' +
        '  + uRakRimColor * rak_rim * uRakRimAmt * ( 0.4 + 0.6 * rak_r )\n' +
        '  + totalEmissiveRadiance;'
      );
  };
}