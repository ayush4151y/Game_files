class IslandBuilder {
  constructor(scene, cubeGrid) {
    this.scene = scene;
    this.cubeGrid = cubeGrid;
    this.group = null;
    this.geos = [];
    this.mats = [];
    this.idle = [];
    this.islands = [];
    this.startCenter = null;
    this.endCenter = null;
    this.makeGeos();
  }

  makeGeos() {
    this.geoBox = new THREE.BoxGeometry(1, 1, 1);
    this.geoBlob = new THREE.IcosahedronGeometry(1, 0);
    this.geos.push(this.geoBox, this.geoBlob);
  }

  mat(color, emissive, emissiveIntensity, flatShading) {
    const m = new THREE.MeshPhongMaterial({
      color,
      emissive: emissive || 0x000000,
      emissiveIntensity: emissiveIntensity || 0,
      shininess: 12,
      flatShading: !!flatShading
    });
    applyToon(m);
    this.mats.push(m);
    return m;
  }

  box(parent, mat, x, y, z, sx, sy, sz, cast = false) {
    const m = new THREE.Mesh(this.geoBox, mat);
    m.scale.set(sx || 1, sy || 1, sz || 1);
    m.position.set(x, y, z);
    m.castShadow = cast;
    m.receiveShadow = true;
    parent.add(m);
    return m;
  }

  blob(parent, mat, x, y, z, radius, cast = false) {
    const m = new THREE.Mesh(this.geoBlob, mat);
    m.scale.set(radius, radius, radius);
    m.position.set(x, y, z);
    m.castShadow = cast;
    m.receiveShadow = true;
    parent.add(m);
    return m;
  }

  build(path) {
    this.clear();
    const g = new THREE.Group();
    this.group = g;

    const grass = this.cubeGrid.getTypeMaterial(BLOCK_TYPES.GRASS);
    const lip = this.mat(0xa8ddb8);
    const dirt = this.mat(0xb08968);
    const rockA = this.mat(0x9aa8b5, 0, 0, true);
    const rockB = this.mat(0x8b98a6, 0, 0, true);
    const crack = this.mat(0x6d7783, 0, 0, true);
    const moss = this.mat(0x6fae7a);
    const trunk = this.mat(0x8a6248);
    const leaf = this.mat(0x7cc576, 0, 0, true);
    const leaf2 = this.mat(0x8fd98a, 0, 0, true);
    const flowerA = this.mat(0xf28fbd);
    const flowerB = this.mat(0xffd27a);
    const stone = this.mat(0xcfd3dc, 0, 0, true);
    const pillar = this.mat(0x98a0b0, 0, 0, true);
    const rune = this.mat(0xe8dcb0, 0x000000, 0, true);
    const wood = this.mat(0xa07a4f, 0, 0, true);

    const first = path[0];
    const last = path[path.length - 1];
    const dStart = { x: path[1].x - first.x, z: path[1].z - first.z };
    const dEnd = { x: last.x - path[path.length - 2].x, z: last.z - path[path.length - 2].z };
    this.startCenter = { x: first.x - dStart.x, z: first.z - dStart.z };
    this.endCenter = { x: last.x + dEnd.x, z: last.z + dEnd.z };
    this.islands = [this.startCenter, this.endCenter];
    const sC = this.startCenter;
    const eC = this.endCenter;
    const pathSet = new Set(path.map(p => p.x + ',' + p.z));

    const sB = { x: sC.x - first.x, z: sC.z - first.z };
    const sP = { x: -sB.z, z: sB.x };
    const eB = { x: eC.x - last.x, z: eC.z - last.z };
    const eP = { x: -eB.z, z: eB.x };

    this.buildIsland(g, sC, pathSet, grass, lip, dirt, rockA, rockB, crack, moss, null);
    this.buildStartDecor(g, sC, sB, sP, pathSet, trunk, leaf, leaf2, flowerA, flowerB, stone, moss);

    const eNotch = new Set([(last.x + eP.x) + ',' + (last.z + eP.z), (last.x - eP.x) + ',' + (last.z - eP.z)]);
    this.buildIsland(g, eC, pathSet, grass, lip, dirt, rockA, rockB, crack, moss, eNotch);
    this.buildEndRuins(g, eC, eB, eP, stone, pillar, rune, moss, dirt);

    this.scene.add(g);
    this.idle.push({ group: g, phase: hash2(sC.x, sC.z) * 0.001 });
    return g;
  }

  buildMenuIsland() {
    this.clear();
    const g = new THREE.Group();
    this.group = g;

    const grass = this.cubeGrid.getTypeMaterial(BLOCK_TYPES.GRASS);
    const lip = this.mat(0xa8ddb8);
    const dirt = this.mat(0xb08968);
    const rockA = this.mat(0x9aa8b5, 0, 0, true);
    const rockB = this.mat(0x8b98a6, 0, 0, true);
    const crack = this.mat(0x6d7783, 0, 0, true);
    const moss = this.mat(0x6fae7a);
    const trunk = this.mat(0x8a6248);
    const leaf = this.mat(0x7cc576, 0, 0, true);
    const leaf2 = this.mat(0x8fd98a, 0, 0, true);
    const flowerA = this.mat(0xf28fbd);
    const flowerB = this.mat(0xffd27a);
    const stone = this.mat(0xcfd3dc, 0, 0, true);
    const pillar = this.mat(0x98a0b0, 0, 0, true);
    const rune = this.mat(0xe8dcb0, 0x000000, 0, true);

    const c = { x: 0, z: 0 };
    const emptySet = new Set();
    const b = { x: 0, z: 1 };
    const p = { x: -1, z: 0 };

    this.buildIsland(g, c, emptySet, grass, lip, dirt, rockA, rockB, crack, moss, null);
    this.buildStartDecor(g, c, b, p, emptySet, trunk, leaf, leaf2, flowerA, flowerB, stone, moss);
    this.buildEndRuins(g, c, { x: 0, z: -1 }, p, stone, pillar, rune, moss, dirt);

    g.scale.set(1.35, 1.35, 1.35);
    g.traverse(o => {
      if (o.isMesh && o.material) {
        o.material.transparent = false;
        o.material.opacity = 1;
        o.material.depthWrite = true;
      }
    });
    this.scene.add(g);
    this.idle.push({ group: g, phase: hash2(0, 0) * 0.001 });
    return g;
  }

  buildEndOnly(path) {
    this.startCenter = this.endCenter;
    const last = path[path.length - 1];
    const dEnd = { x: last.x - path[path.length - 2].x, z: last.z - path[path.length - 2].z };
    this.endCenter = { x: last.x + dEnd.x, z: last.z + dEnd.z };
    const eC = this.endCenter;
    const eB = { x: eC.x - last.x, z: eC.z - last.z };
    const eP = { x: -eB.z, z: eB.x };
    const pathSet = new Set(path.map(p => p.x + ',' + p.z));

    const grass = this.cubeGrid.getTypeMaterial(BLOCK_TYPES.GRASS);
    const lip = this.mat(0xa8ddb8);
    const dirt = this.mat(0xb08968);
    const rockA = this.mat(0x9aa8b5, 0, 0, true);
    const rockB = this.mat(0x8b98a6, 0, 0, true);
    const crack = this.mat(0x6d7783, 0, 0, true);
    const moss = this.mat(0x6fae7a);
    const stone = this.mat(0xcfd3dc, 0, 0, true);
    const pillar = this.mat(0x98a0b0, 0, 0, true);
    const rune = this.mat(0xe8dcb0, 0x000000, 0, true);
    const g = this.group;

    const eNotch = new Set([(last.x + eP.x) + ',' + (last.z + eP.z), (last.x - eP.x) + ',' + (last.z - eP.z)]);
    this.buildIsland(g, eC, pathSet, grass, lip, dirt, rockA, rockB, crack, moss, eNotch);
    this.buildEndRuins(g, eC, eB, eP, stone, pillar, rune, moss, dirt);
    this.islands.push(eC);
    this.idle.push({ group: g, phase: hash2(eC.x, eC.z) * 0.001 });
  }

  buildIsland(g, c, pathSet, grass, lip, dirt, rockA, rockB, crack, moss, skipSet) {
    const rng = mulberry32(hash2(c.x, c.z));
    const cells = [];
    for (let dx = -1; dx <= 1; dx++) {
      for (let dz = -1; dz <= 1; dz++) {
        const x = c.x + dx;
        const z = c.z + dz;
        if (pathSet.has(x + ',' + z)) continue;
        if (skipSet && skipSet.has(x + ',' + z)) continue;
        cells.push({ x, z, dx, dz });
      }
    }

    // exact gameplay grid: grass cubes on top, same positions as before
    cells.forEach(cell => {
      this.box(g, grass, cell.x, 0.45, cell.z, 1, 1, 1, false);
      this.box(g, lip, cell.x, 0.22, cell.z, 1.26, 0.18, 1.26, false);
      this.box(g, dirt, cell.x, -0.62, cell.z, 1.42, 0.42, 1.42, true);
    });

    // tapered rock body: shorted slabs with 2-6% jitter + unique silhouette
    const half = [1.1, 0.9, 0.72, 0.52, 0.34];
    const thk = [0.95, 0.8, 0.68, 0.56, 0.46];
    for (let k = 0; k < 5; k++) {
      const w = (half[k] * 2) * (1 + (rng() - 0.5) * 0.06);
      const t = thk[k] * (1 + (rng() - 0.5) * 0.12);
      const dx = (rng() - 0.5) * half[k] * 0.12;
      const dz = (rng() - 0.5) * half[k] * 0.12;
      const y = -1.45 - k * 0.82;
      const rock = k % 2 === 0 ? rockA : rockB;
      this.box(g, rock, c.x + dx, y, c.z + dz, w, t, w);
    }
    // rounded stub bottom tip (no long spike)
    this.blob(g, rockA, c.x, -4.7, c.z, 0.3, false);

    // small rock protrusions kept inside the island footprint
    for (let k = 0; k < 4; k++) {
      const a = rng() * Math.PI * 2;
      const r = 0.35 + rng() * 0.55;
      const px = c.x + Math.cos(a) * r;
      const pz = c.z + Math.sin(a) * r;
      this.blob(g, rockA, px, -2.1 - rng() * 1.5, pz, 0.14 + rng() * 0.16);
    }

    // cracks
    for (let k = 0; k < 4; k++) {
      const a = rng() * Math.PI * 2;
      const r = half[1 + (k % 4)] * 0.85;
      const px = c.x + Math.cos(a) * r;
      const pz = c.z + Math.sin(a) * r;
      const ck = this.box(g, crack, px, -1.6 - k * 1.1, pz, 0.12, 0.5, 0.12);
      ck.rotation.y = a;
    }

    // moss clumps
    for (let k = 0; k < 3; k++) {
      const a = rng() * Math.PI * 2;
      const r = half[1 + k] * 0.9;
      const px = c.x + Math.cos(a) * r;
      const pz = c.z + Math.sin(a) * r;
      this.blob(g, moss, px, -1.7 - rng() * 2.2, pz, 0.2 + rng() * 0.18, false);
    }

    // hanging roots from underside
    for (let k = 0; k < 3; k++) {
      const a = rng() * Math.PI * 2;
      const r = (0.25 + rng() * 0.5) * 1.2;
      const px = c.x + Math.cos(a) * r;
      const pz = c.z + Math.sin(a) * r;
      const rt = this.box(g, dirt, px, -1.1 - rng() * 0.6, pz, 0.07, 0.7 + rng() * 0.9, 0.07, false);
      rt.rotation.z = (rng() - 0.5) * 0.4;
      rt.rotation.x = (rng() - 0.5) * 0.4;
    }

    // edge decor on non-path ring cells: small stones, tuft moss
    const ring = cells.filter(cl => Math.abs(cl.dx) === 1 || Math.abs(cl.dz) === 1);
    ring.forEach((cl) => {
      const roll = rng();
      if (roll < 0.4) {
        this.blob(g, this.mat(0xcfd3dc, 0, 0, true), cl.x, 1.0, cl.z, 0.13 + rng() * 0.12);
        this.blob(g, moss, cl.x, 0.95, cl.z, 0.1 + rng() * 0.08, false);
      } else if (roll < 0.62) {
        this.blob(g, moss, cl.x, 0.7, cl.z, 0.14);
      }
    });
  }

  buildStartDecor(g, c, sB, sP, pathSet, trunk, leaf, leaf2, flowerA, flowerB, stone, moss) {
    // one low-poly tree on the back edge (opposite the path, never on path cells)
    const tx = c.x + sB.x * 1.0;
    const tz = c.z + sB.z * 1.0;
    if (!pathSet.has(tx + ',' + tz)) {
      this.box(g, trunk, tx, 1.4, tz, 0.5, 1.1, 0.5);
      this.blob(g, leaf, tx, 2.05, tz, 0.78);
      this.blob(g, leaf2, tx + 0.35, 2.65, tz + 0.2, 0.52);
      this.blob(g, leaf2, tx - 0.3, 2.55, tz - 0.3, 0.48);
    }

    // wooden sign on the side edge, board facing the path (skip path cells)
    const sx = c.x + sP.x * 1.0;
    const sz = c.z + sP.z * 1.0;
    const ang = Math.atan2(sB.x, sB.z);
    if (!pathSet.has(sx + ',' + sz)) {
      const post = this.box(g, trunk, sx, 0.95, sz, 0.12, 0.9, 0.12);
      post.rotation.y = ang;
      const board = this.box(g, trunk, sx, 1.45, sz, 0.62, 0.42, 0.1);
      board.rotation.y = ang;
    }

    // flowers, rocks and tufts on free cells
    for (let i = -1; i <= 1; i++) {
      for (let j = -1; j <= 1; j++) {
        if (i === 0 && j === 0) continue;
        const px = c.x + sB.x * i + sP.x * j;
        const pz = c.z + sB.z * i + sP.z * j;
        if (pathSet.has(px + ',' + pz)) continue;
        const rng = mulberry32(hash2(px, pz));
        const roll = rng();
        if (roll < 0.28) {
          this.box(g, roll < 0.13 ? flowerA : flowerB, px, 1.1, pz, 0.2, 0.4, 0.2);
          this.blob(g, moss, px, 1.03, pz, 0.1, false);
        } else if (roll < 0.4) {
          this.blob(g, stone, px, 1.0, pz, 0.16 + rng() * 0.12);
        } else if (roll < 0.48) {
          this.box(g, flowerA, px, 1.15, pz, 0.16, 0.45, 0.16);
        }
      }
    }
  }

  buildEndRuins(g, c, eB, eP, stone, pillar, rune, moss, dirt) {
    const rng = mulberry32(hash2(c.x, c.z));
    // platform pushed toward the back edge, away from the end path block (c - eB)
    const cx = c.x + eB.x * 0.35;
    const cz = c.z + eB.z * 0.35;
    // ancient circular stone platform (stays inside the island grid, off path cells)
    for (let k = 0; k < 7; k++) {
      const a = (k / 7) * Math.PI * 2 + rng() * 0.3;
      const px = cx + Math.cos(a) * 0.8;
      const pz = cz + Math.sin(a) * 0.8;
      this.blob(g, stone, px, 0.92, pz, 0.2 + rng() * 0.06);
      this.blob(g, moss, px + (rng() - 0.5) * 0.2, 0.9, pz + (rng() - 0.5) * 0.2, 0.08, false);
    }
    // engraved rune tile at the centre
    const runeTile = this.box(g, rune, cx, 0.85, cz, 0.42, 0.08, 0.42, false);
    runeTile.rotation.y = rng() * Math.PI;

    // broken stone pillars on the side cells of the island
    for (let k = 0; k < 2; k++) {
      const side = k === 0 ? 1 : -1;
      const ph = 0.7 + rng() * 0.8;
      const px = cx + eP.x * side * 0.9 + (rng() - 0.5) * 0.2;
      const pz = cz + eP.z * side * 0.9 + (rng() - 0.5) * 0.2;
      const pil = this.box(g, pillar, px, ph / 2 + 0.55, pz, 0.34, ph, 0.34);
      pil.rotation.x = (rng() - 0.5) * 0.25;
      pil.rotation.z = (rng() - 0.5) * 0.25;
      this.blob(g, stone, px, pil.position.y + ph / 2 + 0.1, pz, 0.16, false);
    }

    // small stone pile on the back corner of the island (never on path cells)
    for (let k = 0; k < 3; k++) {
      this.blob(g, stone, c.x + eB.x * 0.85 + eP.x * 0.4 + (rng() - 0.5) * 0.4, 0.85 + k * 0.18, c.z + eB.z * 0.85 + eP.z * 0.4 + (rng() - 0.5) * 0.4, 0.16 + k * 0.05);
    }
  }

  isOnIsland(x, z) {
    return this.islands.some(ic => Math.abs(x - ic.x) <= 1.5 && Math.abs(z - ic.z) <= 1.5);
  }

  update() {
    const t = performance.now() / 1000;
    if (this.idle.length) {
      this.idle.forEach(id => {
        id.group.position.y = Math.sin(t * 0.6 + id.phase) * 0.015;
      });
    }
  }

  clear() {
    if (this.group) {
      this.scene.remove(this.group);
      this.group = null;
    }
    this.startCenter = null;
    this.endCenter = null;
    this.islands = [];
    this.geos.forEach(g => g.dispose());
    this.geos = [];
    this.mats.forEach(m => m.dispose());
    this.mats = [];
    this.idle = [];
    this.makeGeos();
  }
}