const hash2 = (x, z) => {
  let h = (Math.imul(x, 73856093) ^ Math.imul(z, 19349663)) >>> 0;
  h = Math.imul(h ^ (h >>> 13), 0x7feb352d) >>> 0;
  return ((h ^ (h >>> 16)) >>> 0);
};
const mulberry32 = (seed) => {
  let t = seed >>> 0;
  return () => {
    t = (t + 0x6D2B79F5) | 0;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r = (r + Math.imul(r ^ (r >>> 7), 61 | r)) ^ r;
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
};

class Environment {
  constructor(scene) {
    this.scene = scene;
    this.clouds = [];
    this.leaves = [];
    this.butterflies = [];
    this.birds = [];
    this.drift = [];
    this.rng = mulberry32(123456789);
    this.buildSky();
    this.buildCloudLayers();
    this.buildDistantIslands();
    this.buildLeaves();
    this.buildButterflies();
    this.buildBirds();
  }

  buildSky() {
    const canvas = document.createElement('canvas');
    canvas.width = 2;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');
    const grd = ctx.createLinearGradient(0, 0, 0, 256);
    grd.addColorStop(0, '#6bb5dc');
    grd.addColorStop(0.42, '#a8ddf0');
    grd.addColorStop(0.72, '#ffdfa8');
    grd.addColorStop(1, '#dceef4');
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, 2, 256);
    const dome = new THREE.Mesh(
      new THREE.SphereGeometry(170, 20, 12),
      new THREE.MeshBasicMaterial({ map: new THREE.CanvasTexture(canvas), side: THREE.BackSide, fog: false, depthWrite: false })
    );
    this.scene.add(dome);
    this.setFog(0);
  }

  setFog(on) {
    if (on) {
      this.scene.fog = new THREE.Fog(0xbcd3e0, 42, 120);
    } else {
      this.scene.fog = null;
    }
  }

  buildCloudLayers() {
    // ponytail: layers sit above the camera orbit envelope (max cam height ~42.4 at 60 dist, 45 pitch)
    const layers = [
      { count: 7, y: 52, speed: 0.05, opacity: 0.4, scaleMin: 2.4, width: 3.4, wrap: 145 },
      { count: 5, y: 64, speed: 0.14, opacity: 0.6, scaleMin: 1.7, width: 2.4, wrap: 125 },
      { count: 3, y: 78, speed: 0.3, opacity: 0.85, scaleMin: 1.2, width: 1.8, wrap: 105 }
    ];
    const geoBox = new THREE.BoxGeometry(1, 1, 1);
    const geoBlob = new THREE.IcosahedronGeometry(0.5, 0);
    layers.forEach(L => {
      const mat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: L.opacity, depthWrite: false });
      for (let i = 0; i < L.count; i++) {
        const g = new THREE.Group();
        const n = 2 + Math.floor(this.rng() * 3);
        for (let j = 0; j < n; j++) {
          let b;
          if (j % 2 === 1) {
            b = new THREE.Mesh(geoBox, mat);
            const w = L.width * (0.8 + this.rng() * 0.9);
            b.scale.set(w, L.scaleMin / 2, L.width * (0.7 + this.rng() * 0.6));
            b.position.set((j - n / 2) * w * 0.7, (this.rng() - 0.5) * 0.5, (this.rng() - 0.5) * 1.4);
          } else {
            b = new THREE.Mesh(geoBlob, mat);
            const s = L.scaleMin * (1 + this.rng() * 1.2);
            b.scale.set(s, s * 0.5, s * 0.6);
            b.position.set((j - n / 2) * s * 1.4, (this.rng() - 0.5) * 0.5, (this.rng() - 0.5) * 1.2);
          }
          g.add(b);
        }
        const a = this.rng() * Math.PI * 2;
        const r = 30 + this.rng() * (L.wrap - 30);
        const x0 = Math.cos(a) * r;
        const z0 = Math.sin(a) * r;
        g.position.set(x0, L.y + (this.rng() - 0.5) * 7, z0);
        g.userData = { speed: L.speed, wrap: L.wrap, dir: this.rng() < 0.5 ? 1 : -1 };
        this.scene.add(g);
        this.clouds.push(g);
      }
    });
  }

  buildDistantIslands() {
    const colors = [0xc7e6e2, 0xd6d9ef, 0xf3dcc8, 0xc8d7ea];
    const geoBox = new THREE.BoxGeometry(1, 1, 1);
    for (let i = 0; i < 9; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: colors[i % 4], transparent: true, opacity: 0.12, depthWrite: false });
      const g = new THREE.Group();
      const s = 2.5 + this.rng() * 5;
      const la = 2 + Math.floor(this.rng() * 3);
      for (let j = 0; j < la; j++) {
        const w = s * (1 - j * 0.22);
        const b = new THREE.Mesh(geoBox, mat);
        b.scale.set(w, 0.5 + (la - j) * 0.4, w);
        b.position.set((this.rng() - 0.5) * w, 0.4 + j, (this.rng() - 0.5) * w);
        g.add(b);
      }
      const cone = new THREE.Mesh(new THREE.ConeGeometry(s * 0.4, s * 0.8, 5), mat);
      cone.position.y = la;
      g.add(cone);
      const a = this.rng() * Math.PI * 2;
      const r = 90 + this.rng() * 50;
      g.position.set(Math.cos(a) * r, 3 + this.rng() * 6, Math.sin(a) * r);
      g.userData = { speed: 0.02 + this.rng() * 0.04, wrap: 160, dir: this.rng() < 0.5 ? 1 : -1 };
      this.scene.add(g);
      this.drift.push(g);
    }
  }

  buildLeaves() {
    const geo = new THREE.BoxGeometry(0.09, 0.02, 0.11);
    const colors = [0xa8d882, 0xc9e6b0, 0x8fc27a];
    for (let i = 0; i < 16; i++) {
      const mat = new THREE.MeshBasicMaterial({ color: colors[i % 3], transparent: true, opacity: 0.85, depthWrite: false });
      const m = new THREE.Mesh(geo, mat);
      m.position.set((this.rng() - 0.5) * 46, 6 + this.rng() * 14, (this.rng() - 0.5) * 46);
      m.userData = { vy: 0.35 + this.rng() * 0.5, sway: 0.4 + this.rng() * 0.8, phase: this.rng() * 6, rot: this.rng() * 6 };
      this.scene.add(m);
      this.leaves.push(m);
    }
  }

  buildButterflies() {
    const wingGeoL = new THREE.ShapeGeometry(
      new THREE.Shape().moveTo(0, 0).lineTo(0.16, 0.12).lineTo(0.05, -0.08)
    );
    const mat = new THREE.MeshBasicMaterial({ color: 0xf0a7c8, side: THREE.DoubleSide, transparent: true, opacity: 0.9 });
    for (let i = 0; i < 4; i++) {
      const g = new THREE.Group();
      const w1 = new THREE.Mesh(wingGeoL, mat);
      const w2 = new THREE.Mesh(wingGeoL, mat);
      w2.rotation.y = Math.PI;
      g.add(w1, w2);
      g.position.set((this.rng() - 0.5) * 30, 4 + this.rng() * 3, (this.rng() - 0.5) * 30);
      g.userData = { phase: this.rng() * 6, cx: g.position.x, cz: g.position.z };
      this.scene.add(g);
      this.butterflies.push(g);
    }
  }

  buildBirds() {
    const mat = new THREE.MeshBasicMaterial({ color: 0x3a4a5a, side: THREE.DoubleSide });
    const wingGeo = new THREE.ShapeGeometry(
      new THREE.Shape().moveTo(0, 0).lineTo(-0.6, -0.35).lineTo(0.15, -0.1)
    );
    for (let i = 0; i < 3; i++) {
      const g = new THREE.Group();
      const w1 = new THREE.Mesh(wingGeo, mat);
      const w2 = new THREE.Mesh(wingGeo, mat);
      w2.rotation.y = Math.PI;
      g.add(w1);
      g.add(w2);
      const a = this.rng() * Math.PI * 2;
      g.position.set(Math.cos(a) * 15, 8 + this.rng() * 4, Math.sin(a) * 15);
      g.userData = { angle: a, radius: 12 + this.rng() * 10, speed: 0.15 + this.rng() * 0.15, yBase: g.position.y };
      this.scene.add(g);
      this.birds.push(g);
    }
  }

  update(dt) {
    const t = performance.now() / 1000;

    this.clouds.forEach(g => {
      g.position.x += g.userData.speed * g.userData.dir * dt;
      if (Math.abs(g.position.x) > g.userData.wrap) g.userData.dir *= -1;
    });

    this.drift.forEach(g => {
      g.position.x += g.userData.speed * g.userData.dir * dt;
      if (Math.abs(g.position.x) > g.userData.wrap) g.userData.dir *= -1;
    });

    this.leaves.forEach(leaf => {
      leaf.position.y -= leaf.userData.vy * dt;
      leaf.position.x += Math.sin(t * leaf.userData.sway + leaf.userData.phase) * dt * 0.6;
      leaf.position.z += Math.cos(t * leaf.userData.sway * 0.8 + leaf.userData.phase) * dt * 0.4;
      leaf.rotation.z += leaf.userData.rot * dt;
      if (leaf.position.y < -1.5) {
        leaf.position.y = 20;
        leaf.position.x = (this.rng() - 0.5) * 46;
        leaf.position.z = (this.rng() - 0.5) * 46;
      }
    });

    this.butterflies.forEach(b => {
      b.position.x = b.userData.cx + Math.sin(t * 0.7 + b.userData.phase) * 1.2;
      b.position.y = 5 + Math.sin(t * 1.4 + b.userData.phase * 2) * 0.6;
      b.position.z = b.userData.cz + Math.cos(t * 0.7 + b.userData.phase) * 1.2;
      b.children[0].rotation.z = Math.sin(t * 12 + b.userData.phase) * 0.6;
      b.children[1].rotation.z = -Math.sin(t * 12 + b.userData.phase) * 0.6;
    });

    this.birds.forEach((b, i) => {
      b.userData.angle += b.userData.speed * dt;
      b.position.x = Math.cos(b.userData.angle) * b.userData.radius;
      b.position.z = Math.sin(b.userData.angle) * b.userData.radius;
      b.position.y = b.userData.yBase + Math.sin(t * 2 + i) * 1.2;
    });
  }
}