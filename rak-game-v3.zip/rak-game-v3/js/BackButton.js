class BackButton {
  constructor() {
    this.armed = false;
    this.screens = ['level-select-screen', 'settings-screen', 'pause-popup', 'win-screen', 'gameover-screen'];
    this.onPop = this.onPop.bind(this);
    window.addEventListener('popstate', this.onPop);
    if (!this.isCoarse()) return;

    const overlay = document.getElementById('overlay');
    const container = document.getElementById('game-container');
    if (overlay || container) {
      const obs = new MutationObserver(() => this.refresh());
      if (overlay) obs.observe(overlay, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
      if (container) obs.observe(container, { attributes: true, attributeFilter: ['class'] });
    }
    this.refresh();
  }

  isCoarse() {
    return (navigator.maxTouchPoints || 0) > 0 || /Android|webOS|iPhone|iPad|iPod|Mobile|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  }

  isDeep() {
    if (window.gm && (window.gm.state === 'showing' || window.gm.state === 'playing')) return true;
    return this.screens.some((id) => {
      const el = document.getElementById(id);
      return el && !el.classList.contains('hidden');
    });
  }

  refresh() {
    if (this.isDeep()) this.arm();
  }

  arm() {
    if (this.armed) return;
    this.armed = true;
    history.pushState({}, '');
  }

  onPop() {
    if (!this.armed) return;
    if (this.doBack()) {
      history.pushState({}, '');
    } else {
      this.armed = false;
    }
  }

  doBack() {
    const gm = window.gm;
    if (!gm) return false;
    const vis = (id) => {
      const el = document.getElementById(id);
      return el && !el.classList.contains('hidden');
    };
    if (vis('settings-screen')) { gm.hideSettings(); return true; }
    if (vis('level-select-screen')) { gm.hideLevelSelect(); return true; }
    if (vis('pause-popup')) { gm.resumeFromPause(); return true; }
    if (vis('gameover-screen')) { gm.backToMenu(); return true; }
    if (vis('win-screen')) { gm.backToMenu(); return true; }
    if (gm.state === 'showing' || gm.state === 'playing') { gm.togglePause(); return true; }
    return false;
  }
}
