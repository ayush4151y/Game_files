class GameAudio {
  constructor() {
    this.ctx = null;
    this.master = null;
    this.groups = {};
    this.buffers = new Map();
    this.loopSources = new Map();
    this.unlocked = false;
    this.muted = localStorage.getItem('rak_muted') === '1';
    this.cooling = {};
    this.SOUNDS = [
      ['ambience', 'assets/audio/ambience/ambience-melody-loop.mp3?v=4'],
      ['ambience-island', 'assets/audio/ambience/ambience-island-loop.mp3?v=3'],
      ['ui-click', 'assets/audio/ui/ui-click.mp3?v=3'],
      ['ui-back', 'assets/audio/ui/ui-back.mp3?v=2'],
      ['ui-pause', 'assets/audio/ui/ui-pause.mp3?v=2'],
      ['ui-toggle', 'assets/audio/ui/ui-toggle.mp3?v=2'],
      ['cube-rise', 'assets/audio/sfx/cube-rise.mp3'],
      ['heart-pickup', 'assets/audio/sfx/heart-pickup.mp3?v=2'],
      ['hint', 'assets/audio/sfx/hint.mp3?v=2'],
      ['win', 'assets/audio/sfx/win.mp3'],
      ['gameover', 'assets/audio/sfx/gameover.mp3?v=2'],
      ['camera-rotate', 'assets/audio/sfx/camera-rotate.mp3'],
      ['ice-slide', 'assets/audio/sfx/ice-slide.mp3'],
      ['fire-warn', 'assets/audio/sfx/fire-warn.mp3'],
      ['tnt-fuse', 'assets/audio/sfx/tnt-fuse.mp3?v=2'],
      ['tnt-boom', 'assets/audio/sfx/tnt-boom.mp3?v=3']
    ];
  }

  init() {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = this.muted ? 0 : 1;
    this.master.connect(this.ctx.destination);
    ['ui', 'sfx', 'ambience'].forEach((g) => {
      const gain = this.ctx.createGain();
      gain.gain.value = 1;
      gain.connect(this.master);
      this.groups[g] = gain;
    });
    this.groups.ui.gain.value = this.getVolume('sfx');
    this.groups.sfx.gain.value = this.getVolume('sfx');
    this.groups.ambience.gain.value = this.getVolume('music');
  }

  getVolume(type) {
    return parseFloat(localStorage.getItem(type === 'music' ? 'rak_vol_music' : 'rak_vol_sfx')) || 1;
  }

  setVolume(type, v) {
    v = Math.max(0, Math.min(1, v));
    localStorage.setItem(type === 'music' ? 'rak_vol_music' : 'rak_vol_sfx', String(v));
    if (!this.ctx) return;
    if (type === 'music') {
      this.groups.ambience.gain.value = v;
    } else {
      this.groups.ui.gain.value = v;
      this.groups.sfx.gain.value = v;
    }
  }

  async unlock() {
    try {
      this.init();
      if (!this.ctx) return false;
      if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
      this.unlocked = true;
      await this.loadAll();
      return true;
    } catch (e) {
      console.error('audio init failed', e);
      return false;
    }
  }

  async loadAll() {
    for (const [id, url] of this.SOUNDS) {
      if (this.buffers.has(id)) continue;
      try {
        const res = await fetch(url);
        if (!res.ok) continue;
        const data = await res.arrayBuffer();
        this.buffers.set(id, await this.ctx.decodeAudioData(data));
        if (id === 'ambience' && this.ambienceRequested) this.startLoop('ambience');
        if (id === 'ambience-island' && this.islandRequested) this.startLoop('ambience-island');
      } catch (e) { /* skip unloadable asset */ }
    }
  }

  play(id, group = 'sfx', volume = 1, cooldown = 0) {
    if (!this.ctx || !this.buffers.has(id)) return;
    if (cooldown > 0) {
      const now = performance.now();
      const last = this.cooling[id] || 0;
      if (now - last < cooldown) return;
      this.cooling[id] = now;
    }
    const src = this.ctx.createBufferSource();
    src.buffer = this.buffers.get(id);
    const g = this.ctx.createGain();
    g.gain.value = volume;
    src.connect(g).connect(this.groups[group] || this.master);
    src.start();
  }

  startLoop(id, volume = 0.45) {
    if (!this.ctx || !this.buffers.has(id)) return;
    if (this.loopSources.has(id)) return;
    const src = this.ctx.createBufferSource();
    src.buffer = this.buffers.get(id);
    src.loop = true;
    const g = this.ctx.createGain();
    g.gain.value = volume;
    src.connect(g).connect(this.groups.ambience || this.master);
    src.start();
    this.loopSources.set(id, src);
  }

  stopLoop(id) {
    const src = this.loopSources.get(id);
    if (src) {
      try { src.stop(); } catch (e) { /* already stopped */ }
      this.loopSources.delete(id);
    }
  }

  startAmbience() {
    this.ambienceRequested = true;
    this.startLoop('ambience', 1.0);
  }

  startIslandAmbience() {
    this.islandRequested = true;
    this.startLoop('ambience-island', 0.9);
  }

  pause() {
    if (this.ctx && this.ctx.state === 'running') this.ctx.suspend();
  }

  resume() {
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
  }

  setMuted(m) {
    this.muted = m;
    localStorage.setItem('rak_muted', m ? '1' : '0');
    if (this.master) this.master.gain.value = m ? 0 : 1;
  }

  toggleMute() {
    this.setMuted(!this.muted);
    return this.muted;
  }

  isMuted() {
    return this.muted;
  }
}
