class Tutorial {
  constructor() {
    this.overlay = document.getElementById('tutorial-overlay');
    this.text = document.getElementById('tut-text');
    this.skipBtn = document.getElementById('tut-skip');
    this.running = false;
    if (this.skipBtn) this.skipBtn.addEventListener('click', () => this.stop(true));
  }

  static getFixedPath() {
    const dirs = [
      { x: 0, z: -1 }, { x: -1, z: 0 }, { x: 0, z: 1 }, { x: 0, z: 1 },
      { x: 1, z: 0 }, { x: 0, z: 1 }, { x: -1, z: 0 }, { x: -1, z: 0 },
      { x: 0, z: -1 }
    ];
    const path = [{ x: 0, z: 0 }];
    let x = 0, z = 0;
    for (const d of dirs) {
      x += d.x; z += d.z;
      path.push({ x, z });
    }
    return path;
  }

  start() {
    if (this.running) return;
    this.running = true;
    window.activeTutorial = this;
    if (this.overlay) this.overlay.classList.remove('hidden');
    this.showStep(0);
  }

  update() {
    if (!this.running || !window.gm) return;
    this.showStep(window.gm.currentPathIndex);
  }

  showStep(idx) {
    const defs = [
      { text: 'MOVE — UP', keys: ['btn-up'] },
      { text: 'MOVE — LEFT', keys: ['btn-left'] },
      { text: 'MOVE — DOWN', keys: ['btn-down'] },
      { text: 'MOVE — DOWN', keys: ['btn-down'] },
      { text: 'MOVE — RIGHT', keys: ['btn-right'] },
      { text: 'CUBES RISE — behind you! MOVE — DOWN', keys: ['btn-down'] },
      { text: 'STUCK? TAP HINT OR ROTATE VIEW — MOVE — LEFT', keys: ['hint-btn', 'rotate-right-btn', 'btn-left'] },
      { text: "DON'T STEP OFF THE PATH — MOVE — LEFT", keys: ['btn-left'] },
      { text: 'REACH THE GOAL!' }
    ];
    const def = defs[idx] || defs[defs.length - 1];
    if (this.text) this.text.textContent = def.text;
    document.querySelectorAll('.tut-highlight').forEach(el => el.classList.remove('tut-highlight'));
    (def.keys || []).forEach(id => {
      const el = document.getElementById(id);
      if (el) el.classList.add('tut-highlight');
    });
  }

  stop(skipped) {
    if (!this.running && !skipped) return;
    this.running = false;
    window.activeTutorial = null;
    if (this.overlay) this.overlay.classList.add('hidden');
    document.querySelectorAll('.tut-highlight').forEach(el => el.classList.remove('tut-highlight'));
    if (skipped) {
      localStorage.setItem('rak_tutorial', '1');
      if (window.gm) window.gm.backToMenu();
    }
  }
}
