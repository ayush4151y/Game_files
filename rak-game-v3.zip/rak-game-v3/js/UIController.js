class UIController {
  constructor(gameManager) {
    this.gm = gameManager;
    this.moveLocked = false;
    this.setupButtons();
    this.setupKeyboard();
    this.setupSwipe();
  }

  setupButtons() {
    document.getElementById('start-btn').addEventListener('click', () => {
      this.gm.startGame();
    });

    document.getElementById('endless-btn').addEventListener('click', () => {
      this.gm.startEndless();
    });

    document.getElementById('daily-btn').addEventListener('click', () => {
      this.gm.startDaily();
    });

    document.getElementById('menu-settings-btn').addEventListener('click', () => {
      this.gm.showSettings();
    });

    document.getElementById('settings-back-btn').addEventListener('click', () => {
      this.gm.hideSettings();
    });

    document.getElementById('reset-progress-btn').addEventListener('click', () => {
      this.gm.resetProgress();
    });

    document.getElementById('input-dpad').addEventListener('click', () => {
      this.gm.setInputMode('dpad');
    });

    document.getElementById('input-swipe').addEventListener('click', () => {
      this.gm.setInputMode('swipe');
    });

    document.getElementById('sound-toggle-btn').addEventListener('click', () => {
      const muted = window.gameAudio ? window.gameAudio.toggleMute() : false;
      document.getElementById('sound-toggle-btn').textContent = 'SOUND: ' + (muted ? 'OFF' : 'ON');
    });

    const tutorialBtn = document.getElementById('tutorial-btn');
    if (tutorialBtn) {
      tutorialBtn.addEventListener('click', () => {
        if (window.gameAudio) window.gameAudio.play('ui-click', 'ui', 1);
        window.launchTutorial();
      });
    }

    this.setupGameButtons();
  }

  initVolumeSliders() {
    const initSlider = (id, type) => {
      const el = document.getElementById(id);
      if (!el || !window.gameAudio) return;
      el.value = Math.round(window.gameAudio.getVolume(type) * 100);
      el.addEventListener('input', () => {
        window.gameAudio.setVolume(type, el.value / 100);
      });
    };
    initSlider('music-vol', 'music');
    initSlider('sfx-vol', 'sfx');
  }

  setupGameButtons() {
    document.getElementById('ls-back-btn').addEventListener('click', () => {
      this.gm.hideLevelSelect();
    });

    document.getElementById('restart-btn').addEventListener('click', () => {
      this.gm.restart();
    });

    document.getElementById('next-btn').addEventListener('click', () => {
      if (this.gm.mode === 'daily' || this.gm.isTutorial) {
        this.gm.backToMenu();
      } else {
        this.gm.nextLevel();
      }
    });

    document.getElementById('pause-btn').addEventListener('click', () => {
      this.gm.togglePause();
    });

    document.getElementById('pause-home-btn').addEventListener('click', () => {
      this.gm.goHomeFromPause();
    });

    document.getElementById('pause-stay-btn').addEventListener('click', () => {
      this.gm.resumeFromPause();
    });

    document.getElementById('skip-btn').addEventListener('click', () => {
      this.gm.skipShow();
    });

    document.getElementById('hint-btn').addEventListener('click', () => {
      this.gm.hintMove();
    });

    document.getElementById('tap-start-overlay').addEventListener('click', () => {
      this.gm.tapToStart();
    });

    document.getElementById('rotate-right-btn').addEventListener('pointerdown', (e) => {
      e.preventDefault();
      this.gm.rotateView(90);
    });

    const btnMap = {
      'btn-up': 'up',
      'btn-down': 'down',
      'btn-left': 'left',
      'btn-right': 'right'
    };

    Object.entries(btnMap).forEach(([id, dir]) => {
      const btn = document.getElementById(id);

      const handleDir = (e) => {
        e.preventDefault();
        if (this.moveLocked) return;
        if (this.gm.getInputMode() !== 'dpad') return;
        this.moveLocked = true;
        this.gm.handleMove(dir);
        setTimeout(() => { this.moveLocked = false; }, 250);
      };

      btn.addEventListener('pointerdown', handleDir);
    });
  }

  setupKeyboard() {
    document.addEventListener('keydown', (e) => {
      const lsScreen = document.getElementById('level-select-screen');
      const settingsScreen = document.getElementById('settings-screen');
      const overlayActive = !lsScreen.classList.contains('hidden') || !settingsScreen.classList.contains('hidden');

      if (this.gm.state === 'menu') {
        if (e.key === 'Enter') {
          this.gm.startGame();
        }
        return;
      }

      if (overlayActive) return;

      if (this.gm.state === 'showing') {
        switch (e.key) {
          case 'Enter':
          case ' ':
            e.preventDefault();
            this.gm.tapToStart();
            break;
          case 's': case 'S':
            this.gm.skipShow();
            break;
          case 'Escape':
          case 'p': case 'P':
            this.gm.togglePause();
            break;
        }
      }

      if (this.gm.state === 'playing') {
        switch (e.key) {
          case 'ArrowUp': e.preventDefault(); this.gm.handleMove('up'); break;
          case 'ArrowDown': e.preventDefault(); this.gm.handleMove('down'); break;
          case 'ArrowLeft': e.preventDefault(); this.gm.handleMove('left'); break;
          case 'ArrowRight': e.preventDefault(); this.gm.handleMove('right'); break;
          case 's': case 'S':
            this.gm.skipShow();
            break;
          case 'Escape':
          case 'p': case 'P':
            this.gm.togglePause();
            break;
          case 'h': case 'H':
            this.gm.hintMove();
            break;
        }
      }
    });
  }

  setupSwipe() {
    let startX = 0, startY = 0;
    const minDist = 30;

    document.addEventListener('touchstart', (e) => {
      startX = 0;
      startY = 0;
      if (this.gm.state !== 'playing') return;
      if (this.gm.getInputMode() !== 'swipe') return;
      startX = e.touches[0].clientX;
      startY = e.touches[0].clientY;
    }, { passive: true });

    document.addEventListener('touchend', (e) => {
      if (this.gm.state !== 'playing' || startX === 0) return;
      if (this.gm.getInputMode() !== 'swipe') return;
      const dx = e.changedTouches[0].clientX - startX;
      const dy = e.changedTouches[0].clientY - startY;
      const absDx = Math.abs(dx);
      const absDy = Math.abs(dy);

      if (Math.max(absDx, absDy) < minDist) { startX = 0; startY = 0; return; }

      if (absDx > absDy) {
        this.gm.handleMove(dx > 0 ? 'right' : 'left');
      } else {
        this.gm.handleMove(dy > 0 ? 'down' : 'up');
      }

      startX = 0;
      startY = 0;
    }, { passive: true });
  }
}
