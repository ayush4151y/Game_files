const CAMERA_CONFIG = {
  minDistance: 7,
  maxDistance: 120,
  padding: 1.2,
  animationDuration: 600,
  pitch: 45,
  yaw: 0,
  screenFillPercent: 0.9
};

const easeInOutCubic = t => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;

class GameManager {
  constructor(scene, camera) {
    this.scene = scene;
    this.camera = camera;
    this.pathGen = new PathGenerator();
    this.blocks = new BlockManager();
    this.cubeGrid = new CubeGrid(scene);
    this.islandBuilder = new IslandBuilder(scene, this.cubeGrid);
    this.environment = new Environment(scene);
    this.player = new Player(scene);

    this.state = 'menu';
    this.paused = false;
    this.camYaw = 0;
    this.mode = 'campaign';
    this.currentLevel = 1;
    this.path = null;
    this.currentPathIndex = 0;
    this.skipBusy = false;
    this.isTutorial = false;
    this.tntBackDirection = null;
    this.activeTNT = null;
    this.slideFalling = false;
    this.GRID_SIZE = 15;
    this.TOTAL_LEVELS = 200;
    this.sequenceId = 0;
    this.stuckTimer = null;
    this.camRight = { x: 1, z: 0 };
    this.camUp = { x: 0, z: -1 };
    this.cameraAnimSeq = 0;
    this.runStreak = 0;
    this.runSeed = 1;
    this.segmentStartIndex = 0;
    this.showStartIndex = 0;
  }

  getCompletedLevels() {
    try {
      const data = localStorage.getItem('rak_completed' + this.getModeSuffix());
      return data ? JSON.parse(data) : [];
    } catch { return []; }
  }

  saveCompletedLevels(levels) {
    localStorage.setItem('rak_completed' + this.getModeSuffix(), JSON.stringify(levels));
  }

  markLevelComplete(level) {
    const completed = this.getCompletedLevels();
    if (!completed.includes(level)) {
      completed.push(level);
      this.saveCompletedLevels(completed);
    }
  }

  getCurrentLevel() {
    const saved = localStorage.getItem('rak_level' + this.getModeSuffix());
    return saved ? parseInt(saved) || 1 : 1;
  }

  saveCurrentLevel(level) {
    localStorage.setItem('rak_level' + this.getModeSuffix(), level.toString());
  }

  getSkippedLevels() {
    try {
      const data = localStorage.getItem('rak_skipped' + this.getModeSuffix());
      return data ? JSON.parse(data) : [];
    } catch { return []; }
  }

  saveSkippedLevels(levels) {
    localStorage.setItem('rak_skipped' + this.getModeSuffix(), JSON.stringify(levels));
  }

  markLevelSkipped(level) {
    const skipped = this.getSkippedLevels();
    if (!skipped.includes(level)) {
      skipped.push(level);
      this.saveSkippedLevels(skipped);
    }
  }

  getModeSuffix() {
    return '';
  }

  getMode() {
    return localStorage.getItem('rak_mode') || 'campaign';
  }

  setMode(mode) {
    this.mode = mode;
    localStorage.setItem('rak_mode', mode);
  }

  hideAllScreens() {
    ['menu-screen', 'level-select-screen', 'settings-screen', 'win-screen', 'gameover-screen', 'pause-popup'].forEach(id => {
      const el = document.getElementById(id);
      if (el) el.classList.add('hidden');
    });
  }

  todayKey() {
    const d = new Date();
    return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
  }

  isDailyDone() {
    return parseInt(localStorage.getItem('rak_daily_last')) === this.todayKey();
  }

  getDailyStreak() {
    return parseInt(localStorage.getItem('rak_daily_streak')) || 0;
  }

  markDailyComplete() {
    const today = this.todayKey();
    if (parseInt(localStorage.getItem('rak_daily_last')) === today) return;
    const last = parseInt(localStorage.getItem('rak_daily_last'));
    const streak = last === today - 1 ? this.getDailyStreak() + 1 : 1;
    localStorage.setItem('rak_daily_streak', String(streak));
    localStorage.setItem('rak_daily_last', String(today));
  }

  showLevelSelect() {
    this._sfx('ui-click', 'ui', 1);
    this.state = 'menu';
    this.paused = false;
    this.cubeGrid.paused = false;
    document.getElementById('menu-screen').classList.add('hidden');
    document.getElementById('level-select-screen').classList.remove('hidden');
    document.getElementById('controls').classList.add('hidden');
    document.getElementById('skip-btn').classList.add('hidden');
    document.getElementById('pause-btn').classList.add('hidden');
    document.getElementById('pause-popup').classList.add('hidden');
    document.getElementById('game-container').classList.add('level-select-active');
    document.getElementById('game-container').classList.remove('game-active');
    this.updatePhaseText('');
    const subtitle = document.getElementById('ls-mode-subtitle');
    if (subtitle) subtitle.textContent = 'CAMPAIGN';
    this.buildLevelGrid();
  }

  hideLevelSelect() {
    this._sfx('ui-back', 'ui', 1);
    document.getElementById('level-select-screen').classList.add('hidden');
    document.getElementById('menu-screen').classList.remove('hidden');
    document.getElementById('game-container').classList.remove('level-select-active');
  }

  buildLevelGrid() {
    const grid = document.getElementById('level-grid');
    grid.innerHTML = '';
    const completed = this.getCompletedLevels();
    const skipped = this.getSkippedLevels();
    const current = this.getCurrentLevel();

    for (let i = 1; i <= this.TOTAL_LEVELS; i++) {
      const cell = document.createElement('div');
      cell.className = 'lvl-cell';
      cell.dataset.level = i;

      const num = document.createElement('div');
      num.className = 'lvl-number';
      num.textContent = i;

      const status = document.createElement('div');
      status.className = 'lvl-status';

      if (completed.includes(i)) {
        cell.classList.add('complete');
        status.textContent = 'Complete';
      } else if (skipped.includes(i)) {
        cell.classList.add('skipped');
        status.textContent = 'Skipped';
      } else if (i === current) {
        cell.classList.add('current');
        status.textContent = 'Current';
      } else if (i < current) {
        cell.classList.add('available');
        status.textContent = 'Play';
      } else {
        cell.classList.add('locked');
        const lockSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        lockSvg.setAttribute('viewBox', '0 0 24 24');
        lockSvg.setAttribute('class', 'lvl-lock-icon');
        lockSvg.innerHTML = '<path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1s3.1 1.39 3.1 3.1v2z" fill="currentColor"/>';
        cell.appendChild(num);
        cell.appendChild(lockSvg);
        cell.addEventListener('click', () => {});
        grid.appendChild(cell);
        continue;
      }

      cell.appendChild(num);
      cell.appendChild(status);
      cell.addEventListener('click', () => this.startLevel(i));
      grid.appendChild(cell);
    }
  }

  startLevel(level) {
    this._sfx('ui-click', 'ui', 1);
    this.setMode('campaign');
    this.cleanup();
    this.sequenceId++;
    this.currentLevel = level;
    document.getElementById('level-select-screen').classList.add('hidden');
    document.getElementById('game-container').classList.remove('level-select-active');
    this.loadLevel();
  }

  startGame() {
    this._sfx('ui-click', 'ui', 1);
    this.setMode('campaign');
    this.currentLevel = this.getCurrentLevel();
    this.showLevelSelect();
  }

  startEndless() {
    this._sfx('ui-click', 'ui', 1);
    this.setMode('endless');
    this.hideAllScreens();
    this.cleanup();
    this.runStreak = 0;
    this.runSeed = (Date.now() & 0x7fffffff) || 1;
    this.startEndlessSegment();
  }

  startDaily() {
    this._sfx('ui-click', 'ui', 1);
    this.setMode('daily');
    this.hideAllScreens();
    this.cleanup();
    if (this.isDailyDone()) {
      this.showDailyDone();
      return;
    }
    this.startDailyLevel();
  }

  showDailyDone() {
    this._sfx('ui-click', 'ui', 1);
    this.state = 'menu';
    const title = document.getElementById('go-title');
    if (title) title.textContent = 'DAILY COMPLETE!';
    const subtitle = document.getElementById('go-subtitle');
    if (subtitle) subtitle.textContent = 'Come back tomorrow for a new challenge!';
    document.getElementById('final-level').textContent = 'Streak: ' + this.getDailyStreak() + ' days';
    document.getElementById('restart-btn').classList.remove('hidden');
    document.getElementById('restart-btn').textContent = 'MENU';
    document.getElementById('gameover-screen').classList.remove('hidden');
  }

  startDailyLevel() {
    const pathLength = 25;
    const seed = this.todayKey() * 7919 + 7;
    const minTurns = Math.max(1, Math.floor(pathLength / 3));
    this.setupLevel({ level: 200, seed, pathLength, turnBias: 0.8, minTurns, noHearts: true, canSkip: false, phaseText: 'Daily Challenge!' });
  }

  setupLevel(opts) {
    this.cleanup();
    this.sequenceId++;
    this.isTutorial = opts.tutorial === true;
    const pathLength = opts.pathLength !== undefined ? opts.pathLength : this.getPathLength(opts.level);
    const seed = opts.seed !== undefined ? opts.seed : opts.level * 9973 + 42;
    const turnBias = opts.turnBias !== undefined ? opts.turnBias : this.getTurnBias(opts.level);
    const minTurns = opts.minTurns !== undefined ? opts.minTurns : Math.max(1, Math.floor(pathLength / 3));

    if (this.isTutorial) {
      this.path = Tutorial.getFixedPath();
    } else {
      this.path = this.pathGen.generate(pathLength, seed, turnBias, minTurns);
    }
    this.offsetPathToCenter();
    this.blocks.assign(this.path, seed, opts.level, 0, opts.noHearts ? { noHearts: true } : {});
    this.islandBuilder.build(this.path);
    this.cubeGrid.buildFromPath(this.path, this.blocks);
    this.adjustCameraToPath();
    this.segmentStartIndex = 0;
    this.showStartIndex = 0;

    const startPos = this.path[0];
    this.player.create(startPos);
    this.player.isMoving = false;
    this.currentPathIndex = 0;

    this.health = 3;
    this.midpointRewarded = false;
    if (opts.hideHearts) {
      this.hideHearts();
    } else {
      this.renderHearts();
      this.showHearts();
    }

    this.state = 'showing';
    this.updatePhaseText(opts.phaseText || 'Watch!');
    if (opts.canSkip === false) {
      document.getElementById('skip-btn').classList.add('hidden');
    } else {
      document.getElementById('skip-btn').classList.remove('hidden');
    }
    document.getElementById('controls').classList.add('hidden');
    document.getElementById('pause-btn').classList.remove('hidden');
    document.getElementById('game-container').classList.add('game-active');
    document.getElementById('info-bar').classList.remove('hidden');
    this.updateHUD();

    this.startShowSequence();
  }

  loadLevel() {
    this.setupLevel({ level: this.currentLevel });
  }

  getPathLength(level) {
    const ranges = [
      { min: 1, max: 20, lenMin: 5, lenMax: 8 },
      { min: 21, max: 50, lenMin: 8, lenMax: 13 },
      { min: 51, max: 100, lenMin: 9, lenMax: 18 },
      { min: 101, max: 150, lenMin: 15, lenMax: 22 },
      { min: 151, max: 200, lenMin: 19, lenMax: 25 }
    ];
    const r = ranges.find(r => level <= r.max) || ranges[ranges.length - 1];
    const t = Math.min((level - r.min) / (r.max - r.min), 1);
    return Math.round(r.lenMin + (r.lenMax - r.lenMin) * t);
  }

  getTurnBias(level) {
    return 0.4 + Math.min((level - 1) / 199, 1) * 0.4;
  }

  offsetPathToCenter() {
    let minX = Infinity, minZ = Infinity;
    let maxX = -Infinity, maxZ = -Infinity;

    this.path.forEach(p => {
      if (p.x < minX) minX = p.x;
      if (p.x > maxX) maxX = p.x;
      if (p.z < minZ) minZ = p.z;
      if (p.z > maxZ) maxZ = p.z;
    });

    const centerX = (minX + maxX) / 2;
    const centerZ = (minZ + maxZ) / 2;

    this.path.forEach(p => {
      p.x -= centerX;
      p.z -= centerZ;
    });
  }
  adjustCameraToPath(rangeStart = 0, rangeEnd = null) {
    const C = CAMERA_CONFIG;
    let minX = Infinity, minZ = Infinity, maxX = -Infinity, maxZ = -Infinity;
    const end = rangeEnd == null ? this.path.length - 1 : rangeEnd;

    for (let i = rangeStart; i <= end; i++) {
      const p = this.path[i];
      if (p.x < minX) minX = p.x;
      if (p.x > maxX) maxX = p.x;
      if (p.z < minZ) minZ = p.z;
      if (p.z > maxZ) maxZ = p.z;
    }

    const cx = (minX + maxX) / 2;
    const cz = (minZ + maxZ) / 2;
    const vfov = this.camera.fov * Math.PI / 180;
    const hfov = 2 * Math.atan(Math.tan(vfov / 2) * Math.max(this.camera.aspect, 0.3));
    const theta = C.pitch * Math.PI / 180;
    const yawRad = this.camYaw * Math.PI / 180;
    const s = Math.sin(theta), c = Math.cos(theta);
    const sinYaw = Math.sin(yawRad), cosYaw = Math.cos(yawRad);
    const tanV = Math.tan(vfov / 2);
    const tanH = Math.tan(hfov / 2);
    const targetNdc = C.screenFillPercent * 0.98;
    const topY = 2.4;
    const EXT = 2.0;
    const xs = [minX - EXT, maxX + EXT], zs = [minZ - EXT, maxZ + EXT];

    const fitNdc = (D) => {
      const G = D * c, Hgt = D * s;
      const cam = { x: cx + sinYaw * G, y: Hgt, z: cz + cosYaw * G };
      // yaw-aware unit view basis (identical to old math at yaw=0)
      const fx = -sinYaw * c, fy = -s, fz = -cosYaw * c;
      const rx = cosYaw, rz = -sinYaw;
      const ux = -s * sinYaw, uy = c, uz = -s * cosYaw;
      let maxN = 0;
      for (let xi = 0; xi < 2; xi++) {
        for (let zi = 0; zi < 2; zi++) {
          for (let yi = 0; yi < 2; yi++) {
            const wx = xs[xi], wz = zs[zi], wy = yi === 0 ? 0 : topY;
            const vx = wx - cam.x, vy = wy - cam.y, vz = wz - cam.z;
            const depth = vx * fx + vy * fy + vz * fz;
            if (depth <= 0.001) return 1e9;
            const unx = Math.abs((vx * rx + vz * rz) / (depth * tanH));
            const uny = Math.abs((vx * ux + vy * uy + vz * uz) / (depth * tanV));
            const m = Math.max(unx, uny);
            if (m > maxN) maxN = m;
          }
        }
      }
      return maxN;
    };

    let lo = C.minDistance, hi = Math.max(C.maxDistance * 1.8, 80);
    for (let i = 0; i < 40; i++) {
      const mid = (lo + hi) / 2;
      if (fitNdc(mid) <= targetNdc) hi = mid;
      else lo = mid;
    }
    let vd = hi;
    if (fitNdc(C.minDistance) <= targetNdc) vd = C.minDistance;
    vd = Math.min(Math.max(vd, C.minDistance), C.maxDistance);
    this.camDistance = vd;
    this.cameraFrame = { minX, maxX, minZ, maxZ };
    this.frameCameraAt(vd, cx, cz, rangeStart, end);
  }

  frameCameraAt(vd, cx, cz, rangeStart, end) {
    const C = CAMERA_CONFIG;
    const theta = C.pitch * Math.PI / 180;
    const yawRad = this.camYaw * Math.PI / 180;
    const s = Math.sin(theta), c = Math.cos(theta);
    const sinYaw = Math.sin(yawRad), cosYaw = Math.cos(yawRad);
    const G = vd * c;
    const H = vd * s;
    const tx = cx + sinYaw * G;
    const tz = cz + cosYaw * G;

    this.camRight = { x: cosYaw, z: -sinYaw };
    this.camUp = { x: -sinYaw, z: -cosYaw };
    this.cameraTarget = { x: tx, y: H, z: tz };
    this.camSegmentStart = rangeStart;
    this.camSegmentEnd = end;

    const seq = ++this.cameraAnimSeq;
    const cp = this.camera.position;
    const from = { x: cp.x || 0, y: cp.y || 0, z: cp.z || 0 };
    AnimTween.animate(null, (unused, t) => {
      if (seq !== this.cameraAnimSeq) return;
      const e = easeInOutCubic(t);
      this.camera.position.set(
        from.x + (tx - from.x) * e,
        from.y + (H - from.y) * e,
        from.z + (tz - from.z) * e
      );
      this.camera.lookAt(cx, 0, cz);
    }, 0, 1, C.animationDuration, null);
  }

  handleResize() {
    if (this.path && this.path.length) {
      this.adjustCameraToPath(this.camSegmentStart || 0, this.camSegmentEnd);
    }
  }

  rotateView(delta = 90) {
    if (!this.path || !this.path.length) return;
    this._sfx('camera-rotate', 'sfx', 0.8);
    this.camYaw = ((this.camYaw + delta) % 360 + 360) % 360;
    const f = this.cameraFrame;
    if (!this.camDistance || !f) return;
    const cx = (f.minX + f.maxX) / 2;
    const cz = (f.minZ + f.maxZ) / 2;
    this.frameCameraAt(this.camDistance, cx, cz, this.camSegmentStart || 0, this.camSegmentEnd);
  }

  _sfx(id, group = 'sfx', volume = 1, cooldown = 0) {
    if (window.gameAudio) window.gameAudio.play(id, group, volume, cooldown);
  }

  screenToWorld(direction) {
    let v;
    if (direction === 'up') v = this.camUp;
    else if (direction === 'down') v = { x: -this.camUp.x, z: -this.camUp.z };
    else if (direction === 'right') v = this.camRight;
    else if (direction === 'left') v = { x: -this.camRight.x, z: -this.camRight.z };
    else return direction;
    if (v.z === -1) return 'up';
    if (v.z === 1) return 'down';
    if (v.x === 1) return 'right';
    return 'left';
  }

  async startShowSequence() {
    const seqId = ++this.sequenceId;
    await this.cubeGrid.showPathWave(null, this.showStartIndex);
    if (this.sequenceId !== seqId || this.state !== 'showing') return;

    this.cubeGrid.drawPathLine(this.path, this.segmentStartIndex);
    document.getElementById('tap-start-overlay').classList.remove('hidden');
  }

  async tapToStart() {
    if (this.state !== 'showing') return;
    this._sfx('ui-click', 'ui', 1);
    const seqId = this.sequenceId;
    document.getElementById('tap-start-overlay').classList.add('hidden');
    this.cubeGrid.removePathLine();
    await this.cubeGrid.hidePathWave(null, true, this.showStartIndex);
    if (this.sequenceId !== seqId || this.state !== 'showing' || this.paused) return;
    this.cubeGrid.startIdleAnimations();
    this.beginPlaying();
  }

  beginPlaying() {
    this.state = 'playing';
    if (this.environment) this.environment.setFog(1);
    this.updatePhaseText('Go!');
    document.getElementById('skip-btn').classList.add('hidden');
    document.getElementById('hint-btn').classList.remove('hidden');
    document.getElementById('rotate-right-btn').classList.remove('hidden');
    if (this.getInputMode() !== 'swipe') {
      document.getElementById('controls').classList.remove('hidden');
    }
    this.startStuckTimer();
  }

  startStuckTimer() {
    this.clearStuckTimer();
    this.stuckTimer = setTimeout(() => {
      this.activateHintGlow();
    }, 3000);
  }

  activateHintGlow() {
    const btn = document.getElementById('hint-btn');
    if (!btn) return;
    btn.classList.add('glow');
    const svg = btn.querySelector('svg');
    if (svg) svg.setAttribute('stroke', '#ffd54f');
  }

  clearStuckTimer() {
    if (this.stuckTimer) {
      clearTimeout(this.stuckTimer);
      this.stuckTimer = null;
    }
    const btn = document.getElementById('hint-btn');
    if (!btn) return;
    btn.classList.remove('glow');
    const svg = btn.querySelector('svg');
    if (svg) svg.setAttribute('stroke', '#888');
  }

  hintMove() {
    if (this.state !== 'playing') return;
    if (this.paused) return;
    if (this.player.isMoving) return;
    if (this.blocks.fuseActive || this.blocks.isSlideActive()) return;
    const lsScreen = document.getElementById('level-select-screen');
    const settingsScreen = document.getElementById('settings-screen');
    if (!lsScreen.classList.contains('hidden') || !settingsScreen.classList.contains('hidden')) return;

    const nextIndex = this.currentPathIndex + 1;
    if (nextIndex >= this.path.length) return;

    this._sfx('hint', 'sfx', 0.9);
    this.clearStuckTimer();
    this.currentPathIndex = nextIndex;
    this.player.currentIndex = nextIndex;
    const nextPos = this.path[nextIndex];
    this.player.mesh.position.set(nextPos.x, 1.2, nextPos.z);
    const prevPos = this.path[nextIndex - 1];
    this.player.setFaceDirection(nextPos.x - prevPos.x, nextPos.z - prevPos.z);
    this.cubeGrid.hintRiseAt(nextIndex);

    if (nextIndex === this.path.length - 1) {
      this.winLevel();
      return;
    }
    this.startStuckTimer();
    if (window.activeTutorial) window.activeTutorial.update();
  }

  skipShow() {
    if (this.mode !== 'campaign') return;
    this._sfx('ui-click', 'ui', 1);
    if (this.state === 'menu' || this.state === 'gameover' || this.state === 'won' || this.skipBusy) return;
    const lsScreen = document.getElementById('level-select-screen');
    const settingsScreen = document.getElementById('settings-screen');
    if (!lsScreen.classList.contains('hidden') || !settingsScreen.classList.contains('hidden')) return;
    this.skipBusy = true;
    this.sequenceId++;
    this.markLevelSkipped(this.currentLevel);
    this.currentLevel++;
    this.saveCurrentLevel(this.currentLevel);
    this.cleanup();
    this.loadLevel();
    this.updateHUD();
    setTimeout(() => { this.skipBusy = false; }, 500);
  }

  togglePause() {
    if (this.state !== 'showing' && this.state !== 'playing') return;
    const lsScreen = document.getElementById('level-select-screen');
    const settingsScreen = document.getElementById('settings-screen');
    if (!lsScreen.classList.contains('hidden') || !settingsScreen.classList.contains('hidden')) return;
    this.paused = !this.paused;
    this.cubeGrid.paused = this.paused;
    const container = document.getElementById('game-container');
    if (this.paused) {
      this._sfx('ui-pause', 'ui', 1);
      if (window.gameAudio) window.gameAudio.pause();
      document.getElementById('pause-popup').classList.remove('hidden');
      document.getElementById('tap-start-overlay').classList.add('hidden');
      container.classList.add('paused');
    } else {
      this._sfx('ui-click', 'ui', 1);
      if (window.gameAudio) window.gameAudio.resume();
      document.getElementById('pause-popup').classList.add('hidden');
      if (this.state === 'showing') document.getElementById('tap-start-overlay').classList.remove('hidden');
      container.classList.remove('paused');
    }
  }

  resumeFromPause() {
    this.paused = false;
    this.cubeGrid.paused = false;
    this._sfx('ui-click', 'ui', 1);
    if (window.gameAudio) window.gameAudio.resume();
    document.getElementById('pause-popup').classList.add('hidden');
    if (this.state === 'showing') document.getElementById('tap-start-overlay').classList.remove('hidden');
    document.getElementById('game-container').classList.remove('paused');
  }

  goHomeFromPause() {
    this.paused = false;
    this.cubeGrid.paused = false;
    this._sfx('ui-back', 'ui', 1);
    if (window.gameAudio) window.gameAudio.resume();
    document.getElementById('pause-popup').classList.add('hidden');
    document.getElementById('game-container').classList.remove('paused');
    this.backToMenu();
  }

  handleMove(direction) {
    if (this.state !== 'playing') return;
    if (this.paused) return;
    if (this.player.isMoving) return;
    direction = this.screenToWorld(direction);
    if (this.blocks.fuseActive) {
      if (direction === this.tntBackDirection) this.backToPrevious();
      return;
    }
    const lsScreen = document.getElementById('level-select-screen');
    const settingsScreen = document.getElementById('settings-screen');
    if (!lsScreen.classList.contains('hidden') || !settingsScreen.classList.contains('hidden')) return;

    const nextIndex = this.currentPathIndex + 1;

    if (nextIndex >= this.path.length) return;

    const currentPos = this.path[this.currentPathIndex];
    const nextPos = this.path[nextIndex];

    const dir = this.pathGen.getDirection(currentPos, nextPos);

    if (dir === direction) {
      this.blocks.cancelSlide();
      this.clearStuckTimer();
      this.currentPathIndex = nextIndex;
      this.player.moveTo(nextPos, nextIndex, () => {
        this.cubeGrid.riseCubeAt(nextIndex);

        if (nextIndex === this.path.length - 1) {
          this.winLevel();
        } else {
          this.blocks.onEntered(nextIndex, this, currentPos);
          if (!this.midpointRewarded && nextIndex >= Math.floor(this.path.length / 2)) {
            this.midpointRewarded = true;
            this.addHealth(1);
            this.updatePhaseText('Midway! +1 Heart');
          }
          this.startStuckTimer();
          if (window.activeTutorial) window.activeTutorial.update();
        }
      });
    } else {
      const v = DIR_VECTORS[direction];
      const nx = currentPos.x + v.x;
      const nz = currentPos.z + v.z;
      if (this.blocks.isDecoy(nx, nz)) {
        this.clearStuckTimer();
        this.tntBackDirection = this.oppositeOf(this.pathGen.getDirection(currentPos, { x: nx, z: nz }));
        this.activeTNT = { x: nx, z: nz };
        this.player.moveTo({ x: nx, z: nz }, -1, () => {
          this.cubeGrid.riseDecoyAt(nx, nz);
          this.blocks.activateTNT(this);
        });
      } else {
        this.gameOver();
      }
    }
  }

  oppositeOf(direction) {
    if (direction === 'up') return 'down';
    if (direction === 'down') return 'up';
    if (direction === 'left') return 'right';
    if (direction === 'right') return 'left';
    return null;
  }

  backToPrevious() {
    if (this.state !== 'playing' || this.paused || this.player.isMoving) return;
    if (!this.blocks.fuseActive) return;
    const target = this.currentPathIndex - 1;
    if (target < 0) return;

    this.blocks.defuseTNT(this);
    this.currentPathIndex = target;
    this.player.moveTo(this.path[target], target, () => {
      this.cubeGrid.riseCubeAt(target);
      this.blocks.onEntered(target, this, this.path[target - 1]);
      this.startStuckTimer();
    });
  }

  onTNTActivated() {
    this._sfx('tnt-fuse', 'sfx', 0.8);
    this.updatePhaseText('TNT! Go back!');
    const btn = document.getElementById(this.btnIdFor(this.tntBackDirection));
    if (btn) btn.classList.add('tnt-back');
  }

  onTNTDefused() {
    this.updatePhaseText('Go!');
    const btn = document.getElementById(this.btnIdFor(this.tntBackDirection));
    if (btn) btn.classList.remove('tnt-back');
    this.tntBackDirection = null;
    this.activeTNT = null;
  }

  onTNTExploded() {
    this.updatePhaseText('BOOM!');
    const btn = document.getElementById(this.btnIdFor(this.tntBackDirection));
    if (btn) btn.classList.remove('tnt-back');
    this.tntBackDirection = null;
    const pos = this.activeTNT || null;
    this.activeTNT = null;
    if (pos && this.cubeGrid.blastAt) {
      setTimeout(() => this._sfx('tnt-boom', 'sfx', 1), 120);
      this.cubeGrid.blastAt(pos.x, pos.z, () => this.gameOver());
    } else {
      this._sfx('tnt-boom', 'sfx', 1);
      this.gameOver();
    }
  }

  addHealth(amount) {
    this._sfx('heart-pickup', 'sfx', 0.9);
    this.health = Math.min(this.health + amount, 3);
    this.renderHearts();
  }

  onFireBurned() {
    this._sfx('fire-warn', 'sfx', 0.9, 800);
    this.health--;
    this.renderHearts();
    this.updatePhaseText('Burned! -1 Heart');
    if (this.health <= 0) {
      this.gameOver();
    }
  }

  showHearts() {
    const container = document.getElementById('hearts');
    if (container) container.classList.remove('hidden');
  }

  hideHearts() {
    const container = document.getElementById('hearts');
    if (container) container.classList.add('hidden');
  }

  renderHearts() {
    const container = document.getElementById('hearts');
    if (!container) return;
    Array.from(container.children).forEach((h, i) => {
      h.classList.toggle('empty', i >= this.health);
    });
  }

  btnIdFor(direction) {
    if (direction === 'up') return 'btn-up';
    if (direction === 'down') return 'btn-down';
    if (direction === 'left') return 'btn-left';
    if (direction === 'right') return 'btn-right';
    return null;
  }

  update(dt) {
    this.environment.update(dt);
    this.islandBuilder.update();
    if (this.paused) return;
    if (this.slideFalling && this.player.mesh) {
      this.player.mesh.position.y -= dt * 5;
      if (this.player.mesh.position.y < -1.2) this.slideFalling = false;
      this.updateFireBar(false);
      return;
    }
    if (this.state !== 'playing') {
      this.updateFireBar(false);
      return;
    }
    this.blocks.update(dt, this);
    if (this.blocks.slideExpired) {
      this.blocks.slideExpired = false;
      this.slideFalling = true;
    }
    if (this.blocks.isSlideActive() && this.player.mesh) {
      const p = this.blocks.slideProgress();
      const pos = this.path[this.currentPathIndex];
      const dir = DIR_VECTORS[this.blocks.slideDir] || { x: 0, z: 0 };
      this.player.mesh.position.set(pos.x + dir.x * 0.45 * p, 1.2, pos.z + dir.z * 0.45 * p);
    }
    this.updateFireBar(this.blocks.fireActive);
  }

  updateFireBar(visible) {
    if (!this._fireBarEls) {
      this._fireBarEls = {
        bar: document.getElementById('fire-bar'),
        fill: document.getElementById('fire-fill')
      };
    }
    const { bar, fill } = this._fireBarEls;
    if (!bar || !fill) return;
    if (visible && this.player.mesh) {
      if (!this._fireBarPos) this._fireBarPos = new THREE.Vector3();
      this._fireBarPos.set(0, 1.6, 0).add(this.player.mesh.position).project(this.camera);
      bar.style.left = ((this._fireBarPos.x + 1) / 2 * window.innerWidth) + 'px';
      bar.style.top = ((-this._fireBarPos.y + 1) / 2 * window.innerHeight) + 'px';
      bar.classList.remove('hidden');
      fill.style.width = (this.blocks.firePercent() * 100).toFixed(1) + '%';
    } else {
      bar.classList.add('hidden');
    }
  }

  startEndlessSegment() {
    this.sequenceId++;
    const len = Math.round(Math.min(Math.max(8 + this.runStreak * 0.75, 8), 25));
    const pseudoLevel = Math.min(this.runStreak * 5 + 1, 200);
    const turnBias = Math.min(0.4 + this.runStreak * 0.05, 0.8);
    const minTurns = Math.max(1, Math.floor(len / 3));
    const segSeed = (this.runSeed + this.runStreak * 7919) >>> 0;

    if (this.runStreak === 0) {
      let attempt = 0;
      while (true) {
        this.path = this.pathGen.generate(len, (segSeed + attempt * 1013) >>> 0, turnBias, minTurns);
        this.offsetPathToCenter();
        this.islandBuilder.build(this.path);
        if (this.path.slice(1, this.path.length - 1).some(p => this.islandBuilder.isOnIsland(p.x, p.z))) {
          attempt++;
          if (attempt > 40) break;
          continue;
        }
        break;
      }
      this.segmentStartIndex = 0;
    } else {
      const oldLen = this.path.length;
      const last = this.path[oldLen - 1];
      const blocked = new Set(this.path.map(p => p.x + ',' + p.z));
      this.islandBuilder.islands.forEach(c => {
        for (let dx = -1; dx <= 1; dx++) {
          for (let dz = -1; dz <= 1; dz++) {
            const x = c.x + dx, z = c.z + dz;
            if (Math.abs(x - last.x) + Math.abs(z - last.z) <= 1 && (x !== last.x || z !== last.z) && (dx !== 0 || dz !== 0)) continue;
            blocked.add(x + ',' + z);
          }
        }
      });
      this.blocks.decoys.forEach(d => blocked.add(d.x + ',' + d.z));
      let seg = null;
      for (let attempt = 0; attempt < 40; attempt++) {
        const cand = this.pathGen.generate(len, (segSeed + attempt * 1013) >>> 0, turnBias, minTurns, blocked, last, this.path[0]);
        if (!cand) continue;
        const newCells = cand.slice(1).map(p => p.x + ',' + p.z);
        const e = cand[cand.length - 1];
        const eC = { x: e.x + (e.x - cand[cand.length - 2].x), z: e.z + (e.z - cand[cand.length - 2].z) };
        if (this.islandBuilder.islands.some(c => Math.abs(c.x - eC.x) < 4 && Math.abs(c.z - eC.z) < 4)) continue;
        const eKey = e.x + ',' + e.z;
        let baseOk = true;
        for (let bx = -1; bx <= 1 && baseOk; bx++) {
          for (let bz = -1; bz <= 1 && baseOk; bz++) {
            const k = (eC.x + bx) + ',' + (eC.z + bz);
            if (blocked.has(k)) baseOk = false;
            else if (k !== eKey && newCells.includes(k)) baseOk = false;
          }
        }
        if (!baseOk) continue;
        seg = cand;
        break;
      }
      if (!seg) {
        seg = this.pathGen.generate(len, segSeed, turnBias, minTurns);
      }
      this.path = this.path.concat(seg.slice(1));
      this.segmentStartIndex = oldLen - 1;
    }

    this.blocks.assign(this.path, segSeed, pseudoLevel, this.segmentStartIndex, { noHearts: true });
    this.blocks.types[this.segmentStartIndex] = BLOCK_TYPES.GRASS;
    if (this.runStreak === 0) {
      this.showStartIndex = 0;
    } else {
      this.cubeGrid.retypeCube(this.segmentStartIndex, BLOCK_TYPES.GRASS);
      this.islandBuilder.buildEndOnly(this.path);
      this.showStartIndex = this.segmentStartIndex + 1;
    }
    this.cubeGrid.buildFromPath(this.path, this.blocks, this.showStartIndex);
    this.adjustCameraToPath(this.segmentStartIndex, this.path.length - 1);

    if (this.runStreak === 0) {
      this.player.create(this.path[0]);
      this.currentPathIndex = 0;
    } else {
      this.currentPathIndex = this.segmentStartIndex;
    }
    this.player.isMoving = false;

    this.health = 1;
    this.midpointRewarded = true;
    this.hideHearts();

    this.state = 'showing';
    this.updatePhaseText('Island ' + (this.runStreak + 1) + '! Watch!');
    document.getElementById('skip-btn').classList.add('hidden');
    document.getElementById('hint-btn').classList.add('hidden');
    document.getElementById('rotate-right-btn').classList.add('hidden');
    document.getElementById('controls').classList.add('hidden');
    document.getElementById('pause-btn').classList.remove('hidden');
    document.getElementById('game-container').classList.add('game-active');
    document.getElementById('info-bar').classList.remove('hidden');
    this.updateHUD();

    this.startShowSequence();
  }

  async endlessComplete() {
    if (this.state !== 'playing') return;
    this.state = 'won';
    this.runStreak++;
    this.updatePhaseText('Island ' + this.runStreak + ' Complete!');
    document.getElementById('hint-btn').classList.add('hidden');
    document.getElementById('rotate-right-btn').classList.add('hidden');
    const best = parseInt(localStorage.getItem('rak_best_endless')) || 0;
    if (this.runStreak > best) localStorage.setItem('rak_best_endless', String(this.runStreak));
    this.updateHUD();
    await this.cubeGrid.sinkOldCubes(this.path.length - 1);
    if (this.state !== 'won') return;
    this.startEndlessSegment();
  }

  winLevel() {
    this._sfx('win', 'sfx', 1);
    if (this.mode === 'endless') {
      this.endlessComplete();
      return;
    }
    const tutWin = this.isTutorial;
    this.state = 'won';
    if (tutWin && window.activeTutorial) window.activeTutorial.stop(false);
    this.updatePhaseText(this.mode === 'daily' ? 'Daily Complete!' : 'Level Complete!');
    document.getElementById('skip-btn').classList.add('hidden');
    document.getElementById('hint-btn').classList.add('hidden');
    document.getElementById('rotate-right-btn').classList.add('hidden');
    document.getElementById('controls').classList.add('hidden');

    if (tutWin) {
      localStorage.setItem('rak_tutorial', '1');
    } else if (this.mode === 'daily') {
      this.markDailyComplete();
    } else {
      this.markLevelComplete(this.currentLevel);
      this.saveCurrentLevel(this.currentLevel + 1);
    }

    setTimeout(() => {
      const title = document.getElementById('win-title');
      const subtitle = document.getElementById('win-subtitle');
      const nextBtn = document.getElementById('next-btn');
      if (this.mode === 'daily') {
        if (title) title.textContent = 'DAILY COMPLETE!';
        if (subtitle) {
          subtitle.textContent = 'Streak: ' + this.getDailyStreak() + ' days';
          subtitle.classList.remove('hidden');
        }
        if (nextBtn) nextBtn.textContent = 'MENU';
      } else if (tutWin) {
        if (title) title.textContent = 'TUTORIAL COMPLETE!';
        if (subtitle) subtitle.classList.add('hidden');
        if (nextBtn) nextBtn.textContent = 'MENU';
      } else {
        if (title) title.textContent = 'LEVEL COMPLETE!';
        if (subtitle) subtitle.classList.add('hidden');
        if (nextBtn) nextBtn.textContent = 'NEXT LEVEL';
      }
      document.getElementById('win-screen').classList.remove('hidden');
    }, 500);
  }

  nextLevel() {
    if (this.isTutorial) {
      this.backToMenu();
      return;
    }
    this._sfx('ui-click', 'ui', 1);
    this.currentLevel++;
    this.saveCurrentLevel(this.currentLevel);
    document.getElementById('win-screen').classList.add('hidden');
    this.cleanup();
    this.sequenceId++;
    this.loadLevel();
    this.updateHUD();
  }

  gameOver() {
    this._sfx('gameover', 'sfx', 1);
    this.state = 'gameover';
    this.updatePhaseText('Game Over');
    document.getElementById('skip-btn').classList.add('hidden');
    document.getElementById('hint-btn').classList.add('hidden');
    document.getElementById('rotate-right-btn').classList.add('hidden');
    document.getElementById('controls').classList.add('hidden');
    if (this.isTutorial && window.activeTutorial) window.activeTutorial.stop(false);

    const title = document.getElementById('go-title');
    const subtitle = document.getElementById('go-subtitle');
    if (title) title.textContent = 'GAME OVER';
    if (subtitle) subtitle.textContent = 'Wrong direction!';
    const restartBtn = document.getElementById('restart-btn');
    if (restartBtn) {
      restartBtn.classList.remove('hidden');
      restartBtn.textContent = 'TRY AGAIN';
    }
    if (this.mode === 'endless') {
      const best = parseInt(localStorage.getItem('rak_best_endless')) || 0;
      document.getElementById('final-level').textContent = 'Islands: ' + this.runStreak + ' (Best: ' + best + ')';
    } else if (this.mode === 'daily') {
      document.getElementById('final-level').textContent = 'Daily ' + this.dateLabel() + ' — Streak: ' + this.getDailyStreak() + ' days';
    } else {
      document.getElementById('final-level').textContent = 'Level ' + this.currentLevel;
    }
    setTimeout(() => {
      document.getElementById('gameover-screen').classList.remove('hidden');
    }, 300);
  }

  restart() {
    this._sfx('ui-click', 'ui', 1);
    document.getElementById('gameover-screen').classList.add('hidden');
    if (this.mode === 'endless') {
      this.cleanup();
      this.runStreak = 0;
      this.runSeed = (Date.now() & 0x7fffffff) || 1;
      this.startEndlessSegment();
    } else if (this.mode === 'daily') {
      this.cleanup();
      if (this.isDailyDone()) {
        this.backToMenu();
        return;
      }
      this.startDailyLevel();
    } else if (this.isTutorial) {
      this.setupLevel({ tutorial: true, level: 0, seed: 1, noHearts: true, canSkip: false, phaseText: 'Tutorial' });
      if (window.activeTutorial) {
        window.activeTutorial.stop(false);
      }
      new Tutorial().start();
    } else {
      this.cleanup();
      this.sequenceId++;
      this.loadLevel();
    }
    this.updateHUD();
  }

  backToMenu() {
    this._sfx('ui-back', 'ui', 1);
    this.cleanup();
    this.paused = false;
    this.cubeGrid.paused = false;
    this.sequenceId++;
    this.state = 'menu';
    this.isTutorial = false;
    if (window.activeTutorial) window.activeTutorial.stop(false);
    document.getElementById('skip-btn').classList.add('hidden');
    document.getElementById('hint-btn').classList.add('hidden');
    document.getElementById('rotate-right-btn').classList.add('hidden');
    document.getElementById('controls').classList.add('hidden');
    document.getElementById('pause-popup').classList.add('hidden');
    document.getElementById('gameover-screen').classList.add('hidden');
    document.getElementById('win-screen').classList.add('hidden');
    document.getElementById('level-select-screen').classList.add('hidden');
    document.getElementById('menu-screen').classList.remove('hidden');
    document.getElementById('game-container').classList.remove('game-active');
    document.getElementById('game-container').classList.remove('level-select-active');
    this.updatePhaseText('');
    this.updateHUD();
  }

  dateLabel() {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const d = new Date();
    return d.getDate() + ' ' + months[d.getMonth()];
  }

  updateHUD() {
    const indicator = document.getElementById('level-indicator');
    if (!indicator) return;
    if (this.mode === 'endless') {
      indicator.textContent = 'Island ' + (this.runStreak + 1);
    } else if (this.mode === 'daily') {
      indicator.textContent = 'Daily ' + this.dateLabel();
    } else {
      indicator.textContent = 'Level ' + this.currentLevel;
    }
  }

  updatePhaseText(text) {
    const el = document.getElementById('phase-text');
    if (el) el.textContent = text || '';
  }

  getInputMode() {
    return localStorage.getItem('rak_input') || 'dpad';
  }

  setInputMode(mode) {
    this._sfx('ui-toggle', 'ui', 1);
    localStorage.setItem('rak_input', mode);
    const dpadBtn = document.getElementById('input-dpad');
    const swipeBtn = document.getElementById('input-swipe');
    if (mode === 'dpad') {
      dpadBtn.classList.add('selected');
      swipeBtn.classList.remove('selected');
    } else {
      swipeBtn.classList.add('selected');
      dpadBtn.classList.remove('selected');
    }
    this.updateInputUI(mode);
  }

  updateInputUI(mode) {
    if (this.state !== 'showing' && this.state !== 'playing') return;
    if (mode === 'swipe') {
      document.getElementById('controls').classList.add('hidden');
    } else {
      document.getElementById('controls').classList.remove('hidden');
    }
  }

  showSettings() {
    this._sfx('ui-click', 'ui', 1);
    document.getElementById('menu-screen').classList.add('hidden');
    document.getElementById('settings-screen').classList.remove('hidden');
    document.getElementById('info-bar').classList.add('hidden');
    this.updatePhaseText('');

    const mode = this.getInputMode();
    const dpadBtn = document.getElementById('input-dpad');
    const swipeBtn = document.getElementById('input-swipe');
    if (mode === 'dpad') {
      dpadBtn.classList.add('selected');
      swipeBtn.classList.remove('selected');
    } else {
      swipeBtn.classList.add('selected');
      dpadBtn.classList.remove('selected');
    }
  }

  hideSettings() {
    this._sfx('ui-back', 'ui', 1);
    document.getElementById('settings-screen').classList.add('hidden');
    document.getElementById('menu-screen').classList.remove('hidden');
    this.updatePhaseText('');
  }

  resetProgress() {
    this._sfx('ui-back', 'ui', 1);
    localStorage.removeItem('rak_completed');
    localStorage.removeItem('rak_skipped');
    localStorage.removeItem('rak_level');
    localStorage.removeItem('rak_completed_n');
    localStorage.removeItem('rak_skipped_n');
    localStorage.removeItem('rak_level_n');
    localStorage.removeItem('rak_completed_h');
    localStorage.removeItem('rak_skipped_h');
    localStorage.removeItem('rak_level_h');
    localStorage.removeItem('rak_diff');
    localStorage.removeItem('rak_mode');
    localStorage.removeItem('rak_best_endless');
    localStorage.removeItem('rak_daily_last');
    localStorage.removeItem('rak_daily_streak');
    this.currentLevel = 1;
    document.getElementById('settings-screen').classList.add('hidden');
    document.getElementById('menu-screen').classList.remove('hidden');
    this.updatePhaseText('');
    this.updateHUD();
  }

  cleanup() {
    document.getElementById('pause-btn').classList.add('hidden');
    document.getElementById('hint-btn').classList.add('hidden');
    document.getElementById('rotate-right-btn').classList.add('hidden');
    document.getElementById('tap-start-overlay').classList.add('hidden');
    document.getElementById('info-bar').classList.add('hidden');
    document.getElementById('fire-bar').classList.add('hidden');
    document.getElementById('game-container').classList.remove('game-active');
    this.clearStuckTimer();
    this.tntBackDirection = null;
    this.slideFalling = false;
    this.hideHearts();
    document.querySelectorAll('.ctrl-btn.tnt-back').forEach(b => b.classList.remove('tnt-back'));
    this.blocks.reset();
    this.cubeGrid.clear();
    this.cubeGrid.removePathLine();
    this.player.destroy();
  }
}
