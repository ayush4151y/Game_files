class SeededRandom {
  constructor(seed) {
    this.seed = seed;
  }

  next() {
    this.seed = (this.seed * 1664525 + 1013904223) & 0xffffffff;
    return (this.seed >>> 0) / 0xffffffff;
  }
}

class PathGenerator {
  constructor() {
    this.directions = [
      { x: 0, z: -1, name: 'up' },
      { x: 0, z: 1, name: 'down' },
      { x: -1, z: 0, name: 'left' },
      { x: 1, z: 0, name: 'right' }
    ];
  }

  generate(length, seed, turnBias, minTurns, avoid, startPos, pull) {
    let last = null;
    for (let attempt = 0; attempt < 40; attempt++) {
      const bias = Math.min((turnBias || 0) + attempt * 0.08, 0.9);
      const result = this.tryGenerate(length, seed + attempt * 7919, bias, avoid, startPos, pull);
      if (result && this.countTurns(result) >= (minTurns || 0)) return result;
      if (result) last = result;
    }
    return last;
  }

  countTurns(path) {
    let turns = 0;
    for (let i = 2; i < path.length; i++) {
      const d1 = { x: path[i].x - path[i - 1].x, z: path[i].z - path[i - 1].z };
      const d2 = { x: path[i - 1].x - path[i - 2].x, z: path[i - 1].z - path[i - 2].z };
      if (d1.x !== d2.x || d1.z !== d2.z) turns++;
    }
    return turns;
  }

  tryGenerate(length, seed, turnBias, avoid, startPos, pull) {
    const rng = new SeededRandom(seed);
    const path = [];
    const visited = new Set(avoid || []);
    const key = (x, z) => `${x},${z}`;
    const sp = startPos || { x: 0, z: 0 };

    const weighted = (candidates) => {
      if (!pull || candidates.length < 2) return candidates[Math.floor(rng.next() * candidates.length)];
      let best = candidates[0], bestD = -Infinity;
      candidates.forEach(c => {
        const nx = path[path.length - 1].x + c.x;
        const nz = path[path.length - 1].z + c.z;
        const d = (nx - pull.x) * (nx - pull.x) + (nz - pull.z) * (nz - pull.z);
        if (d > bestD) { bestD = d; best = c; }
      });
      return best;
    };

    path.push({ x: sp.x, z: sp.z });
    visited.add(key(sp.x, sp.z));

    let lastDir = null;

    for (let i = 0; i < length; i++) {
      const current = path[path.length - 1];

      const available = this.directions.filter(d => {
        if (lastDir && d.x === -lastDir.x && d.z === -lastDir.z) return false;
        const nx = current.x + d.x;
        const nz = current.z + d.z;
        if (visited.has(key(nx, nz))) return false;
        return true;
      });

      if (available.length === 0) return null;

      let chosen = null;
      if (lastDir && turnBias && available.length > 1) {
        const straight = available.find(d => d.x === lastDir.x && d.z === lastDir.z);
        const turns = available.filter(d => d !== straight);
        if (turns.length && rng.next() < turnBias) {
          chosen = weighted(turns);
        } else if (straight) {
          chosen = straight;
        }
      }
      if (!chosen) chosen = weighted(available);
      lastDir = chosen;

      const next = {
        x: current.x + chosen.x,
        z: current.z + chosen.z
      };

      path.push(next);
      visited.add(key(next.x, next.z));
    }

    return path;
  }

  getDirection(from, to) {
    const dx = to.x - from.x;
    const dz = to.z - from.z;
    if (dx === 1 && dz === 0) return 'right';
    if (dx === -1 && dz === 0) return 'left';
    if (dx === 0 && dz === -1) return 'up';
    if (dx === 0 && dz === 1) return 'down';
    return null;
  }
}
