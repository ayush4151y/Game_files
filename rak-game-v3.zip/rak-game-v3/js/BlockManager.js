const BLOCK_TYPES = Object.freeze({
  GRASS: 'grass',
  ICE: 'ice',
  FIRE: 'fire',
  TNT: 'tnt',
  HEART: 'heart'
});

const DIR_VECTORS = {
  up: { x: 0, z: -1 },
  down: { x: 0, z: 1 },
  left: { x: -1, z: 0 },
  right: { x: 1, z: 0 }
};

const ICE_SLIDE_TIME = 2.0;
const FIRE_BUDGET = 3.0;
const TNT_FUSE_TIME = 3.0;

const LEVEL_TIERS = [
  { start: 1, end: 20, ice: 0, fire: 0, tnt: 0, heart: 0 },
  { start: 21, end: 50, ice: [0.12, 0.20], fire: 0, tnt: 0.5, heart: 0 },
  { start: 51, end: 100, ice: [0.20, 0.30], fire: [0.10, 0.25], tnt: 0.4, heart: 0 },
  { start: 101, end: 200, ice: [0.30, 0.40], fire: [0.25, 0.40], tnt: 0.35, heart: 0.08 }
];

function ramp(chance, level, tier) {
  if (!chance) return 0;
  if (typeof chance === 'number') return chance;
  const t = Math.min((level - tier.start) / (tier.end - tier.start), 1);
  return chance[0] + (chance[1] - chance[0]) * t;
}

class BlockManager {
  constructor() {
    this.types = [];
    this.decoys = [];
    this.slideRemaining = null;
    this.slideDir = null;
    this.slideExpired = false;
    this.fireRemaining = FIRE_BUDGET;
    this.standingOnFire = false;
    this.fuseRemaining = null;
  }

  assign(path, seed, level, startIndex = 0, opts = {}) {
    const tier = LEVEL_TIERS.find(t => level <= t.end) || LEVEL_TIERS[LEVEL_TIERS.length - 1];
    const icePct = ramp(tier.ice, level, tier);
    const firePct = ramp(tier.fire, level, tier);
    const heartPct = opts.noHearts ? 0 : ramp(tier.heart, level, tier);
    const rng = new SeededRandom((seed * 2654435761) >>> 0);

    for (let i = startIndex; i < path.length; i++) {
      if (i === 0) {
        this.types[0] = BLOCK_TYPES.GRASS;
        continue;
      }
      const r = rng.next();
      if (heartPct && r < heartPct) this.types[i] = BLOCK_TYPES.HEART;
      else if (firePct && r < heartPct + firePct) this.types[i] = BLOCK_TYPES.FIRE;
      else if (icePct && r < heartPct + firePct + icePct) this.types[i] = BLOCK_TYPES.ICE;
      else this.types[i] = BLOCK_TYPES.GRASS;
    }

    let firstCandidate = null;
    for (let i = startIndex + 1; i < path.length - 1; i++) {
      const d1 = this.directionOf(path[i - 1], path[i]);
      const d2 = this.directionOf(path[i], path[i + 1]);
      if (d1 === d2 || !d1) continue;
      const v = DIR_VECTORS[d1];
      const pos = { x: path[i].x + v.x, z: path[i].z + v.z };
      const overlapsPath = path.some(p => p.x === pos.x && p.z === pos.z);
      const overlapsDecoy = this.decoys.some(d => d.x === pos.x && d.z === pos.z);
      const isTNT = rng.next() < tier.tnt;
      if (!overlapsPath && !overlapsDecoy) {
        if (!firstCandidate) firstCandidate = pos;
        if (isTNT) this.decoys.push(pos);
      }
    }
    if (level > 20 && this.decoys.length === 0 && firstCandidate) {
      this.decoys.push(firstCandidate);
    }
  }

  directionOf(from, to) {
    const dx = to.x - from.x;
    const dz = to.z - from.z;
    if (dx === 1 && dz === 0) return 'right';
    if (dx === -1 && dz === 0) return 'left';
    if (dx === 0 && dz === -1) return 'up';
    if (dx === 0 && dz === 1) return 'down';
    return null;
  }

  typeOf(index) {
    return this.types[index] || BLOCK_TYPES.GRASS;
  }

  isDecoy(x, z) {
    return this.decoys.some(d => d.x === x && d.z === z);
  }

  isSlideActive() {
    return this.slideRemaining !== null;
  }

  slideProgress() {
    if (this.slideRemaining === null) return 0;
    return 1 - Math.max(this.slideRemaining / ICE_SLIDE_TIME, 0);
  }

  get fuseActive() {
    return this.fuseRemaining !== null;
  }

  get fireActive() {
    return this.standingOnFire;
  }

  firePercent() {
    return Math.max(this.fireRemaining / FIRE_BUDGET, 0);
  }

  onEntered(index, gm, fromPos) {
    const type = this.typeOf(index);
    if (type === BLOCK_TYPES.ICE) {
      this.slideRemaining = ICE_SLIDE_TIME;
      this.slideDir = this.directionOf(fromPos, gm.path[index]);
      gm.updatePhaseText('SLIDING! Choose direction!');
      if (window.gameAudio) window.gameAudio.play('ice-slide', 'sfx', 0.8);
    } else if (this.slideRemaining !== null) {
      this.slideRemaining = null;
      gm.updatePhaseText('Go!');
    }
    if (type === BLOCK_TYPES.FIRE) {
      this.standingOnFire = true;
      this.fireWarnAccum = 0;
      if (gm.player && gm.player.setFire) gm.player.setFire(true);
    } else if (this.standingOnFire) {
      this.standingOnFire = false;
      if (gm.player && gm.player.setFire) gm.player.setFire(false);
    }
    if (type === BLOCK_TYPES.HEART) {
      gm.addHealth(1);
      gm.updatePhaseText('Heart! +1');
    }
  }

  cancelSlide() {
    this.slideRemaining = null;
  }

  activateTNT(gm) {
    this.fuseRemaining = TNT_FUSE_TIME;
    gm.onTNTActivated();
  }

  defuseTNT(gm) {
    this.fuseRemaining = null;
    gm.onTNTDefused();
  }

  update(dt, gm) {
    if (this.slideRemaining !== null) {
      this.slideRemaining -= dt;
      if (this.slideRemaining <= 0) {
        this.slideRemaining = null;
        this.slideExpired = true;
        gm.gameOver();
        return;
      }
    }
    if (this.standingOnFire) {
      this.fireRemaining -= dt;
      if (this.fireRemaining <= 0) {
        this.fireRemaining = FIRE_BUDGET;
        gm.onFireBurned();
        return;
      }
      this.fireWarnAccum = (this.fireWarnAccum || 0) + dt;
      if (this.fireWarnAccum >= 0.22) {
        this.fireWarnAccum = 0;
        if (window.gameAudio) window.gameAudio.play('fire-warn', 'sfx', 0.6);
      }
      gm.updatePhaseText('FIRE! ' + Math.max(this.fireRemaining, 0).toFixed(1) + 's');
    }
    if (this.fuseRemaining !== null) {
      this.fuseRemaining -= dt;
      if (this.fuseRemaining <= 0) {
        this.fuseRemaining = null;
        gm.onTNTExploded();
        return;
      }
    }
  }

  reset() {
    this.types = [];
    this.decoys = [];
    this.slideRemaining = null;
    this.slideDir = null;
    this.slideExpired = false;
    this.fireRemaining = FIRE_BUDGET;
    this.standingOnFire = false;
    this.fireWarnAccum = 0;
    this.fuseRemaining = null;
  }
}
