class AnimTween {
  static animate(obj, prop, from, to, duration, easing, onComplete) {
    const start = performance.now();
    const ease = easing || ((t) => 1 - Math.pow(1 - t, 3));

    function update() {
      const elapsed = performance.now() - start;
      let t = Math.min(elapsed / duration, 1);
      const val = from + (to - from) * ease(t);
      if (typeof prop === 'string') {
        obj[prop] = val;
      } else {
        prop(obj, val);
      }
      if (t < 1) {
        requestAnimationFrame(update);
      } else if (onComplete) {
        onComplete();
      }
    }
    update();
  }

  static wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

const CUBE_MATERIALS = {
  grass: { color: 0x4caf50, emissive: 0x2e7d32, shininess: 60 },
  ice: { color: 0x2196f3, emissive: 0x1565c0, shininess: 120 },
  fire: { color: 0xff9800, emissive: 0xe65100, shininess: 60 },
  tnt: { color: 0xb71c1c, emissive: 0x4a0000, shininess: 30 },
  heart: { color: 0xe91e63, emissive: 0x880e4f, shininess: 90 }
};

const TEXTURE_FILES = {
  [BLOCK_TYPES.GRASS]: { top: 'assets/texture/grass_top.jpg', side: 'assets/texture/grass_side.jpg' },
  [BLOCK_TYPES.ICE]: { all: 'assets/texture/ice.jpeg' },
  [BLOCK_TYPES.FIRE]: { all: 'assets/texture/fire.png' },
  [BLOCK_TYPES.TNT]: { top: 'assets/texture/tnt_top.jpg', side: 'assets/texture/tnt_face.jpg' },
  start: { top: 'assets/texture/start_top.jpg', side: 'assets/texture/side_face.jpg' },
  end: { top: 'assets/texture/end_top.jpg', side: 'assets/texture/end_face.jpg' }
};

class CubeGrid {
  constructor(scene) {
    this.scene = scene;
    this.cubes = {};
    this.pathCubes = [];
    this.decoyCubes = [];
    this.startCube = null;
    this.endCube = null;
    this.materials = {};
    this.geometries = [];
  }

  eachMat(mats, fn) {
    (Array.isArray(mats) ? mats : [mats]).forEach(fn);
  }

  loadTexture(src) {
    if (!this.textureLoader) this.textureLoader = new THREE.TextureLoader();
    const t = this.textureLoader.load(src);
    if (typeof MAX_ANISO === 'number') t.anisotropy = MAX_ANISO;
    return t;
  }

  makeRoundedBox(width, height, depth, radius, segments) {
    const geo = new THREE.BoxGeometry(width, height, depth, segments, segments, segments);
    const pos = geo.attributes.position;
    const halfW = width / 2, halfH = height / 2, halfD = depth / 2;
    const r = Math.min(radius, halfW, halfH, halfD);
    const v = new THREE.Vector3();
    for (let i = 0; i < pos.count; i++) {
      v.fromBufferAttribute(pos, i);
      const ax = Math.max(Math.abs(v.x) - (halfW - r), 0);
      const ay = Math.max(Math.abs(v.y) - (halfH - r), 0);
      const az = Math.max(Math.abs(v.z) - (halfD - r), 0);
      const d = Math.sqrt(ax * ax + ay * ay + az * az);
      if (d > r) {
        const t = r / d;
        v.x = Math.sign(v.x) * ((halfW - r) + ax * t);
        v.y = Math.sign(v.y) * ((halfH - r) + ay * t);
        v.z = Math.sign(v.z) * ((halfD - r) + az * t);
      }
      pos.setXYZ(i, v.x, v.y, v.z);
    }
    pos.needsUpdate = true;
    geo.computeVertexNormals();
    return geo;
  }

  getTypeMaterial(type) {
    if (!this.materials[type]) {
      const def = CUBE_MATERIALS[type] || CUBE_MATERIALS.grass;
      const files = TEXTURE_FILES[type];
      const fallback = files ? null : this.createBlockTexture(type);
      const mats = [];
      for (let i = 0; i < 6; i++) {
        const isTop = i === 2;
        const src = files ? (isTop ? (files.top || files.all) : (files.side || files.all)) : null;
        const m = new THREE.MeshPhongMaterial({
          map: src ? this.loadTexture(src) : fallback,
          emissive: 0x000000,
          emissiveIntensity: 0,
          shininess: def.shininess
        });
        applyToon(m);
        mats.push(m);
      }
      this.materials[type] = mats;
    }
    return this.materials[type];
  }

  createBlockTexture(type) {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d');
    const def = CUBE_MATERIALS[type] || CUBE_MATERIALS.grass;
    const base = '#' + def.color.toString(16).padStart(6, '0');
    const dark = '#' + def.emissive.toString(16).padStart(6, '0');

    ctx.fillStyle = base;
    ctx.fillRect(0, 0, 256, 256);

    if (type === BLOCK_TYPES.GRASS) {
      ctx.fillStyle = 'rgba(0,0,0,0.15)';
      for (let y = 16; y < 256; y += 32) {
        for (let x = 16; x < 256; x += 32) {
          ctx.fillRect(x - 3, y - 3, 6, 6);
        }
      }
    } else if (type === BLOCK_TYPES.ICE) {
      ctx.strokeStyle = 'rgba(255,255,255,0.35)';
      ctx.lineWidth = 10;
      for (let i = -256; i < 512; i += 48) {
        ctx.beginPath();
        ctx.moveTo(i, 256);
        ctx.lineTo(i + 256, 0);
        ctx.stroke();
      }
    } else if (type === BLOCK_TYPES.FIRE) {
      ctx.fillStyle = 'rgba(0,0,0,0.25)';
      for (let i = 0; i < 14; i++) {
        const x = (i * 97) % 256;
        const y = (i * 53) % 256;
        ctx.beginPath();
        ctx.arc(x, y, 14 + (i % 4) * 6, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = 'rgba(255,255,255,0.18)';
      ctx.beginPath();
      ctx.arc(128, 128, 20, 0, Math.PI * 2);
      ctx.fill();
    } else if (type === BLOCK_TYPES.TNT) {
      ctx.fillStyle = dark;
      ctx.fillRect(0, 96, 256, 64);
      ctx.strokeStyle = 'rgba(255,255,255,0.4)';
      ctx.lineWidth = 4;
      ctx.strokeRect(8, 8, 240, 240);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 58px Arial';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('TNT', 128, 132);
    } else if (type === BLOCK_TYPES.HEART) {
      ctx.fillStyle = 'rgba(255,255,255,0.9)';
      ctx.save();
      ctx.translate(128, 140);
      ctx.scale(0.9, 0.9);
      ctx.beginPath();
      ctx.moveTo(0, 30);
      ctx.bezierCurveTo(-70, -20, -35, -80, 0, -25);
      ctx.bezierCurveTo(35, -80, 70, -20, 0, 30);
      ctx.fill();
      ctx.restore();
    }

    const texture = new THREE.CanvasTexture(canvas);
    return texture;
  }

  buildFromPath(path, blocks, startIndex = 0) {
    if (startIndex === 0) this.clear();

    const cubeSize = 1;
    const hiddenY = -0.8;
    const geometry = new THREE.BoxGeometry(cubeSize * 0.9, cubeSize * 0.9, cubeSize * 0.9);
    this.geometries.push(geometry);

    for (let i = startIndex; i < path.length; i++) {
      const pos = path[i];
      const isStart = i === 0;
      const isEnd = i === path.length - 1;
      const type = blocks ? blocks.typeOf(i) : BLOCK_TYPES.GRASS;
      let material;
      if (isStart || isEnd) {
        material = this.getTypeMaterial(isStart ? 'start' : 'end');
      } else {
        material = this.getTypeMaterial(type);
      }
      material = material.map(m => m.clone());

      const cube = new THREE.Mesh(geometry, material);
      cube.position.set(pos.x, hiddenY, pos.z);
      cube.visible = false;
      cube.receiveShadow = true;
      cube.userData = {
        pathIndex: i,
        isStart,
        isEnd,
        type,
        revealed: false,
        hidden: true,
        normalY: 0.5,
        hiddenY: hiddenY,
        restoreEmissive: material[0].emissive.getHex(),
        restoreIntensity: 0.15
      };
      cube.userData.materials = material;
      this.scene.add(cube);

      const key = `${pos.x},${pos.z}`;
      this.cubes[key] = cube;
      this.pathCubes.push(cube);

      if (isStart) this.startCube = cube;
      if (isEnd) this.endCube = cube;
    }

    if (blocks && blocks.decoys.length) {
      const existing = new Set(this.decoyCubes.map(c => c.position.x + ',' + c.position.z));
      const tntDef = CUBE_MATERIALS.tnt;
      const tntFiles = TEXTURE_FILES[BLOCK_TYPES.TNT];
      const mk = (src) => {
        const m = new THREE.MeshPhongMaterial({
          map: src ? this.loadTexture(src) : null,
          emissive: 0x000000,
          emissiveIntensity: 0,
          shininess: tntDef.shininess
        });
        applyToon(m);
        return m;
      };
      if (!this.materials['tnt-cyl']) {
        this.materials['tnt-cyl'] = [
          mk(tntFiles.side), mk(tntFiles.side),
          mk(tntFiles.top), mk(tntFiles.top),
          mk(tntFiles.side), mk(tntFiles.side)
        ];
      }
      if (!this.tntCylGeo) {
        this.tntCylGeo = this.makeRoundedBox(0.7, 0.8, 0.7, 0.09, 5);
        this.geometries.push(this.tntCylGeo);
      }
      blocks.decoys.forEach(pos => {
        const key = `${pos.x},${pos.z}`;
        if (existing.has(key) || this.cubes[key]) return;
        const cube = new THREE.Mesh(this.tntCylGeo, this.materials['tnt-cyl']);
        cube.position.set(pos.x, hiddenY, pos.z);
        cube.visible = false;
        cube.userData = {
          pathIndex: -1,
          isStart: false,
          isEnd: false,
          type: BLOCK_TYPES.TNT,
          revealed: false,
          hidden: true,
          normalY: 0.4,
          hiddenY: hiddenY
        };
        this.scene.add(cube);
        this.cubes[`${pos.x},${pos.z}`] = cube;
        this.decoyCubes.push(cube);
      });
    }
  }

  async showPathWave(onCubeRise, startIndex = 0) {
    for (let i = startIndex; i < this.pathCubes.length; i++) {
      while (this.paused) await AnimTween.wait(100);
      const cube = this.pathCubes[i];
      cube.visible = true;
      AnimTween.animate(
        cube.position, 'y',
        cube.userData.hiddenY, cube.userData.normalY,
        250, (t) => 1 - Math.pow(1 - t, 3)
      );
      cube.userData.hidden = false;

      if (onCubeRise) onCubeRise(i);
      if (window.gameAudio) window.gameAudio.play('cube-rise', 'sfx', 0.45);
      await AnimTween.wait(100);
    }
  }

  async hidePathWave(onCubeSink, skipStartEnd = true, startIndex = 0) {
    for (let i = startIndex; i < this.pathCubes.length; i++) {
      const cube = this.pathCubes[i];
      if (skipStartEnd && (cube.userData.isStart || cube.userData.isEnd)) continue;

      AnimTween.animate(
        cube.position, 'y',
        cube.userData.normalY, cube.userData.hiddenY,
        200, (t) => 1 - Math.pow(1 - t, 3),
        () => { cube.visible = false; }
      );
      cube.userData.hidden = true;

      if (onCubeSink) onCubeSink(i);
      await AnimTween.wait(80);
    }
  }

  sinkOldCubes(keepIndex) {
    const jobs = this.pathCubes.filter(c => c.userData.pathIndex < keepIndex && !c.userData.hidden);
    return new Promise(resolve => {
      if (!jobs.length) { resolve(); return; }
      let done = 0;
      jobs.forEach(cube => {
        AnimTween.animate(
          cube.position, 'y',
          cube.userData.normalY, cube.userData.hiddenY,
          200, (t) => 1 - Math.pow(1 - t, 3),
          () => {
            cube.visible = false;
            if (++done === jobs.length) resolve();
          }
        );
        cube.userData.hidden = true;
      });
    });
  }

  drawPathLine(path, startIndex = 0) {
    if (this.pathLine) this.removePathLine();
    const points = path.slice(startIndex).map(p => new THREE.Vector3(p.x, 0.98, p.z));
    const curve = new THREE.CatmullRomCurve3(points);
    const tubeGeo = new THREE.TubeGeometry(curve, 64, 0.1, 12, false);
    const mat = new THREE.MeshPhongMaterial({
      color: 0xff6d00,
      emissive: 0xff6d00,
      emissiveIntensity: 0.6,
      transparent: true,
      opacity: 0.9
    });
    this.pathLine = new THREE.Mesh(tubeGeo, mat);
    this.scene.add(this.pathLine);
  }

  startIdleAnimations() {
    this.pathCubes.forEach(cube => {
      if (cube.userData.isStart) {
        this.pulseCube(cube, 0x4caf50, 0x2e7d32, 0.3, 1200);
      } else if (cube.userData.isEnd) {
        this.pulseCube(cube, 0xff5252, 0xd32f2f, 0.3, 900);
      }
    });
  }

  removePathLine() {
    if (this.pathLine) {
      this.scene.remove(this.pathLine);
      this.pathLine.traverse(child => {
        if (child.isMesh) {
          child.geometry.dispose();
          child.material.dispose();
        }
      });
      this.pathLine = null;
    }
  }

  revealType(cube) {
    if (!cube || cube.userData.revealed || cube.userData.type === BLOCK_TYPES.GRASS) return;
    cube.userData.revealed = true;
    cube.material = this.getTypeMaterial(cube.userData.type).map(m => m.clone());
    cube.userData.materials = cube.material;
    this.eachMat(cube.material, m => m.emissiveIntensity = 0.3);
    cube.userData.restoreEmissive = cube.material[0].emissive.getHex();
    cube.userData.restoreIntensity = 0.3;
  }

  retypeCube(index, type) {
    const cube = this.pathCubes[index];
    if (!cube) return;
    cube.userData.type = type;
    cube.userData.isEnd = false;
    cube.userData.revealed = false;
    cube.material = this.getTypeMaterial(type).map(m => m.clone());
    cube.userData.materials = cube.material;
    this.eachMat(cube.material, m => m.emissiveIntensity = 0.15);
    cube.userData.restoreEmissive = cube.material[0].emissive.getHex();
    cube.userData.restoreIntensity = 0.15;
    if (this.endCube === cube) this.endCube = null;
  }

  hintRiseAt(index) {
    const cube = this.pathCubes[index];
    if (!cube) return;
    cube.visible = true;
    cube.userData.hidden = false;
    this.revealType(cube);
    const origColor = [], origEmissive = [], origIntensity = [];
    this.eachMat(cube.material, m => {
      origColor.push(m.color.getHex());
      origEmissive.push(m.emissive.getHex());
      origIntensity.push(m.emissiveIntensity);
      m.color.setHex(0xffd54f);
      m.emissive.setHex(0xff8f00);
      m.emissiveIntensity = 0.6;
    });
    setTimeout(() => {
      this.eachMat(cube.material, (m, i) => {
        m.color.setHex(origColor[i]);
        m.emissive.setHex(origEmissive[i]);
        m.emissiveIntensity = origIntensity[i];
      });
    }, 600);
    const alreadyUp = Math.abs(cube.position.y - cube.userData.normalY) < 0.01;
    if (alreadyUp) return;
    AnimTween.animate(
      cube.position, 'y',
      cube.userData.hiddenY, cube.userData.normalY,
      300, (t) => 1 - Math.pow(1 - t, 3)
    );
  }

  pulseCube(cube, color, emissiveColor, intensity, duration) {
    const start = performance.now();
    const origEmissiveIntensity = 0.15;

    const pulse = () => {
      if (!cube.parent) return;
      const elapsed = (performance.now() - start) % duration;
      const t = elapsed / duration;
      const pulseVal = Math.sin(t * Math.PI * 2) * 0.5 + 0.5;

      this.eachMat(cube.material, m => {
        m.emissiveIntensity = origEmissiveIntensity + pulseVal * intensity;
      });
      const s = 1 + pulseVal * 0.04;
      cube.scale.set(s, s, s);

      requestAnimationFrame(pulse);
    };
    pulse();
  }

  riseCubeAt(index) {
    const cube = this.pathCubes[index];
    if (!cube) return;
    if (window.gameAudio) window.gameAudio.play('cube-rise', 'sfx', 0.6, 120);

    cube.visible = true;
    cube.userData.hidden = false;
    this.revealType(cube);

    const alreadyUp = Math.abs(cube.position.y - cube.userData.normalY) < 0.01;

    if (alreadyUp) return;

    AnimTween.animate(
      cube.position, 'y',
      cube.userData.hiddenY, cube.userData.normalY,
      300, (t) => 1 - Math.pow(1 - t, 3)
    );
  }

  riseDecoyAt(x, z) {
    const cube = this.cubes[`${x},${z}`];
    if (!cube) return;
    if (window.gameAudio) window.gameAudio.play('cube-rise', 'sfx', 0.6);
    cube.visible = true;
    cube.userData.hidden = false;
    cube.userData.revealed = true;
    AnimTween.animate(
      cube.position, 'y',
      cube.userData.hiddenY, cube.userData.normalY,
      300, (t) => 1 - Math.pow(1 - t, 3),
       () => this.flashCube(cube)
    );
  }

  flashCube(cube) {
    const origColor = [], origEmissive = [], origIntensity = [];
    this.eachMat(cube.material, m => {
      origColor.push(m.color.getHex());
      origEmissive.push(m.emissive.getHex());
      origIntensity.push(m.emissiveIntensity);
      m.color.setHex(0xffffff);
      m.emissive.setHex(0x4dd0e1);
      m.emissiveIntensity = 0.6;
    });
    setTimeout(() => {
      this.eachMat(cube.material, (m, i) => {
        m.color.setHex(origColor[i]);
        m.emissive.setHex(origEmissive[i]);
        m.emissiveIntensity = origIntensity[i];
      });
    }, 250);
  }

  blastAt(x, z, onDone) {
    const cube = this.cubes[`${x},${z}`];
    if (!cube) { if (onDone) onDone(); return; }
    const done = typeof onDone === 'function' ? onDone : (() => {});
    this.eachMat(cube.material, m => {
      m.emissive.setHex(0xff8f00);
      m.emissiveIntensity = 1.5;
    });

    const flashGeo = new THREE.SphereGeometry(0.5, 12, 10);
    const flashMat = new THREE.MeshBasicMaterial({
      color: 0xfff3d6,
      transparent: true,
      opacity: 0.95,
      depthWrite: false
    });
    const flash = new THREE.Mesh(flashGeo, flashMat);
    flash.position.copy(cube.position);
    this.scene.add(flash);
    this._blastProps = this._blastProps || [];
    this._blastProps.push(flash);

    AnimTween.animate(flash.scale, 'x', 0.4, 3.2, 450, (t) => t, null);
    AnimTween.animate(flash.scale, 'y', 0.4, 3.2, 450, (t) => t, null);
    AnimTween.animate(flash.scale, 'z', 0.4, 3.2, 450, (t) => t, null);
    AnimTween.animate(flash.material, 'opacity', 0.95, 0, 450, (t) => t, null);
    AnimTween.animate(
      cube.position, 'y',
      cube.position.y, cube.position.y + 0.6,
      150, (t) => t, null
    );
    setTimeout(() => {
      this.scene.remove(flash);
      if (flash.geometry) flash.geometry.dispose();
      if (flash.material) flash.material.dispose();
      cube.visible = false;
      cube.position.y = cube.userData.hiddenY;
      done();
    }, 480);
  }

  clear() {
    this.pathCubes.concat(this.decoyCubes).forEach(cube => {
      this.scene.remove(cube);
      if (cube.userData.materials) {
        this.eachMat(cube.userData.materials, m => m.dispose());
      }
    });
    (this._blastProps || []).forEach(flash => {
      this.scene.remove(flash);
      if (flash.geometry) flash.geometry.dispose();
      if (flash.material) flash.material.dispose();
    });
    this._blastProps = [];
    this.geometries.forEach(g => g.dispose());
    const disposedTextures = new Set();
    Object.values(this.materials).forEach(mats => {
      this.eachMat(mats, m => {
        if (m.map && !disposedTextures.has(m.map)) {
          m.map.dispose();
          disposedTextures.add(m.map);
        }
        m.dispose();
      });
    });
    this.geometries = [];
    this.materials = {};
    this.cubes = {};
    this.pathCubes = [];
    this.decoyCubes = [];
    this.startCube = null;
    this.endCube = null;
  }
}
