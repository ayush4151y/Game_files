class_name CubeGrid
extends Node3D

## Port of CubeGrid.js. Cubes rise out of the grid as the player walks the
## path; block types reveal on first touch; decoy TNT barrels sit beside turns.
## No textures in this port - flat colours from Cfg.

class Cube extends RefCounted:
	var mesh: MeshInstance3D
	var mat: StandardMaterial3D
	var path_index := -1
	var is_start := false
	var is_end := false
	var type := Cfg.T_GRASS
	var revealed := false
	var hidden := true
	var normal_y := Cfg.NORMAL_Y
	var restore_color := Color.WHITE

	func world() -> Vector3:
		return mesh.position


var paused := false
var cancel := false

var _cubes := {}          # Vector2i -> Cube
var _path_cubes: Array[Cube] = []
var _decoy_cubes: Array[Cube] = []
var _pulses: Array = []
var _pulse_t := 0.0
var _tweens: Array[Tween] = []
var _path_line: Node3D


func _process(delta: float) -> void:
	if _pulses.is_empty():
		return
	_pulse_t += delta
	for p in _pulses:
		var t: float = fmod(_pulse_t, p["period"]) / p["period"]
		var v := sin(t * TAU) * 0.5 + 0.5
		p["mat"].emission_enabled = true
		p["mat"].emission_energy_multiplier = 0.15 + v * p["intensity"]
		var s := 1.0 + v * 0.04
		p["mesh"].scale = Vector3(s, s, s)


# --- build -------------------------------------------------------------------

## `start_index` > 0 appends without clearing, so endless mode keeps the islands
## already on the board.
func build_from_path(path: Array[Vector2i], blocks: BlockManager, start_index := 0) -> void:
	if start_index == 0:
		clear()

	var box := BoxMesh.new()
	box.size = Vector3(Cfg.CUBE_SIZE, Cfg.CUBE_SIZE, Cfg.CUBE_SIZE)

	for i in range(start_index, path.size()):
		var pos := path[i]
		if _cubes.has(pos):
			continue
		var is_start := i == 0
		var is_end := i == path.size() - 1
		var type: String = blocks.type_of(i)
		var c := _new_cube(box, pos, Cfg.HIDDEN_Y, Cfg.NORMAL_Y,
			Cfg.T_START if is_start else (Cfg.T_END if is_end else type))
		c.path_index = i
		c.is_start = is_start
		c.is_end = is_end
		c.type = type
		_path_cubes.append(c)
		_cubes[pos] = c

	# JS used a rounded 0.7x0.8x0.7 barrel; plain box is close enough without assets
	var barrel := BoxMesh.new()
	barrel.size = Vector3(0.7, 0.8, 0.7)
	for d in blocks.decoys:
		if _cubes.has(d):
			continue
		var c := _new_cube(barrel, d, Cfg.HIDDEN_Y, 0.4, Cfg.T_TNT)
		c.revealed = true
		_decoy_cubes.append(c)
		_cubes[d] = c


func _new_cube(mesh: Mesh, pos: Vector2i, hidden_y: float, normal_y: float, type: String) -> Cube:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.position = Vector3(pos.x, hidden_y, pos.y)
	mi.visible = false
	add_child(mi)

	var mat := StandardMaterial3D.new()
	mat.albedo_color = Cfg.color_of(type)
	mat.roughness = 0.55

	var c := Cube.new()
	c.mesh = mi
	c.mat = mat
	c.normal_y = normal_y
	c.restore_color = mat.albedo_color
	c.type = type
	mi.material_override = mat
	return c


func cube_at(x: int, z: int) -> Cube:
	return _cubes.get(Vector2i(x, z), null)


func clear() -> void:
	_kill_tweens()
	for c in _path_cubes + _decoy_cubes:
		c.mesh.queue_free()
	remove_path_line()
	_cubes.clear()
	_path_cubes.clear()
	_decoy_cubes.clear()
	_pulses.clear()


# --- reveal / rise -----------------------------------------------------------

func reveal_type(c: Cube) -> void:
	if c == null or c.revealed or c.type == Cfg.T_GRASS:
		return
	c.revealed = true
	c.mat.albedo_color = Cfg.color_of(c.type)
	c.mat.emission_enabled = true
	c.mat.emission = Cfg.color_of(c.type)
	c.mat.emission_energy_multiplier = 0.3
	c.restore_color = c.mat.albedo_color


## Endless mode turns the previous island's goal cube back into plain grass
## before appending the next segment.
func retype_cube(index: int, type: String) -> void:
	var c: Cube = _path_cubes[index] if index >= 0 and index < _path_cubes.size() else null
	if c == null:
		return
	c.type = type
	c.is_end = false
	c.revealed = false
	c.mat.albedo_color = Cfg.color_of(type)
	c.mat.emission_enabled = false
	c.mat.emission_energy_multiplier = 0.15


## JS sinkOldCubes: drop every cube before `keep_index` in parallel, then wait.
func sink_old_cubes(keep_index: int) -> void:
	var slowest := 0.0
	for c in _path_cubes:
		if c.path_index < keep_index:
			c.hidden = true
			_tween_y(c.mesh, c.mesh.position.y, Cfg.HIDDEN_Y, Cfg.CUBE_WAVE_SINK_MS,
				func() -> void: c.mesh.visible = false)
			slowest = Cfg.CUBE_WAVE_SINK_MS
	if slowest > 0.0:
		await get_tree().create_timer(slowest / 1000.0).timeout


func rise_cube_at(index: int) -> void:
	var c: Cube = _path_cubes[index] if index >= 0 and index < _path_cubes.size() else null
	if c == null:
		return
	c.mesh.visible = true
	c.hidden = false
	reveal_type(c)
	if absf(c.mesh.position.y - c.normal_y) < 0.01:
		return
	_tween_y(c.mesh, Cfg.HIDDEN_Y, c.normal_y, Cfg.CUBE_RISE_MS)


func rise_decoy_at(x: int, z: int) -> void:
	var c := cube_at(x, z)
	if c == null:
		return
	c.mesh.visible = true
	c.hidden = false
	c.revealed = true
	_tween_y(c.mesh, Cfg.HIDDEN_Y, c.normal_y, Cfg.CUBE_RISE_MS,
		func() -> void: _flash(c, Cfg.FLASH_COLOR, Cfg.FLASH_EMISSIVE, 0.25))


func hint_rise_at(index: int) -> void:
	var c: Cube = _path_cubes[index] if index >= 0 and index < _path_cubes.size() else null
	if c == null:
		return
	c.mesh.visible = true
	c.hidden = false
	reveal_type(c)
	_flash(c, Cfg.HINT_COLOR, Cfg.HINT_EMISSIVE, 0.6)
	if absf(c.mesh.position.y - c.normal_y) < 0.01:
		return
	_tween_y(c.mesh, Cfg.HIDDEN_Y, c.normal_y, Cfg.CUBE_RISE_MS)


func _flash(c: Cube, color: Color, emissive: Color, hold: float) -> void:
	var prev_color := c.mat.albedo_color
	var prev_emissive_on := c.mat.emission_enabled
	var prev_emissive := c.mat.emission
	var prev_energy := c.mat.emission_energy_multiplier
	c.mat.albedo_color = color
	c.mat.emission_enabled = true
	c.mat.emission = emissive
	c.mat.emission_energy_multiplier = 0.6
	get_tree().create_timer(hold).timeout.connect(func() -> void:
		if not is_instance_valid(c.mesh):
			return
		c.mat.albedo_color = prev_color
		c.mat.emission_enabled = prev_emissive_on
		c.mat.emission = prev_emissive
		c.mat.emission_energy_multiplier = prev_energy)


# --- show / hide waves -------------------------------------------------------

func show_path_wave(start_index := 0) -> void:
	# bounds are re-checked every step: this coroutine awaits, and a new level
	# can clear or rebuild the grid underneath it while it is suspended
	var i := start_index
	while i < _path_cubes.size():
		while paused:
			await get_tree().create_timer(0.1).timeout
			if cancel:
				return
		if cancel or i >= _path_cubes.size():
			return
		var c := _path_cubes[i]
		c.mesh.visible = true
		c.hidden = false
		_tween_y(c.mesh, Cfg.HIDDEN_Y, c.normal_y, Cfg.CUBE_WAVE_RISE_MS)
		await get_tree().create_timer(Cfg.WAVE_RISE_STEP_S).timeout
		i += 1


func hide_path_wave(skip_start_end := true, start_index := 0) -> void:
	var i := start_index
	while i < _path_cubes.size():
		if cancel or i >= _path_cubes.size():
			return
		var c := _path_cubes[i]
		i += 1
		if skip_start_end and (c.is_start or c.is_end):
			continue
		c.hidden = true
		_tween_y(c.mesh, c.mesh.position.y, Cfg.HIDDEN_Y, Cfg.CUBE_WAVE_SINK_MS,
			func() -> void: c.mesh.visible = false)
		await get_tree().create_timer(Cfg.WAVE_SINK_STEP_S).timeout


# --- path line ---------------------------------------------------------------

## JS draws a TubeGeometry (0.1 radius, 12 sides) along a CatmullRomCurve3 through
## the path cells. Curve3D bakes the same smoothing; the ring sweep below builds
## the tube. Per-cell boxes looked wrong: they drew a 1-unit stick across every
## block instead of following the path.
func draw_path_line(path: Array[Vector2i], start_index := 0) -> void:
	remove_path_line()
	if path.size() - start_index < 2:
		return
	var line := MeshInstance3D.new()
	line.name = "PathLine"
	line.mesh = _tube_mesh(path, start_index)
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Cfg.PATH_LINE_COLOR
	mat.emission_enabled = true
	mat.emission = Cfg.PATH_LINE_COLOR
	mat.emission_energy_multiplier = 0.6
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.albedo_color.a = 0.9
	line.material_override = mat
	add_child(line)
	_path_line = line


const TUBE_SEGMENTS := 64
const TUBE_SIDES := 12


func _tube_mesh(path: Array[Vector2i], start_index := 0) -> ArrayMesh:
	var pts := PackedVector3Array()
	for i in range(start_index, path.size()):
		var p := path[i]
		pts.append(Vector3(p.x, Cfg.PATH_LINE_Y, p.y))

	# uniform Catmull-Rom: c1 = p + m/3, c2 = q - m/3, so the tube rounds the
	# 90-degree corners instead of pinching at them
	var curve := Curve3D.new()
	for i in pts.size():
		var before: Vector3 = pts[maxi(i - 1, 0)]
		var after: Vector3 = pts[mini(i + 1, pts.size() - 1)]
		var tangent := (after - before) / 6.0
		curve.add_point(pts[i], -tangent, tangent)
	curve.bake_interval = 1.0

	var total := curve.get_baked_length()
	if total <= 0.0:
		total = float(pts.size() - 1)
	var center := PackedVector3Array()
	for i in TUBE_SEGMENTS + 1:
		center.append(curve.sample_baked(total * float(i) / float(TUBE_SEGMENTS)))

	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var side := Cfg.PATH_LINE_R
	for i in center.size():
		var prev: Vector3 = center[maxi(i - 1, 0)]
		var next: Vector3 = center[mini(i + 1, center.size() - 1)]
		var fwd := (next - prev).normalized()
		if fwd.length_squared() < 0.0001:
			fwd = Vector3.FORWARD
		var up := Vector3.UP if absf(fwd.dot(Vector3.UP)) < 0.95 else Vector3.RIGHT
		var right := fwd.cross(up).normalized()
		var real_up := right.cross(fwd).normalized()
		for j in TUBE_SIDES:
			var a := TAU * float(j) / float(TUBE_SIDES)
			var n := (right * cos(a) + real_up * sin(a)).normalized()
			verts.append(center[i] + n * side)
			norms.append(n)

	var idx := PackedInt32Array()
	for i in center.size() - 1:
		for j in TUBE_SIDES:
			var a := i * TUBE_SIDES + j
			var b := i * TUBE_SIDES + (j + 1) % TUBE_SIDES
			idx.append_array([a, b, a + TUBE_SIDES, b, b + TUBE_SIDES, a + TUBE_SIDES])

	var arrays := []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = norms
	arrays[Mesh.ARRAY_INDEX] = idx

	var am := ArrayMesh.new()
	am.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	return am


func remove_path_line() -> void:
	if _path_line != null and is_instance_valid(_path_line):
		_path_line.queue_free()
	_path_line = null


# --- idle pulses -------------------------------------------------------------

func start_idle_animations() -> void:
	for c in _path_cubes:
		if c.is_start:
			_pulse(c, Cfg.START_PULSE_COLOR, Cfg.START_PULSE_EMISSIVE, 0.3, Cfg.START_PULSE_MS)
		elif c.is_end:
			_pulse(c, Cfg.END_PULSE_COLOR, Cfg.END_PULSE_EMISSIVE, 0.3, Cfg.END_PULSE_MS)


func _pulse(c: Cube, color: Color, emissive: Color, intensity: float, period: float) -> void:
	c.mat.albedo_color = color
	c.mat.emission_enabled = true
	c.mat.emission = emissive
	_pulses.append({"mesh": c.mesh, "mat": c.mat, "intensity": intensity, "period": period})


# --- blast -------------------------------------------------------------------

func blast_at(x: int, z: int) -> void:
	var c := cube_at(x, z)
	if c == null:
		return
	c.mat.emission_enabled = true
	c.mat.emission = Cfg.HINT_EMISSIVE
	c.mat.emission_energy_multiplier = 1.5

	var flash := MeshInstance3D.new()
	var sphere := SphereMesh.new()
	sphere.radius = 0.5
	sphere.height = 1.0
	sphere.radial_segments = 12
	sphere.rings = 10
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(1.0, 0.953, 0.839)
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sphere.material = mat
	flash.mesh = sphere
	flash.position = c.mesh.position
	flash.scale = Vector3.ONE * 0.4
	add_child(flash)

	var tw := _track(create_tween()).set_parallel(true)
	tw.tween_property(flash, "scale", Vector3.ONE * 3.2, 0.45)
	tw.tween_property(mat, "albedo_color:a", 0.0, 0.45)
	tw.tween_property(c.mesh, "position:y", c.mesh.position.y + 0.6, 0.15)

	get_tree().create_timer(0.48).timeout.connect(func() -> void:
		if is_instance_valid(flash):
			flash.queue_free()
		if is_instance_valid(c.mesh):
			c.mesh.visible = false
			c.mesh.position.y = Cfg.HIDDEN_Y)


# --- tween plumbing ----------------------------------------------------------

func _track(tw: Tween) -> Tween:
	_tweens.append(tw)
	tw.finished.connect(func() -> void: _tweens.erase(tw))
	return tw


func _kill_tweens() -> void:
	for tw in _tweens:
		if tw.is_valid():
			tw.kill()
	_tweens.clear()


func _tween_y(node: Node3D, from_y: float, to_y: float, ms: float, on_done := Callable()) -> void:
	var tw := _track(create_tween())
	tw.tween_method(func(v: float) -> void: node.position.y = v,
		from_y, to_y, ms / 1000.0).set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
	if on_done.is_valid():
		tw.tween_callback(on_done)