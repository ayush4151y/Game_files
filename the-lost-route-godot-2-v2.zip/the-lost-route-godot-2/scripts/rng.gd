class_name Rng
extends RefCounted

## Exact ports of the JS random sources used by the original game.
## JS bit ops are 32-bit; GDScript ints are 64-bit, so every op that JS
## performs with `& 0xffffffff` / `| 0` is emulated here.
## ponytail: only the two generators the game actually uses.

const U32 := 0xffffffff
const I32 := 0x100000000


static func to_int32(v: int) -> int:
	var m := v & U32
	return m - I32 if m >= 0x80000000 else m


## Math.imul - 32-bit signed multiply with wraparound.
static func imul32(a: int, b: int) -> int:
	return to_int32(a * b)


## hash2(x, z) -> uint32, used for per-island / per-cell decor seeds.
static func hash2(x: int, z: int) -> int:
	var h := (imul32(x, 73856093) ^ imul32(z, 19349663)) & U32
	h = imul32(h ^ (h >> 13), 0x7feb352d) & U32
	return (h ^ (h >> 16)) & U32


enum { LCG, MULBERRY }

var kind := LCG
var state := 0


## SeededRandom: (seed * 1664525 + 1013904223) & 0xffffffff
static func lcg(seed: int) -> Rng:
	var r := Rng.new()
	r.kind = LCG
	r.state = seed & U32
	return r


## mulberry32
static func mulberry(seed: int) -> Rng:
	var r := Rng.new()
	r.kind = MULBERRY
	r.state = seed & U32
	return r


func next() -> float:
	if kind == LCG:
		state = (state * 1664525 + 1013904223) & U32
		return float(state) / 4294967295.0
	state = to_int32(state + 0x6D2B79F5)
	var r := imul32(state ^ ((state & U32) >> 15), 1 | state)
	r = to_int32(r + imul32(r ^ ((r & U32) >> 7), 61 | r)) ^ r
	return float((r ^ ((r & U32) >> 14)) & U32) / 4294967296.0