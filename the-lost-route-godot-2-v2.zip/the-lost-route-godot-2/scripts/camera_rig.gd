class_name CameraRig
extends Node3D

## Port of GameManager.adjustCameraToPath / frameCameraAt / rotateView /
## screenToWorld. Distance is found by binary-searching the yaw-aware NDC fit
## function so the whole path fills ~88% of the screen at a 45 deg pitch.

var camera: Camera3D
var cam_yaw := 0.0
var cam_distance := 20.0
var cam_segment_start := 0
var cam_segment_end := 0

var _frame := {}
var _center := Vector3.ZERO
var _anim_seq := 0
var _tween: Tween


func setup(cam: Camera3D) -> void:
	camera = cam
	camera.fov = Cfg.CAM_FOV
	camera.keep_aspect = Camera3D.KEEP_HEIGHT


func adjust_camera_to_path(path: Array[Vector2i], range_start := 0, range_end := -1) -> void:
	if camera == null or path.is_empty():
		return
	var end := range_end if range_end >= 0 else path.size() - 1
	end = mini(end, path.size() - 1)
	if end < range_start:
		return

	var min_x := INF
	var max_x := -INF
	var min_z := INF
	var max_z := -INF
	for i in range(range_start, end + 1):
		var p := path[i]
		min_x = minf(min_x, float(p.x))
		max_x = maxf(max_x, float(p.x))
		min_z = minf(min_z, float(p.y))
		max_z = maxf(max_z, float(p.y))

	var cx := (min_x + max_x) * 0.5
	var cz := (min_z + max_z) * 0.5
	_center = Vector3(cx, 0.0, cz)

	var vfov := deg_to_rad(camera.fov)
	var aspect := 1.0
	var vp := get_viewport()
	if vp != null and vp.size.y > 0:
		aspect = maxf(float(vp.size.x) / float(vp.size.y), 0.3)
	var hfov := 2.0 * atan(tan(vfov * 0.5) * aspect)

	var theta := deg_to_rad(Cfg.CAM_PITCH)
	var yaw := deg_to_rad(cam_yaw)
	var s := sin(theta)
	var c := cos(theta)
	var sin_y := sin(yaw)
	var cos_y := cos(yaw)
	var tan_v := tan(vfov * 0.5)
	var tan_h := tan(hfov * 0.5)
	var target := Cfg.CAM_SCREEN_FILL * 0.98
	var ext := Cfg.CAM_FIT_EXT
	var xs := [min_x - ext, max_x + ext]
	var zs := [min_z - ext, max_z + ext]

	var fit_ndc := func(d: float) -> float:
		var g := d * c
		var cam := Vector3(cx + sin_y * g, d * s, cz + cos_y * g)
		var fx := -sin_y * c
		var fy := -s
		var fz := -cos_y * c
		var rx := cos_y
		var rz := -sin_y
		var ux := -s * sin_y
		var uy := c
		var uz := -s * cos_y
		var max_n := 0.0
		for xi in range(2):
			for zi in range(2):
				for yi in range(2):
					var w := Vector3(xs[xi], 0.0 if yi == 0 else Cfg.CAM_FIT_TOP_Y, zs[zi])
					var v := w - cam
					var depth := v.x * fx + v.y * fy + v.z * fz
					if depth <= 0.001:
						return 1e9
					var unx := absf((v.x * rx + v.z * rz) / (depth * tan_h))
					var uny := absf((v.x * ux + v.y * uy + v.z * uz) / (depth * tan_v))
					max_n = maxf(max_n, maxf(unx, uny))
		return max_n

	var lo := Cfg.CAM_MIN_DISTANCE
	var hi := maxf(Cfg.CAM_MAX_DISTANCE * 1.8, 80.0)
	for _i in range(Cfg.CAM_FIT_ITERS):
		var mid := (lo + hi) * 0.5
		if fit_ndc.call(mid) <= target:
			hi = mid
		else:
			lo = mid
	var vd := hi
	if fit_ndc.call(Cfg.CAM_MIN_DISTANCE) <= target:
		vd = Cfg.CAM_MIN_DISTANCE
	vd = clampf(vd, Cfg.CAM_MIN_DISTANCE, Cfg.CAM_MAX_DISTANCE)

	cam_distance = vd
	_frame = {"min_x": min_x, "max_x": max_x, "min_z": min_z, "max_z": max_z}
	frame_camera_at(vd, cx, cz, range_start, end)


func frame_camera_at(vd: float, cx: float, cz: float, range_start: int, end: int) -> void:
	cam_segment_start = range_start
	cam_segment_end = end
	_center = Vector3(cx, 0.0, cz)

	var theta := deg_to_rad(Cfg.CAM_PITCH)
	var yaw := deg_to_rad(cam_yaw)
	var s := sin(theta)
	var c := cos(theta)
	var to := Vector3(cx + sin(yaw) * (vd * c), vd * s, cz + cos(yaw) * (vd * c))
	var from := camera.position

	_anim_seq += 1
	var seq := _anim_seq
	if _tween != null and _tween.is_valid():
		_tween.kill()
	_tween = create_tween()
	_tween.tween_method(func(t: float) -> void:
		if seq != _anim_seq:
			return
		camera.position = from.lerp(to, t)
		camera.look_at(_center, Vector3.UP)
	, 0.0, 1.0, Cfg.CAM_ANIM_MS / 1000.0).set_ease(Tween.EASE_IN_OUT).set_trans(Tween.TRANS_CUBIC)


func rotate_view(delta := 90.0) -> void:
	if camera == null or _frame.is_empty():
		return
	cam_yaw = fmod(cam_yaw + delta, 360.0)
	if cam_yaw < 0.0:
		cam_yaw += 360.0
	var cx := (float(_frame["min_x"]) + float(_frame["max_x"])) * 0.5
	var cz := (float(_frame["min_z"]) + float(_frame["max_z"])) * 0.5
	frame_camera_at(cam_distance, cx, cz, cam_segment_start, cam_segment_end)


## Screen direction -> world grid direction, using the current camera yaw.
func screen_to_world(direction: String) -> String:
	var yaw := deg_to_rad(cam_yaw)
	var r := Vector2(cos(yaw), -sin(yaw))
	var u := Vector2(-sin(yaw), -cos(yaw))
	var v := Vector2.ZERO
	match direction:
		"up": v = u
		"down": v = -u
		"right": v = r
		"left": v = -r
		_: return direction
	if v.y == -1.0:
		return "up"
	if v.y == 1.0:
		return "down"
	if v.x == 1.0:
		return "right"
	return "left"