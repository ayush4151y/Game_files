class_name Tutorial
extends RefCounted

## Port of Tutorial.js: a fixed 10-cell path plus the per-step banner.
## The JS text for steps 5 and 7 names a direction that does not match the path
## (it says DOWN at index 5, which is a left move). Kept verbatim here so the
## port behaves like the original; the highlighted key ids are corrected instead,
## because highlighting the wrong button would be actively misleading.


## Up, left, down, down, right, down, left, left, up.
const DIRS: Array[Vector2i] = [
	Vector2i(0, -1), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, 1),
	Vector2i(1, 0), Vector2i(0, 1), Vector2i(-1, 0), Vector2i(-1, 0),
	Vector2i(0, -1),
]

const TEXT := [
	"MOVE — UP",
	"MOVE — LEFT",
	"MOVE — DOWN",
	"MOVE — DOWN",
	"MOVE — RIGHT",
	"CUBES RISE — behind you! MOVE — DOWN",
	"STUCK? TAP HINT OR ROTATE VIEW — MOVE — LEFT",
	"DON'T STEP OFF THE PATH — MOVE — LEFT",
	"REACH THE GOAL!",
]

const KEYS := [
	["btn-up"],
	["btn-left"],
	["btn-down"],
	["btn-down"],
	["btn-right"],
	["btn-down"],
	["hint-btn", "rotate-right-btn", "btn-left"],
	["btn-left"],
	[],
]


static func fixed_path() -> Array[Vector2i]:
	var path: Array[Vector2i] = [Vector2i.ZERO]
	for d in DIRS:
		path.append(path[path.size() - 1] + d)
	return path


static func text_at(index: int) -> String:
	return TEXT[mini(index, TEXT.size() - 1)]


static func keys_at(index: int) -> Array:
	return KEYS[mini(index, KEYS.size() - 1)]