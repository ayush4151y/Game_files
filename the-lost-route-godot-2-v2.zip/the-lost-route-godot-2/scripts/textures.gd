class_name Textures
extends RefCounted

## Procedural textures for the island, generated at load time.
##
## The port painted every surface a flat hex, which is what makes the islands
## read as untextured blockout rather than terrain. Baking small noise images
## once costs a few milliseconds and nothing at runtime, and keeps the ZIP free
## of binary image assets.

static var _cache := {}


static func grain(base: Color, amount: float, scale: int, size := 128) -> ImageTexture:
	var key := "%s_%s_%d_%d" % [base.to_html(), str(amount), scale, size]
	if _cache.has(key):
		return _cache[key]
	var img := Image.create_empty(size, size, false, Image.FORMAT_RGBA8)
	var rng := Rng.mulberry(int(base.to_rgba32()) + size)
	# value noise: a coarse random lattice, bilinearly interpolated and summed
	# over a few octaves, so the result has both grain and larger blotches
	var octaves := []
	var cells := scale
	for _o in range(3):
		octaves.append({"n": cells, "g": []})
		for _i in range(cells * cells):
			octaves[-1]["g"].append(rng.next())
		cells = maxi(2, cells * 2)
	for y in range(size):
		for x in range(size):
			var v := 0.0
			var w := 1.0
			var total := 0.0
			for o in octaves:
				v += _sample(o["n"], o["g"], float(x) / float(size), float(y) / float(size)) * w
				total += w
				w *= 0.5
			v /= total
			# pull toward the base colour, keeping it recognisably the same hue
			var c := base.lerp(Color(1, 1, 1) if v > 0.5 else Color(0, 0, 0), absf(v - 0.5) * 2.0 * amount)
			img.set_pixel(x, y, c)
	var tex := ImageTexture.create_from_image(img)
	_cache[key] = tex
	return tex


static func _sample(n: int, g: Array, u: float, v: float) -> float:
	var fx := u * float(n)
	var fy := v * float(n)
	var x0 := int(fx) % n
	var y0 := int(fy) % n
	var x1 := (x0 + 1) % n
	var y1 := (y0 + 1) % n
	var tx := fx - floorf(fx)
	var ty := fy - floorf(fy)
	# smoothstep so the blotches do not show the lattice as diamonds
	tx = tx * tx * (3.0 - 2.0 * tx)
	ty = ty * ty * (3.0 - 2.0 * ty)
	var a: float = g[y0 * n + x0]
	var b: float = g[y0 * n + x1]
	var c: float = g[y1 * n + x0]
	var d: float = g[y1 * n + x1]
	return lerpf(lerpf(a, b, tx), lerpf(c, d, tx), ty)


## Two-tone tile for the sea: deep water with lighter crest blotches.
static func sea(size := 128) -> ImageTexture:
	if _cache.has("sea"):
		return _cache["sea"]
	var deep := Color(0.055, 0.243, 0.353)
	var img := grain(deep, 0.55, 4, size).get_image()
	var rng := Rng.mulberry(7)
	for _i in range(int(size * 0.6)):
		var x := int(rng.next() * float(size))
		var y := int(rng.next() * float(size))
		var r := 1 + int(rng.next() * 4.0)
		for dy in range(-r, r + 1):
			for dx in range(-r, r + 1):
				if dx * dx + dy * dy > r * r:
					continue
				img.set_pixel((x + dx + size) % size, (y + dy + size) % size,
					Color(0.71, 0.87, 0.92, 0.55))
	var tex := ImageTexture.create_from_image(img)
	_cache["sea"] = tex
	return tex