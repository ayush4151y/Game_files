extends Node3D

## Scene assembly. Every system is built from code, so main.tscn stays an empty
## root and there is no editor-side setup to drift out of sync with the scripts.


func _ready() -> void:
	var world := Node3D.new()
	world.name = "World"
	add_child(world)

	var sun := DirectionalLight3D.new()
	sun.name = "Sun"
	sun.rotation_degrees = Vector3(-52.0, -38.0, 0.0)
	sun.light_energy = 1.15
	sun.light_color = Color(1.0, 0.972, 0.906)
	sun.shadow_enabled = true
	add_child(sun)

	var environment := EnvironmentBuilder.new()
	environment.name = "Environment"
	add_child(environment)
	environment.build()

	var island_builder := IslandBuilder.new()
	island_builder.name = "Islands"
	world.add_child(island_builder)

	var cube_grid := CubeGrid.new()
	cube_grid.name = "Cubes"
	world.add_child(cube_grid)

	var player := Player.new()
	player.name = "Player"
	world.add_child(player)

	var camera := Camera3D.new()
	camera.name = "Camera"
	world.add_child(camera)
	var camera_rig := CameraRig.new()
	camera_rig.name = "CameraRig"
	world.add_child(camera_rig)
	camera_rig.setup(camera)

	var ui := UI.new()
	ui.name = "UI"
	add_child(ui)

	var gm := GameManager.new()
	gm.name = "Game"
	add_child(gm)
	gm.environment = environment
	gm.island_builder = island_builder
	gm.cube_grid = cube_grid
	gm.player = player
	gm.camera_rig = camera_rig
	gm.ui = ui
	ui.build(gm)

	# JS boots straight into the menu; the first campaign level is reached from
	# there. The tutorial only auto-starts when it has never been completed.
	if not Save.tutorial_seen():
		gm.launch_tutorial()
	else:
		gm.back_to_menu()