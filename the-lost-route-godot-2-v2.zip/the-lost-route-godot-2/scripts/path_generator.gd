class_name PathGenerator
extends RefCounted

## Port of PathGenerator.js - identical rules, identical RNG consumption.

const DIRS: Array[Vector2i] = [
	Vector2i(0, -1), Vector2i(0, 1), Vector2i(-1, 0), Vector2i(1, 0),
]


func generate(length: int, seed: int, turn_bias: float, min_turns: int,
		avoid := PackedStringArray(), start_pos := Vector2i.ZERO,
		pull: Variant = null) -> Array[Vector2i]:
	var last: Array[Vector2i] = []
	for attempt in range(40):
		var bias: float = min(turn_bias + attempt * 0.08, 0.9)
		var result := try_generate(length, seed + attempt * 7919, bias, avoid, start_pos, pull)
		if not result.is_empty() and count_turns(result) >= min_turns:
			return result
		if not result.is_empty():
			last = result
	if last.is_empty():
		# safety net: JS would hand a null path back and crash later
		last = try_generate(length, seed, turn_bias, avoid, start_pos, pull)
	return last


func count_turns(path: Array[Vector2i]) -> int:
	var turns := 0
	for i in range(2, path.size()):
		if path[i] - path[i - 1] != path[i - 1] - path[i - 2]:
			turns += 1
	return turns


func try_generate(length: int, seed: int, turn_bias: float,
		avoid := PackedStringArray(), start_pos := Vector2i.ZERO,
		pull: Variant = null) -> Array[Vector2i]:
	var rng := Rng.lcg(seed)
	var path: Array[Vector2i] = [start_pos]
	var visited := {}
	for k in avoid:
		visited[k] = true
	visited[key(start_pos)] = true
	var last_dir := Vector2i.ZERO
	var has_dir := false
	var has_pull := pull != null

	# JS weighted(): with a pull target, prefer the candidate furthest from it
	# (steers the endless segment away from the run origin)
	var weighted := func(candidates: Array[Vector2i]) -> Vector2i:
		if not has_pull or candidates.size() < 2:
			return candidates[pick(candidates.size(), rng)]
		var here := path[path.size() - 1]
		var best := candidates[0]
		var best_d := -INF
		for c in candidates:
			var n := here + c
			var d := float(n.x - pull.x) * float(n.x - pull.x) + float(n.y - pull.y) * float(n.y - pull.y)
			if d > best_d:
				best_d = d
				best = c
		return best

	for _i in range(length):
		var current := path[path.size() - 1]
		var available: Array[Vector2i] = []
		for d in DIRS:
			if has_dir and d == -last_dir:
				continue
			if visited.has(key(current + d)):
				continue
			available.append(d)
		if available.is_empty():
			return []

		var chosen := Vector2i.ZERO
		var got := false
		if has_dir and turn_bias > 0.0 and available.size() > 1:
			var straight := Vector2i.ZERO
			var turns: Array[Vector2i] = []
			for d in available:
				if d == last_dir:
					straight = d
				else:
					turns.append(d)
			if not turns.is_empty() and rng.next() < turn_bias:
				chosen = weighted.call(turns)
				got = true
			elif straight != Vector2i.ZERO:
				chosen = straight
				got = true
		if not got:
			chosen = weighted.call(available)
		last_dir = chosen
		has_dir = true

		path.append(current + chosen)
		visited[key(path[path.size() - 1])] = true

	return path


static func key(p: Vector2i) -> String:
	return str(p.x) + "," + str(p.y)


## Math.floor(rng.next() * n), clamped: next() can return exactly 1.0 when
## the LCG state hits 0xffffffff and would index one past the end.
static func pick(n: int, rng: Rng) -> int:
	return mini(int(rng.next() * n), n - 1)