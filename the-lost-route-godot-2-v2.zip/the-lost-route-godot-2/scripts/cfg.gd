class_name Cfg
extends RefCounted

## Tuning values copied verbatim from the original JS modules.

# --- cube grid / player placement -------------------------------------------
const CUBE_SIZE := 0.9
const HIDDEN_Y := -0.8
const NORMAL_Y := 0.5
const PLAYER_Y := 1.2
const CUBE_RISE_MS := 300.0
const CUBE_WAVE_RISE_MS := 250.0
const CUBE_WAVE_SINK_MS := 200.0
const WAVE_RISE_STEP_S := 0.1
const WAVE_SINK_STEP_S := 0.08
const PATH_LINE_Y := 0.98
const PATH_LINE_R := 0.1
const PATH_LINE_COLOR := Color(1.0, 0.427, 0.0)

# --- player ------------------------------------------------------------------
const PLAYER_MOVE_MS := 200.0
const PLAYER_MOVE_BOUNCE := 0.15
const PLAYER_IDLE_PULSE_MS := 800.0

# --- block timings -----------------------------------------------------------
const ICE_SLIDE_TIME := 2.0
const FIRE_BUDGET := 3.0
const TNT_FUSE_TIME := 3.0
const FIRE_WARN_STEP := 0.22

# --- misc --------------------------------------------------------------------
const STUCK_HINT_MS := 3000.0
const MOVE_LOCK_S := 0.25
const SWIPE_MIN_PX := 30.0
const MAX_HEARTS := 3

# --- camera ------------------------------------------------------------------
const CAM_MIN_DISTANCE := 7.0
const CAM_MAX_DISTANCE := 120.0
const CAM_PADDING := 1.2
const CAM_ANIM_MS := 600.0
const CAM_PITCH := 45.0
const CAM_SCREEN_FILL := 0.9
const CAM_FOV := 45.0
const CAM_FIT_TOP_Y := 2.4
const CAM_FIT_EXT := 2.0
const CAM_FIT_ITERS := 40

# --- colours (from CUBE_MATERIALS in CubeGrid.js) ---------------------------
const COLOR_GRASS := Color(0.298, 0.686, 0.314)
const COLOR_ICE := Color(0.129, 0.588, 0.953)
const COLOR_FIRE := Color(1.0, 0.596, 0.0)
const COLOR_TNT := Color(0.718, 0.110, 0.110)
const COLOR_HEART := Color(0.914, 0.118, 0.388)
# no textures in this port, so start/end get their own tints (JS relied on
# start_top/end_top images). JS still pulses these cubes green / red.
const COLOR_START := Color(0.431, 0.878, 0.431)
const COLOR_END := Color(1.0, 0.42, 0.42)

const START_PULSE_COLOR := Color(0.298, 0.686, 0.314)
const START_PULSE_EMISSIVE := Color(0.180, 0.490, 0.196)
const START_PULSE_MS := 1200.0
const END_PULSE_COLOR := Color(1.0, 0.322, 0.322)
const END_PULSE_EMISSIVE := Color(0.827, 0.196, 0.196)
const END_PULSE_MS := 900.0

const HINT_COLOR := Color(1.0, 0.835, 0.310)
const HINT_EMISSIVE := Color(1.0, 0.561, 0.0)
const FLASH_COLOR := Color(1.0, 1.0, 1.0)
const FLASH_EMISSIVE := Color(0.302, 0.816, 0.882)

# --- block types -------------------------------------------------------------
const T_GRASS := "grass"
const T_ICE := "ice"
const T_FIRE := "fire"
const T_TNT := "tnt"
const T_HEART := "heart"
const T_START := "start"
const T_END := "end"

# LEVEL_TIERS from BlockManager.js. ice/fire/heart are either a constant
# (float) or a [from, to] ramp across the tier; tnt is a constant.
const LEVEL_TIERS := [
	{"start": 1, "end": 20, "ice": 0.0, "fire": 0.0, "tnt": 0.0, "heart": 0.0},
	{"start": 21, "end": 50, "ice": [0.12, 0.20], "fire": 0.0, "tnt": 0.5, "heart": 0.0},
	{"start": 51, "end": 100, "ice": [0.20, 0.30], "fire": [0.10, 0.25], "tnt": 0.4, "heart": 0.0},
	{"start": 101, "end": 200, "ice": [0.30, 0.40], "fire": [0.25, 0.40], "tnt": 0.35, "heart": 0.08},
]

# PATH_RANGES from GameManager.getPathLength
const PATH_RANGES := [
	{"min": 1, "max": 20, "len_min": 5, "len_max": 8},
	{"min": 21, "max": 50, "len_min": 8, "len_max": 13},
	{"min": 51, "max": 100, "len_min": 9, "len_max": 18},
	{"min": 101, "max": 150, "len_min": 15, "len_max": 22},
	{"min": 151, "max": 200, "len_min": 19, "len_max": 25},
]


static func dir_vec(name: String) -> Vector2i:
	match name:
		"up": return Vector2i(0, -1)
		"down": return Vector2i(0, 1)
		"left": return Vector2i(-1, 0)
		"right": return Vector2i(1, 0)
	return Vector2i.ZERO


## Direction name for a grid step, "" when not a single orthogonal step.
static func dir_between(from: Vector2i, to: Vector2i) -> String:
	var d := to - from
	if d == Vector2i(1, 0): return "right"
	if d == Vector2i(-1, 0): return "left"
	if d == Vector2i(0, -1): return "up"
	if d == Vector2i(0, 1): return "down"
	return ""


static func opposite(name: String) -> String:
	match name:
		"up": return "down"
		"down": return "up"
		"left": return "right"
		"right": return "left"
	return ""


static func color_of(type: String) -> Color:
	match type:
		T_ICE: return COLOR_ICE
		T_FIRE: return COLOR_FIRE
		T_TNT: return COLOR_TNT
		T_HEART: return COLOR_HEART
		T_START: return COLOR_START
		T_END: return COLOR_END
	return COLOR_GRASS