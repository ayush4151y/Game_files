class_name Icons
extends RefCounted

## Icons for the HUD buttons, drawn into Images at runtime.
##
## Godot's built-in font has no geometric-shape glyphs, so the port used ASCII
## stand-ins ("^", "v", "<", ">") which read as junk on a phone. Rasterising the
## shapes ourselves is about the same amount of code and gives real glyphs, and
## it keeps the ZIP asset-free: nothing to download, nothing to go missing.

const SS := 4  # supersampling, so the edges are not jagged
static var _cache := {}

const INK := Color(0.118, 0.176, 0.235)


static func _canvas() -> Image:
	var img := Image.create_empty(64 * SS, 64 * SS, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	return img


static func get_icon(name: String) -> Texture2D:
	if _cache.has(name):
		return _cache[name]
	var img := _canvas()
	match name:
		"up": _tri(img, 32, 10, 54, 52, 10, 52)
		"down": _tri(img, 32, 54, 54, 12, 10, 12)
		"left": _tri(img, 10, 32, 52, 54, 52, 10)
		"right": _tri(img, 54, 32, 12, 10, 12, 54)
		"pause": _rect(img, 15, 14, 27, 50); _rect(img, 37, 14, 49, 50)
		"play": _tri(img, 20, 12, 52, 32, 20, 52)
		"skip": _tri(img, 12, 16, 38, 32, 12, 48); _rect(img, 43, 14, 51, 50)
		"rotate": _arrow_around(img, 32, 33, 17.0, -50.0, 225.0)
		"close": _line(img, 17, 17, 47, 47, 8.0); _line(img, 47, 17, 17, 47, 8.0)
		"hint": _disc(img, 32, 26, 15.0); _rect(img, 25, 40, 39, 45); _rect(img, 27, 47, 37, 52)
		"home": _tri(img, 32, 7, 58, 32, 6, 32); _rect(img, 15, 30, 49, 55)
		"lock": _rect(img, 15, 30, 49, 55); _arc(img, 32, 31, 11.0, 180.0, 360.0, 6.0)
		"check": _line(img, 15, 33, 28, 46, 9.0); _line(img, 28, 46, 50, 20, 9.0)
		"star": _star(img, 32, 32, 21.0)
		"skip_": _tri(img, 16, 14, 42, 32, 16, 50); _tri(img, 42, 14, 68, 32, 42, 50)
		_: _disc(img, 32, 32, 12.0)
	img.resize(64, 64, Image.INTERPOLATE_LANCZOS)
	var tex := ImageTexture.create_from_image(img)
	_cache[name] = tex
	return tex


## Applies an icon to a button and drops the text, keeping it centred.
static func dress(b: Button, name: String, tint := Color(1, 1, 1)) -> void:
	b.text = ""
	b.icon = get_icon(name)
	b.expand_icon = true
	b.add_theme_color_override("icon_normal_color", tint)
	b.add_theme_color_override("icon_hover_color", tint)
	b.add_theme_color_override("icon_pressed_color", tint)
	# expand_icon stretches to fill, which distorts; keep it at the button size
	b.expand_icon = false
	b.add_theme_constant_override("icon_max_width", int(minf(b.custom_minimum_size.x, b.custom_minimum_size.y) * 0.62))


## Centred icon that scales with the button, for boxes that are laid out after
## build() and so have no size yet.
static func fit(b: Button, name: String, tint := Color(1, 1, 1)) -> void:
	dress(b, name, tint)
	if not b.resized.is_connected(_refit.bind(b)):
		b.resized.connect(_refit.bind(b))
	b.resized.emit()


static func _refit(b: Button) -> void:
	b.add_theme_constant_override("icon_max_width",
		int(maxf(12.0, minf(b.size.x, b.size.y) * 0.62)))


# --- rasterisers (all coordinates are in the 0..64 design grid) ---------------

static func _px(img: Image, x: int, y: int, c: Color) -> void:
	if x >= 0 and y >= 0 and x < img.get_width() and y < img.get_height():
		img.set_pixel(x, y, c)


static func _rect(img: Image, x0: float, y0: float, x1: float, y1: float, c := INK) -> void:
	for y in range(int(y0 * SS), int(y1 * SS)):
		for x in range(int(x0 * SS), int(x1 * SS)):
			img.set_pixel(x, y, c)


static func _disc(img: Image, cx: float, cy: float, r: float, c := INK) -> void:
	for y in range(int((cy - r) * SS), int((cy + r + 1) * SS)):
		for x in range(int((cx - r) * SS), int((cx + r + 1) * SS)):
			if Vector2(x, y).distance_to(Vector2(cx * SS, cy * SS)) <= r * SS:
				img.set_pixel(x, y, c)


static func _tri(img: Image, ax: float, ay: float, bx: float, by: float, cx: float, cy: float,
		col := INK) -> void:
	# everything in design units, then multiply by SS on the way to pixels, so
	# the winding test never mixes spaces
	var det := (by - cy) * (ax - cx) + (cx - bx) * (ay - cy)
	if is_zero_approx(det):
		return
	var min_x := int(floorf(minf(ax, minf(bx, cx)))) * SS - 1
	var max_x := int(ceilf(maxf(ax, maxf(bx, cx)))) * SS + 1
	var min_y := int(floorf(minf(ay, minf(by, cy)))) * SS - 1
	var max_y := int(ceilf(maxf(ay, minf(by, cy)))) * SS + 1
	for y in range(min_y, max_y + 1):
		for x in range(min_x, max_x + 1):
			var px := (x + 0.5) / float(SS)
			var py := (y + 0.5) / float(SS)
			var u := ((by - cy) * (px - cx) + (cx - bx) * (py - cy)) / det
			var v := ((cy - ay) * (px - cx) + (ax - cx) * (py - cy)) / det
			if u >= 0.0 and v >= 0.0 and u + v <= 1.0:
				_px(img, x, y, col)


static func _line(img: Image, x0: float, y0: float, x1: float, y1: float, w: float, c := INK) -> void:
	var steps := int(maxf(absf(x1 - x0), absf(y1 - y0)) * SS)
	for i in range(steps + 1):
		var t := float(i) / float(maxi(steps, 1))
		_disc(img, lerpf(x0, x1, t), lerpf(y0, y1, t), w * 0.5, c)


static func _arc(img: Image, cx: float, cy: float, r: float, a0: float, a1: float,
		w: float, c := INK) -> void:
	var steps := int(absf(a1 - a0) * r * SS / 2.0) + 8
	for i in range(steps + 1):
		var a: float = deg_to_rad(lerpf(a0, a1, float(i) / float(steps)))
		_disc(img, cx + cos(a) * r, cy + sin(a) * r, w * 0.5, c)


## A C-shaped arc with a triangular head on the open end, i.e. "rotate".
static func _arrow_around(img: Image, cx: float, cy: float, r: float, a0: float, a1: float) -> void:
	_arc(img, cx, cy, r, a0, a1, 7.0)
	var e := deg_to_rad(a0)
	var tip := Vector2(cx + cos(e) * (r + 5.0), cy + sin(e) * (r + 5.0))
	var tang := Vector2(-sin(e), cos(e))
	var norm := Vector2(cos(e), sin(e))
	_tri(img, tip.x, tip.y,
		tip.x + tang.x * 9.0 - norm.x * 4.0, tip.y + tang.y * 9.0 - norm.y * 4.0,
		tip.x - tang.x * 6.0 - norm.x * 7.0, tip.y - tang.y * 6.0 - norm.y * 7.0)


static func _star(img: Image, cx: float, cy: float, r: float, c := INK) -> void:
	var pts := PackedVector2Array()
	for k in range(10):
		var a := -PI * 0.5 + k * PI / 5.0
		var rr: float = r if k % 2 == 0 else r * 0.44
		pts.append(Vector2(cx + cos(a) * rr, cy + sin(a) * rr) * SS)
	_poly(img, pts, c)


## Even-odd scanline fill of a closed polygon given in pixel space.
static func _poly(img: Image, pts: PackedVector2Array, c := INK) -> void:
	var ys := []
	for p in pts:
		ys.append(p.y)
	for y in range(int(minf(ys.min(), float(img.get_height() - 1))), int(maxf(ys.max(), 1.0)) + 1):
		var hits: Array[float] = []
		for i in pts.size():
			var a := pts[i]
			var b := pts[(i + 1) % pts.size()]
			if (a.y <= y and b.y > y) or (b.y <= y and a.y > y):
				hits.append(a.x + (y - a.y) / (b.y - a.y) * (b.x - a.x))
		hits.sort()
		var k := 0
		while k + 1 < hits.size():
			for x in range(int(hits[k]), int(hits[k + 1]) + 1):
				_px(img, x, y, c)
			k += 2